<?php
/**
 * @version     1.0.0
 * @package     com_eventdata
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; 
 */
// no direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');

// Import CSS
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_eventdata/assets/css/eventdata.css');
?>
<script type="text/javascript">
    js = jQuery.noConflict();
    js(document).ready(function() {
       
    });

    Joomla.submitbutton = function(task)
    {
		if(js('#jform_title').val() == '' && task != 'eventdata.cancel')
		{
			alert("Please enter the title");
			return false;
		}
        if (task == 'eventdata.cancel') {
            Joomla.submitform(task, document.getElementById('eventdata-form'));
        }
        else {
            
            if (task != 'eventdata.cancel' && document.formvalidator.isValid(document.id('eventdata-form'))) {
                
                Joomla.submitform(task, document.getElementById('eventdata-form'));
            }
            else {
                alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
            }
        }
    }
</script>

<form action="<?php echo JRoute::_('index.php?option=com_eventdata&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="eventdata-form" class="form-validate">

    <div class="form-horizontal">
        <?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>

        <?php echo JHtml::_('bootstrap.addTab', 'myTab', 'general', JText::_('COM_EVENTDATA_TITLE_EVENTDATA', true)); ?>
        <div class="row-fluid">
            <div class="span10 form-horizontal">
                <fieldset class="adminform">
                    <div class="control-group">
                        <div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('state'); ?></div>
                    </div>
                    <div class="control-group">
                        <div class="control-label"><?php  echo $this->form->getLabel('title'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('title'); ?></div>
                    </div>
					
					<div class="control-group">
                        <div class="control-label"><?php  echo $this->form->getLabel('date'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('date'); ?></div>
                    </div>
                    
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('location'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('location'); ?></div>
                    </div>
					
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('duration'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('duration'); ?></div>
                    </div>
					
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('audio'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('audio'); ?></div>
                    </div>
					
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('agenda'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('agenda'); ?></div>
                    </div>
					
                    <div class="control-group video_url" >
                        <div class="control-label"><?php echo $this->form->getLabel('minutes'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('minutes'); ?></div>
                    </div>
					
					<div class="control-group video_url" >
                        <div class="control-label"><?php echo $this->form->getLabel('handout1'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('handout1'); ?></div>
                    </div>
					
					<div class="control-group video_url" >
                        <div class="control-label"><?php echo $this->form->getLabel('handout2'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('handout2'); ?></div>
                    </div>
					
					<div class="control-group video_url" >
                        <div class="control-label"><?php echo $this->form->getLabel('handout3'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('handout3'); ?></div>
                    </div>
					
					<div class="control-group video_url" >
                        <div class="control-label"><?php echo $this->form->getLabel('handout4'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('handout4'); ?></div>
                    </div>
					
					<div class="control-group video_url" >
                        <div class="control-label"><?php echo $this->form->getLabel('handout5'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('handout5'); ?></div>
                    </div>
					
                    <div class="control-group">
                        <div class="control-label"><?php echo $this->form->getLabel('created_by'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('created_by'); ?></div>
                    </div>


                </fieldset>
            </div>
        </div>
        <?php echo JHtml::_('bootstrap.endTab'); ?>
        
        

        <?php echo JHtml::_('bootstrap.endTabSet'); ?>

        <input type="hidden" name="task" value="" />
        <?php echo JHtml::_('form.token'); ?>

    </div>
</form>