<?php
/**
 * @version     1.0.0
 * @package     com_clientresource
 * @copyright   Copyright (C) 2016. All rights reserved.
 * @license     GNU General Public License version 2 or later;
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

/**
 * View class for a list of Client Resource - Departments.
 */
class ClientResourceViewDepartments extends JViewLegacy
{
	protected $items;
	protected $pagination;
	protected $state;

	/**
	 * Display the view
	 */
	public function display($tpl = null)
	{
		$this->state		= $this->get('State');
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			throw new Exception(implode("\n", $errors));
		}
        
		ClientResourceHelper::addSubmenu('departments');
        
		$this->addToolbar();
        
        $this->sidebar = JHtmlSidebar::render();
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @since	1.6
	 */
	protected function addToolbar()
	{
		require_once JPATH_COMPONENT.'/helpers/clientresource.php';

		$state	= $this->get('State');
		$canDo	= ClientResourceHelper::getActions($state->get('filter.category_id'));

		JToolBarHelper::title(JText::_('COM_CLIENTRESOURCE_DEPARTMENT_INFORMATION'), 'departments.png');

        //Check if the form exists before showing the add/edit buttons
        $formPath = JPATH_COMPONENT_ADMINISTRATOR.'/views/department';
        if (file_exists($formPath)) {

            if ($canDo->get('core.create')) {
			    JToolBarHelper::addNew('department.add','JTOOLBAR_NEW');
		    }

		    if ($canDo->get('core.edit') && isset($this->items[0])) {
			    JToolBarHelper::editList('department.edit','JTOOLBAR_EDIT');
		    }

        }

		if ($canDo->get('core.edit.state')) {

            if (isset($this->items[0]->state)) {
			    JToolBarHelper::divider();
			    JToolBarHelper::custom('departments.publish', 'publish.png', 'publish_f2.png','JTOOLBAR_PUBLISH', true);
			    JToolBarHelper::custom('departments.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);
            } else if (isset($this->items[0])) {
                //If this component does not use state then show a direct delete button as we can not trash
                JToolBarHelper::deleteList('', 'departments.delete','JTOOLBAR_DELETE');
            }

            if (isset($this->items[0]->checked_out)) {
            	JToolBarHelper::custom('departments.checkin', 'checkin.png', 'checkin_f2.png', 'JTOOLBAR_CHECKIN', true);
            }
		}
        
        //Show trash and delete for components that uses the state field
        if (isset($this->items[0]->state)) {
		    if ($state->get('filter.state') == -2 && $canDo->get('core.delete')) {
			    JToolBarHelper::deleteList('', 'departments.delete','JTOOLBAR_EMPTY_TRASH');
			    JToolBarHelper::divider();
		    } else if ($canDo->get('core.edit.state')) {
			    JToolBarHelper::trash('departments.trash','JTOOLBAR_TRASH');
			    JToolBarHelper::divider();
		    }
        }
		
		//Options button
		if ($canDo->get('core.admin')) {
			JToolBarHelper::preferences('com_clientresource');
		}
		
        //Set sidebar action - New in 3.0
		JHtmlSidebar::setAction('index.php?option=com_clientresource&view=departments');        
        $this->extra_sidebar = '';        
		JHtmlSidebar::addFilter(
			JText::_('JOPTION_SELECT_PUBLISHED'),
			'filter_published',
			JHtml::_('select.options', JHtml::_('jgrid.publishedOptions'), "value", "text", $this->state->get('filter.state'), true)
		);        
	}
    
	protected function getSortFields()
	{
		return array(
			'a.ID' => JText::_('JGRID_HEADING_ID'),
			'a.state' => JText::_('JSTATUS'),
			'a.clname' => JText::_('COM_CLIENTRESOURCE_DEPARTMENT_NAME'),
			'a.con_info' => JText::_('COM_CLIENTRESOURCE_DEPARTMENT_CONTACT_NAME'),
			'a.con_phone' => JText::_('COM_CLIENTRESOURCE_DEPARTMENT_CONTACT_PHONE'),
			'a.con_email' => JText::_('COM_CLIENTRESOURCE_DEPARTMENT_CONTACT_EMAIL'),
			'a.dept_head' => JText::_('COM_CLIENTRESOURCE_DEPARTMENT_CONTACT_HEAD'),
			'a.category' => JText::_('COM_CLIENTRESOURCE_DEPARTMENT_CATEGORY'),
		);
	}

    
}
