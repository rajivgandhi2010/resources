<?php
/**
 * @version     1.0.0
 * @package     com_clientresource
 * @copyright   Copyright (C) 2016. All rights reserved.
 * @license     GNU General Public License version 2 or later; 
 */
// no direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');

// Import CSS
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_clientresource/assets/css/clientresource.css');
?>
<script type="text/javascript">
    js = jQuery.noConflict();
    js(document).ready(function() {
       
    });

    Joomla.submitbutton = function(task)
    {
		if(js('#jform_title').val() == '' && task != 'clientresource.cancel')
		{
			alert("Please enter the title");
			return false;
		}
        if (task == 'clientresource.cancel') {
            Joomla.submitform(task, document.getElementById('clientresource-form'));
        }
        else {
            
            if (task != 'clientresource.cancel' && document.formvalidator.isValid(document.id('clientresource-form'))) {
                
                Joomla.submitform(task, document.getElementById('clientresource-form'));
            }
            else {
                alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
            }
        }
    }
</script>

<form action="<?php echo JRoute::_('index.php?option=com_clientresource&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="clientresource-form" class="form-validate">

    <div class="form-horizontal">
        <?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>

        <?php echo JHtml::_('bootstrap.addTab', 'myTab', 'general', JText::_('COM_CLIENTRESOURCE_MANAGER_INFORMATION', true)); ?>
        <div class="row-fluid">
            <div class="span10 form-horizontal">
                <fieldset class="adminform">
                    <div class="control-group">
                        <div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('state'); ?></div>
                    </div>
                    <div class="control-group">
                        <div class="control-label"><?php  echo $this->form->getLabel('cname'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('cname'); ?></div>
                    </div>
					
					<div class="control-group">
                        <div class="control-label"><?php  echo $this->form->getLabel('cemail'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('cemail'); ?></div>
                    </div>
                    
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('cphone'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('cphone'); ?></div>
                    </div>
					
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('ccphone'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('ccphone'); ?></div>
                    </div>
					
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('caddress'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('caddress'); ?></div>
                    </div>
					
                </fieldset>
            </div>
        </div>
        <?php echo JHtml::_('bootstrap.endTab'); ?>
        <?php echo JHtml::_('bootstrap.endTabSet'); ?>
        <input type="hidden" name="task" value="" />
        <?php echo JHtml::_('form.token'); ?>
    </div>
</form>