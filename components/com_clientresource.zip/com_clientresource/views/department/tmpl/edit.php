<?php
/**
 * @version     1.0.0
 * @package     com_clientresource
 * @copyright   Copyright (C) 2016. All rights reserved.
 * @license     GNU General Public License version 2 or later; 
 */
// no direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');

// Import CSS
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_clientresource/assets/css/department.css');
?>
<script type="text/javascript">
    js = jQuery.noConflict();
    js(document).ready(function() {
       
    });

    Joomla.submitbutton = function(task)
    {
		if(js('#jform_title').val() == '' && task != 'department.cancel')
		{
			alert("Please enter the title");
			return false;
		}
        if (task == 'department.cancel') {
            Joomla.submitform(task, document.getElementById('department-form'));
        }
        else {
            
            if (task != 'department.cancel' && document.formvalidator.isValid(document.id('department-form'))) {
                
                Joomla.submitform(task, document.getElementById('department-form'));
            }
            else {
                alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
            }
        }
    }
</script>

<form action="<?php echo JRoute::_('index.php?option=com_clientresource&view=department&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="department-form" class="form-validate">

    <div class="form-horizontal">
        <?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>

        <?php echo JHtml::_('bootstrap.addTab', 'myTab', 'general', JText::_('COM_CLIENTRESOURCE_DEPARTMENT_INFORMATION', true)); ?>
        <div class="row-fluid">
            <div class="span10 form-horizontal">
                <fieldset class="adminform">
                    <div class="control-group">
                        <div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('state'); ?></div>
                    </div>
                    <div class="control-group">
                        <div class="control-label"><?php  echo $this->form->getLabel('clname'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('clname'); ?></div>
                    </div>
					<div class="control-group">
                        <div class="control-label"><?php  echo $this->form->getLabel('cmid'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('cmid'); ?></div>
                    </div>
					
					<div class="control-group">
                        <div class="control-label"><?php  echo $this->form->getLabel('con_info'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('con_info'); ?></div>
                    </div>
                    
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('con_phone'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('con_phone'); ?></div>
                    </div>
					
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('con_email'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('con_email'); ?></div>
                    </div>
					
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('address'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('address'); ?></div>
                    </div>
					
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('dept_head'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('dept_head'); ?></div>
                    </div>
					
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('category'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('category'); ?></div>
                    </div>
					
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('oracle_cust_num'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('oracle_cust_num'); ?></div>
                    </div>
					
					<div class="control-group image_field" >
                        <div class="control-label"><?php echo $this->form->getLabel('dh_phone'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('dh_phone'); ?></div>
                    </div>
					

					
                </fieldset>
            </div>
        </div>
        <?php echo JHtml::_('bootstrap.endTab'); ?>
        <?php echo JHtml::_('bootstrap.endTabSet'); ?>
        <input type="hidden" name="task" value="" />
        <?php echo JHtml::_('form.token'); ?>
    </div>
</form>