CREATE TABLE IF NOT EXISTS `#__councilmember` (
	`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  	`ordering` int(11) NOT NULL,
  	`state` tinyint(1) NOT NULL,
  	`checked_out` int(11) NOT NULL,
  	`checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  	`name` varchar(50) NOT NULL,
  	`thumbnail` varchar(255) NOT NULL,
	`district` varchar(255) NOT NULL,
	`description` varchar(255) NOT NULL,
	`email` varchar(255) NOT NULL,	
	`phone` varchar(255) NOT NULL,
	`url` varchar(255) NOT NULL,
  	`created_by` int(11) NOT NULL,
  	PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;