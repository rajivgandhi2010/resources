DROP TABLE IF EXISTS `#__councilmember`;
