<?php
/**
 * @version     1.0.0
 * @package     com_councilmember
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later;
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * CouncilMember controller class.
 */
class CouncilMemberControllerCouncilMember extends JControllerForm
{

    function __construct() {
        $this->view_list = 'councilmembers';
        parent::__construct();
    }

}