DROP TABLE IF EXISTS `#__event_registration_registered_users`;
DROP TABLE IF EXISTS `#__event_registration_registered_users_map`;
DROP TABLE IF EXISTS `#__event_states`;