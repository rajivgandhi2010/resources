<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access
defined('_JEXEC') or die('Restricted access');

// EventRegister Table class
class EventRegisterTableEventRegister	extends JTable
{
    function __construct(&$db) 
    {
		parent::__construct('#__event_registration_registered_users', 'id', $db);
    }
}
