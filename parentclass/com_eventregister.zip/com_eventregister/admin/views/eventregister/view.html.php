<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
/**
 * EventRegister View
 */
class EventRegisterViewEventRegister extends JViewLegacy
{
        /**
         * display method of EventRegister view
         * @return void
         */
        public function display($tpl = null) 
        {
			// Set the toolbar
			$this->addToolBar();

			// Display the template
			parent::display($tpl);
        }
 
        /**
         * Setting the toolbar
         */
        protected function addToolBar() 
        {
            JToolBarHelper::title(JText::_('COM_EVENTREGISTER_MANAGER_EVENTREGISTER'));
        }
}
