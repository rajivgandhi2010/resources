<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_eventregister')) {
	return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}

// Get an instance of the controller prefixed by EventRegister
$controller = JControllerLegacy::getInstance('EventRegister');

// Perform the Request task
//$controller->execute(JRequest::getCmd('task'));
$controller->execute(JFactory::getApplication()->input->getCmd('task')); 

// Redirect if set by the controller
$controller->redirect();
