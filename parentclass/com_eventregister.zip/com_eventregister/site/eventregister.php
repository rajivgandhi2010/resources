<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

// Get an instance of the controller prefixed by EventRegister
$controller = JControllerLegacy::getInstance('EventRegister');

$doc = JFactory::getDocument();
$page_title = $doc->getTitle();

// Perform the Request task
$controller->execute(JFactory::getApplication()->input->getCmd('task')); 

// Redirect if set by the controller
$controller->redirect();