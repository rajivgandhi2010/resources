<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * Event Register Component Controller
 *
 * @package Event Register
 *
 */
class EventRegisterController extends JControllerLegacy
{
	/**
	 * Constructor
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	/**
	 * Display the view
	 */
	function display($cachable = false, $urlparams = false)
	{
		$document   = JFactory::getDocument();
		$user       = JFactory::getUser();
		// Set the default view name and format from the Request.
		$jinput     = JFactory::getApplication()->input;
		$id         = $jinput->getInt('id', 0);
		$viewName   = $jinput->getCmd('view', '');
		$viewFormat = $document->getType();
		$layoutName = $jinput->getCmd('layout', 'edit');
			
		$view = $this->getView($viewName, $viewFormat);
		if ($view) {
			switch ($viewName) {
				case 'eventregister':
					$model = $this->getModel($viewName);
					break;
				case 'update_users':
					$model = $this->getModel($viewName);
					break;
				case 'history':
					$model = $this->getModel($viewName);
					break;
				default:
					$model = $this->getModel('registered_users');
					break;
			}
		}
		
		$view->setModel($model, true);
		
		$view->setLayout($layoutName);

		// Push document object into the view.
		$view->document = $document;

		$view->display();
	}
	
	/*
	* Assign user to a selected event
	*/
	function register_user()
	{
		$data =new stdClass();

		//Variables from Form
        $data->case_id   = JRequest::getString('case_id','', 'post');
		$data->firstname   = JRequest::getString('firstname','', 'post');
		$data->lastname   = JRequest::getString('lastname','', 'post');
		$data->address   = JRequest::getString('address','', 'post');
		$data->city   = JRequest::getString('city','', 'post');
		$data->state   = JRequest::getString('state','', 'post');
		$data->zip   = JRequest::getString('zip','', 'post');
		$data->email   = JRequest::getString('email','', 'post');
		$data->homephone   = JRequest::getString('homephone','', 'post');
		$data->workphone   = JRequest::getString('workphone','', 'post');
		$data->cellphone   = JRequest::getString('cellphone','', 'post');
		$data->douglascounty   = JRequest::getString('douglascounty','', 'post');
		$data->comments   = JRequest::getString('comments','', 'post');
		$event_id   = JRequest::getString('event_id','', 'post');
		$data->status   = JRequest::getString('status','1', 'post');
		
		//Insert the form values into registered users table
		$db = JFactory::getDBO();
		$db->insertObject('#__event_registration_registered_users', $data, 'id');
		$user_id = $data->id;
		
		//Map the users with event
		$map_data =new stdClass();
		$map_data->event_id   = $event_id;
		$map_data->user_id   = $user_id;
		$map_data->reg_date   = date('Y-m-d h:i:s');
		$map_data->final_notice   = 0;
		$map_data->attendance   = 0;
		$map_data->status   = 1;
		
		$db->insertObject('#__event_registration_registered_users_map', $map_data, 'id');
		
		$app  = JFactory::getApplication();
		$message = JText::_('Successfully registered for a class.');
		$app->redirect(JURI::root().'events', $message, 'Success');
	}    
	
	/*
	* Update user
	*/
	function update_user()
	{
		/*echo "<pre>";
		print_r($_POST);*/
		$db = JFactory::getDbo(); 
		$query = $db->getQuery(true);
		
		$user_id		= JRequest::getString('user_id','', 'post');
		
		$registered_event	= JRequest::getString('registered_event','', 'post');
		$modified_event_name			= JRequest::getString('event_name','', 'post');
		
		/*Update #__event_registration_registered_users_map table if they did any changes in event dropdown*/
		if($registered_event != $modified_event_name){
			$query = "UPDATE #__event_registration_registered_users_map
					  SET status = '0' WHERE user_id = '".$user_id."' and event_id = '".$registered_event."'";
			$db->setQuery($query);
			$result = $db->execute();
			
			//Map the users with event
			$map_data =new stdClass();
			$map_data->event_id   = $modified_event_name;
			$map_data->user_id   = $user_id;
			$map_data->reg_date   = date('Y-m-d h:i:s');
			$map_data->final_notice   = 0;
			$map_data->attendance   = 0;
			$map_data->status   = 1;
			
			$db->insertObject('#__event_registration_registered_users_map', $map_data, 'id');
		}

		//Variables from Form
        $case_id		= JRequest::getString('case_id','', 'post');
		$firstname   	= JRequest::getString('firstname','', 'post');
		$lastname   	= JRequest::getString('lastname','', 'post');
		$address   		= JRequest::getString('address','', 'post');
		$city   		= JRequest::getString('city','', 'post');
		$state   		= JRequest::getString('state','', 'post');
		$zip   			= JRequest::getString('zip','', 'post');
		$email   		= JRequest::getString('email','', 'post');
		$homephone   	= JRequest::getString('homephone','', 'post');
		$workphone   	= JRequest::getString('workphone','', 'post');
		$cellphone   	= JRequest::getString('cellphone','', 'post');
		$douglascounty 	= JRequest::getString('douglascounty','', 'post');
		$comments   	= JRequest::getString('comments','', 'post');
		$event_id   	= JRequest::getString('event_id','', 'post');
		$status   		= JRequest::getString('status','1', 'post');
		
		$query = "UPDATE #__event_registration_registered_users
						SET case_id = '".$case_id."',
							firstname = '".$firstname."',
							lastname = '".$lastname."',
							address = '".$address."',
							city = '".$city."',
							state = '".$state."',
							zip = '".$zip."',
							email = '".$email."',
							homephone = '".$homephone."',
							workphone = '".$workphone."',
							cellphone = '".$cellphone."',
							douglascounty = '".$douglascounty."',
							comments = '".$comments."'
							WHERE id = '".$user_id."'
             ";

		$db->setQuery($query);
		$result = $db->execute();
		
		$app  = JFactory::getApplication();
		if($result){
			$message = JText::_('Successfully updated the user.');
			$app->redirect(JURI::root().'event/users/'.$modified_event_name, $message, 'Success');
		}		
	}
	
	/*
	* Update Attendance and Final Notice
	*/
	function update_all_registrant()
	{
		//Variables from Form
        $user_ids   = $_POST['user_id'];
		$attendance   = $_POST['attendance'];
		$final_notice   = $_POST['final_notice'];
		$event_id   = $_POST['event_id'];
		
		$db = JFactory::getDbo(); 
		$query = $db->getQuery(true);

		foreach($user_ids as $key => $user_id)
		{
			$query = "UPDATE #__event_registration_registered_users_map
						SET attendance = '".$attendance[$user_id]."',
							final_notice = '".$final_notice[$user_id]."'
							WHERE user_id = '".$user_id."' and event_id = '".$event_id."'
             ";

			$db->setQuery($query);
			$result = $db->execute();
		}

		$app  = JFactory::getApplication();
		if($result){
			$message = JText::_('Successfully updated the attendance and final notice.');
			$app->redirect(JURI::current(), $message, 'Success');
		}
	}
	
	/**
	 * Remove the user from the particular event -> Delete User
	 */
	public static function removeuser()
    {
		$event_id = $_POST['event_id'];
		$user_id = $_POST['user_id'];
		
		$db = JFactory::getDBO();
        $query = $db->getQuery(true); 
		$query = "UPDATE #__event_registration_registered_users_map
					  SET status = '0' WHERE user_id = '".$user_id."' and event_id = '".$event_id."'";
		$db->setQuery($query);

		$result = $db->execute();
		if($result)
			return true;
		else
			return false;
	}
}