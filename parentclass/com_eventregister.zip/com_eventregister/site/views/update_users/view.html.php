<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');
 
/**
 * Users update View class for the Event Register Component
 */
class EventRegisterViewUpdate_users extends JViewLegacy
{
	protected $state;
	protected $item;
	protected $form;
	
    protected $params;
	
	// Overwriting JView display method
    public function display($tpl = null)
    {
		$app  = JFactory::getApplication();
		$user = JFactory::getUser();
		
		$this->state	= $this->get('State');
		$this->item		= $this->get('Item');
		$this->form		= $this->get('Form');
		
		$id = $app->input->getInt('id', 0);
		
		//redirect if not logged in
		if (!$user->get('id')) {
			$app->enqueueMessage(JText::_('You are not authorized to view this page. Please login and try again.'), 'error');
			return false;
		}
		if($id == 0) {
			$app->enqueueMessage(JText::_('You are trying to access an invalid URL.'), 'error');
			return false;
		}
		
		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
            throw new Exception(implode("\n", $errors));
		}

		// Assign data from the model to the view
        $this->user_details = $this->get('Items');
				
		if(empty($this->user_details)) {
			$app->enqueueMessage(JText::_('User not available.'), 'error');
			return false;
		}
		
        if (count($errors = $this->get('Errors'))) 
        {
            JError::raiseError(500, implode('<br />', $errors));
            return false;
        }
		
		
		$this->registered_event_id = $this->get('Registered_event');
		
		// Generate Event Dropdown
        $this->event_details = $this->get('Events');
		$event_select_array = array('value'=>'', 'text'=>' - Select -');
		array_unshift($this->event_details, $event_select_array);
		$default_event = $this->registered_event_id;
		$this->event_name = JHTML::_('select.genericList', $this->event_details, 'event_name', 'class="inputbox form-control" ', 'value', 'text', $default_event);
		
		/*Generate State Dropdown*/
		$this->state_details = $this->get('States');
		$select_array = array('value'=>'', 'text'=>' - Select -');
		array_unshift($this->state_details, $select_array);
		$change_state = '';
		$default_state = $this->user_details[0]->state;
		$this->state_details = JHTML::_('select.genericList', $this->state_details, 'state', 'class="inputbox form-control" '.$change_state, 'value', 'text', $default_state);
		
		
		JHtml::_('behavior.keepalive');
		JHtml::_('behavior.formvalidation');	
		JHtml::_('jquery.framework');
		
		// Load Css
		JHtml::stylesheet('com_eventregister/eventregister.css', array(), true);
		JHtml::stylesheet('com_eventregister/jquery-confirm.css', array(), true);
		
		// Load scripts
		JHtml::_('script', 'com_eventregister/jquery-confirm.js', false, true);
		JHtml::_('script', 'com_eventregister/jquery.mask.js', false, true);
		
		// Prepare the document
		$this->_prepareDocument();
		// Display the view
        parent::display($tpl);
    }
	
	/**
	 * Prepares the document
	 */
	protected function _prepareDocument()
	{
		$app  = JFactory::getApplication();
		$menu = $app->getMenu()->getActive();
		$params = JComponentHelper::getParams( 'com_eventregister' );

		$this->pagetitle = $menu->params->get('page_title');
		$title = null;

		$title = $this->pagetitle;
		
		// Check for empty title and add site name if param is set
		if (empty($title)) {
			$title = $app->getCfg('sitename');
		}
		elseif ($app->getCfg('sitename_pagetitles', 0) == 1) {
			$title = JText::sprintf('JPAGETITLE', $app->getCfg('sitename'), $title);
		}
		elseif ($app->getCfg('sitename_pagetitles', 0) == 2) {
			$title = JText::sprintf('JPAGETITLE', $title, $app->getCfg('sitename'));
		}
		
		$this->document->setTitle($title);

		$style =$params->get('css_style', '');
		$this->document->addStyleDeclaration( $style );
		
	}
	
}
