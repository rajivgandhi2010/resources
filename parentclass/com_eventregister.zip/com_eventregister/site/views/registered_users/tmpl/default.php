<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$app = JFactory::getApplication();
// get some menu parameters	
$menu = $app->getMenu()->getActive();
$this->showpageheading = (int)$menu->params->get('show_page_heading', 1);
$this->pageheading = $menu->params->get('page_heading');

//Escape strings for HTML output
$this->pageclass_sfx = htmlspecialchars($menu->params->get('pageclass_sfx'));

$user = JFactory::getUser();
$document = JFactory::getDocument();
$params = JComponentHelper::getParams( 'com_eventregister' );
$title = $menu->params->get('title', '');
?>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		var all = $('#all-registrants').DataTable({
			"order": [[ 3, "asc" ]],
			responsive: true,
			columnDefs: [
				{ targets: [0,2,4,5,6,8,9,10], orderable: false}
			],
			dom: 'Bfrtip',
			lengthMenu: [
				[ 10, 25, 50, -1 ],
				[ '10 rows', '25 rows', '50 rows', 'Show all' ]
			],
			buttons: [
				'pageLength',
				{
					extend: 'excelHtml5',
					exportOptions: {
						columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
					}
				},
				{
					extend: 'pdfHtml5',
					exportOptions: {
						columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
					}
				},
				{
					extend: 'print',
					exportOptions: {
						columns: [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
					}
				}
			]
		});
		all.on( 'order.dt search.dt', function () {
			all.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
				cell.innerHTML = i+1;
			} );
		} ).draw();
		
		var who = $('#who-attended').DataTable({
			"order": [[ 3, "asc" ]],
			responsive: true,
			columnDefs: [
				{ targets: [0,2,4,5,6,8,9,10], orderable: false}
			],
			dom: 'Bfrtip',
			lengthMenu: [
				[ 10, 25, 50, -1 ],
				[ '10 rows', '25 rows', '50 rows', 'Show all' ]
			],
			buttons: [
				'pageLength',
				{
					extend: 'excelHtml5',
					exportOptions: {
						columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
					}
				},
				{
					extend: 'pdfHtml5',
					exportOptions: {
						columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
					}
				},
				{
					extend: 'print',
					exportOptions: {
						columns: [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
					}
				}
			]
		});
		who.on( 'order.dt search.dt', function () {
			who.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
				cell.innerHTML = i+1;
			} );
		} ).draw();
		
		var whonot = $('#who-did-not').DataTable({
			"order": [[ 3, "asc" ]],
			responsive: true,
			columnDefs: [
				{ targets: [0,2,4,5,6,8,9,10], orderable: false}
			],
			dom: 'Bfrtip',
			lengthMenu: [
				[ 10, 25, 50, -1 ],
				[ '10 rows', '25 rows', '50 rows', 'Show all' ]
			],
			buttons: [
				'pageLength',
				{
					extend: 'excelHtml5',
					exportOptions: {
						columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
					}
				},
				{
					extend: 'pdfHtml5',
					exportOptions: {
						columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
					}
				},
				{
					extend: 'print',
					exportOptions: {
						columns: [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
					}
				}
			]
		});
		whonot.on( 'order.dt search.dt', function () {
			whonot.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
				cell.innerHTML = i+1;
			} );
		} ).draw();
		
		$(".attendance").click(function() {	
			var id = this.id;
			var parent_id = $(this).parents('table').attr('id');
			if(this.value==0){
				//alert('#' + parent_id + ' #attendance-'+id);
				$('#' + parent_id + ' #' + id).val(1);
				$('#' + parent_id + ' #attendance-'+id).val(1);
				$('#' + parent_id + ' .attendance_label_'+id).text(1);
			}
			else {
				$('#' + parent_id + ' #' + id).val(0);
				$('#' + parent_id + ' #attendance-'+id).val(0);
				$('#' + parent_id + ' .attendance_label_'+id).text(0);
			}
		});
		
		$(".final_notice").click(function() {	
			var id = this.id;
			var id = id.substring(3);
			var parent_id = $(this).parents('table').attr('id');
			if(this.value==0){
				$('#' + parent_id + ' #fn-' + id).val(1);
				$('#' + parent_id + ' #final_notice-' + id).val(1);
				$('#' + parent_id + ' .final_notice_label_' + id).text(1);
			}
			else {
				$('#' + parent_id + ' #fn-' + id).val(0);
				$('#' + parent_id + ' #final_notice-' + id).val(0);
				$('#' + parent_id + ' .final_notice_label_' + id).text(0);
			}
		});
		
	});
</script>

<div class="item-page<?php echo $this->pageclass_sfx?>">
	<?php if ($title != '') : ?>
		<div class="page-header">
			<h2><a href="<?php echo $_SERVER["REQUEST_URI"]; ?>"><?php echo $title; ?></a></h2>
		</div>	
	<?php endif; ?>
	
	<div class="users_list">
		
		<h1><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_USERS_LIST'));?></h1>
		
		<!--Event Details -->
		<div class="control-group">
			<p><strong><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_SIGNUP_EVENT_NAME')); ?></strong> : <?php echo $this->event_details[0]->title; ?></p>
			<p><strong><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_SIGNUP_EVENT_DATETIME')); ?></strong> : 
				<?php 	
					$date = date('D, d F Y,', strtotime($this->event_details[0]->eventdate));
					echo $date . ' ' . $this->event_details[0]->starttime . ' h - ' . $this->event_details[0]->endtime . ' h';
				?>
			</p><br/>
		</div>
		
		<?php
			$options = array(
				'startOffset' => 0,  // 0 starts on the first tab, 1 starts the second, etc...
				'useCookie' => true, // this must not be a string. Don't use quotes.
			);
		?>
		<?php echo JHtml::_('tabs.start', 'det-pane',$options); ?>
		
		<!-- ALL REGISTRANTS TAB -->
		<?php echo JHtml::_('tabs.panel',JText::_('COM_EVENTREGISTER_USERS_ALL_REGISTRANTS'), 'all_registrants' ); ?>
		
		<form action="<?php echo htmlspecialchars($this->action); ?>" method="post" name="adminForm" id="all_users">
		
			<div class="userslist">
				<p align="right"><input type="submit" class="btn btn-success" value="<?php echo JText::_('COM_EVENT_REGISTER_USERS_UPDATE_ATTENDANCE'); ?>" /></p>
				<p><?php echo JText::_('COM_EVENT_REGISTER_USERS_TOTAL_REGSITRANTS') . ' - ' . count($this->allusers); ?></p>
				<p><a href="#"><?php echo JText::_('COM_EVENT_REGISTER_USERS_EMAIL_ALL'); ?></a></p><br/>
			</div>
			
			<table class="userstable table-bordered table-striped" id="all-registrants">
				<thead>
					<tr>
						<th>S.No</th>
						<th id="users_list_attendance" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_ATTENDANCE'); ?></th>
						<th id="users_list_case_id" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_CASE_ID'); ?></th>
						<th id="users_list_name" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_NAME'); ?></th>
						<th id="users_list_phone" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_PHONE'); ?></th>
						<th id="users_list_email" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_EMAIL'); ?></th>
						<th id="users_list_address" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_ADDRESS'); ?></th>
						<th id="users_list_final_notice" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_FINAL_NOTICE'); ?></th>
						<th id="users_list_douglas_county" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_DOUGLAS_COUNTY'); ?></th>
						<th id="users_list_commets" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_COMMENTS'); ?></th>
						<th id="users_list_action" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_ACTION'); ?></th>
						<th id="users_list_history" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_HISTORY'); ?></th>
					</tr>
				</thead>
				
				<tbody>
					<?php foreach ($this->allusers as $users) : ?>
						<tr>
							<td></td>
							<td headers="event_register_attendance" align="left" valign="top" >
								<label class="hide_label"><?php echo $users->attendance; ?></label>
								<?php $checked = ($this->escape($users->attendance) == 1) ? "checked=checked value=1" : " value=0"; ?>
								<input type="checkbox" id="all-registrants-<?php echo $users->user_id; ?>" class="attendance" name="attendance[<?php echo $users->user_id; ?>]" <?php echo $checked; ?> >
								<input type="hidden" name="user_id[]" value="<?php echo $users->user_id; ?>" />
							</td>
							
							<input type="hidden" id="attendance-all-registrants-<?php echo $users->user_id; ?>" name="attendance[<?php echo $users->user_id; ?>]" value="<?php echo $this->escape($users->attendance); ?>">
							
							<td headers="event_register_case_id" align="left" valign="top" >
								<?php echo $this->escape($users->case_id); ?>
							</td>
							<td headers="event_register_name" align="left" valign="top" >
								<?php echo $this->escape($users->lastname) . ', ' . $this->escape($users->firstname); ?>
							</td>
							<td headers="event_register_phone" align="left" valign="top" >
								<?php 
									if($this->escape($users->homephone) != '')
										echo 'H:'. $this->escape($users->homephone) . '<br/>'; 
									if($this->escape($users->workphone) != '')
										echo 'W:'. $this->escape($users->workphone) . '<br/>'; 
									if($this->escape($users->cellphone) != '')
										echo 'C:'. $this->escape($users->cellphone); 
								?>
							</td>
							<td headers="event_register_email" align="left" valign="top" >
								<?php echo $this->escape($users->email); ?>
							</td>
							<td headers="event_register_address" align="left" valign="top" >
								<?php 
									if($this->escape($users->address) != '')
										echo $this->escape($users->address) . '<br/>'; 
									if($this->escape($users->city) != '' && $this->escape($users->state) != '')
										echo $this->escape($users->city) . ',' . $this->escape($users->state) . '<br/>'; 
									else if($this->escape($users->city) != '')
										echo $this->escape($users->city) . '<br/>'; 
									else if($this->escape($users->state) != '')
										echo $this->escape($users->state) . '<br/>'; 
									else{
										echo '';
									}
									if($this->escape($users->zip) != '')
										echo $this->escape($users->zip); 
								?>
							</td>
							<td headers="event_register_final_notice" align="left" valign="top" >
								<label class="hide_label"><?php echo $users->final_notice; ?></label>
								<?php $checked = ($this->escape($users->final_notice) == 1) ? "checked=checked value=1" : " value=0"; ?>
								<input type="checkbox" id="fn-<?php echo $users->user_id; ?>" class="final_notice" name="final_notice[<?php echo $users->user_id; ?>]" <?php echo $checked; ?> >
							</td>
							
							<input type="hidden" id="final_notice-<?php echo $users->user_id; ?>" name="final_notice[<?php echo $users->user_id; ?>]" value="<?php echo $this->escape($users->final_notice); ?>">
							
							<td headers="event_register_douglascounty" align="left" valign="top" >
								<?php echo ($this->escape($users->douglascounty) == 1) ? "Yes" : "No"; ?>
							</td>
							<td headers="event_register_comments" align="left" valign="top" >
								<?php echo $this->escape($users->comments); ?>
							</td>
							<td>
								<a href="event/update/<?php echo $this->escape($users->user_id); ?>">Update</a> / 
								<a class="removeuser" id="removeuser-<?php echo $this->escape($users->user_id); ?>" href="#">Delete</a>
							</td>
							<td><a href="event/history/<?php echo $this->escape($users->user_id); ?>">Click here to view Parent History</a></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			
			<input type="hidden" name="option" value="com_eventregister" />
			<input type="hidden" name="task" value="update_all_registrant" />
			<input type="hidden" name="event_id" value="<?php echo $this->event_id; ?>" />
			<?php echo JHtml::_('form.token'); ?>
		</form>
		

		<!-- WHO ATTENDED TAB -->
		<?php echo JHtml::_('tabs.panel',JText::_('COM_EVENTREGISTER_USERS_WHO_ATTENDED'), 'who_attended' ); ?>
		<form action="<?php echo htmlspecialchars($this->action); ?>" method="post" name="adminForm" id="attended_users">
		
			<div class="userslist">
				<p align="right"><input type="submit" class="btn btn-success" value="<?php echo JText::_('COM_EVENT_REGISTER_USERS_UPDATE_ATTENDANCE'); ?>" /></p>
				<p><?php echo JText::_('COM_EVENT_REGISTER_USERS_TOTAL_REGSITRANTS') . ' - ' . count($this->who_attended); ?></p>
				<p><a href="#"><?php echo JText::_('COM_EVENT_REGISTER_USERS_EMAIL_ALL'); ?></a></p><br/>
			</div>
			
			<table class="userstable table-bordered table-striped" id="who-attended">
				<thead>
					<tr>
						<th>S.No</th>
						<th id="users_list_attendance" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_ATTENDANCE'); ?></th>
						<th id="users_list_case_id" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_CASE_ID'); ?></th>
						<th id="users_list_name" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_NAME'); ?></th>
						<th id="users_list_phone" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_PHONE'); ?></th>
						<th id="users_list_email" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_EMAIL'); ?></th>
						<th id="users_list_address" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_ADDRESS'); ?></th>
						<th id="users_list_final_notice" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_FINAL_NOTICE'); ?></th>
						<th id="users_list_douglas_county" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_DOUGLAS_COUNTY'); ?></th>
						<th id="users_list_commets" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_COMMENTS'); ?></th>
						<th id="users_list_action" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_ACTION'); ?></th>
						<th id="users_list_history" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_HISTORY'); ?></th>
					</tr>
				</thead>
				
				<tbody>
					<?php foreach ($this->who_attended as $users) : ?>
						<tr>
							<td></td>
							<td headers="event_register_attendance" align="left" valign="top" >
								<label class="hide_label"><?php echo $users->attendance; ?></label>
								<?php $checked = ($this->escape($users->attendance) == 1) ? "checked=checked value=1" : " value=0"; ?>
								<input type="checkbox" id="who-attended-<?php echo $users->user_id; ?>" class="attendance" name="attendance[<?php echo $users->user_id; ?>]" <?php echo $checked; ?> >
								<input type="hidden" name="user_id[]" value="<?php echo $users->user_id; ?>" />
							</td>
							
							<input type="hidden" id="attendance-who-attended-<?php echo $users->user_id; ?>" name="attendance[<?php echo $users->user_id; ?>]" value="<?php echo $this->escape($users->attendance); ?>">
							
							<td headers="event_register_case_id" align="left" valign="top" >
								<?php echo $this->escape($users->case_id); ?>
							</td>
							<td headers="event_register_name" align="left" valign="top" >
								<?php echo $this->escape($users->lastname) . ', ' . $this->escape($users->firstname); ?>
							</td>
							<td headers="event_register_phone" align="left" valign="top" >
								<?php 
									if($this->escape($users->homephone) != '')
										echo 'H:'. $this->escape($users->homephone) . '<br/>'; 
									if($this->escape($users->workphone) != '')
										echo 'W:'. $this->escape($users->workphone) . '<br/>'; 
									if($this->escape($users->cellphone) != '')
										echo 'C:'. $this->escape($users->cellphone); 
								?>
							</td>
							<td headers="event_register_email" align="left" valign="top" >
								<?php echo $this->escape($users->email); ?>
							</td>
							<td headers="event_register_address" align="left" valign="top" >
								<?php 
									if($this->escape($users->address) != '')
										echo $this->escape($users->address) . '<br/>'; 
									if($this->escape($users->city) != '' && $this->escape($users->state) != '')
										echo $this->escape($users->city) . ',' . $this->escape($users->state) . '<br/>'; 
									else if($this->escape($users->city) != '')
										echo $this->escape($users->city) . '<br/>'; 
									else if($this->escape($users->state) != '')
										echo $this->escape($users->state) . '<br/>'; 
									else{
										echo '';
									}
									if($this->escape($users->zip) != '')
										echo $this->escape($users->zip); 
								?>
							</td>
							<td headers="event_register_final_notice" align="left" valign="top" >
								<label class="hide_label"><?php echo $users->final_notice; ?></label>
								<?php $checked = ($this->escape($users->final_notice) == 1) ? "checked=checked value=1" : " value=0"; ?>
								<input type="checkbox" id="fn-<?php echo $users->user_id; ?>" class="final_notice" name="final_notice[<?php echo $users->user_id; ?>]" <?php echo $checked; ?> >
							</td>
							
							<input type="hidden" id="final_notice-<?php echo $users->user_id; ?>" name="final_notice[<?php echo $users->user_id; ?>]" value="<?php echo $this->escape($users->final_notice); ?>">
							
							<td headers="event_register_douglascounty" align="left" valign="top" >
								<?php echo ($this->escape($users->douglascounty) == 1) ? "Yes" : "No"; ?>
							</td>
							<td headers="event_register_comments" align="left" valign="top" >
								<?php echo $this->escape($users->comments); ?>
							</td>
							<td>
								<a href="event/update/<?php echo $this->escape($users->user_id); ?>">Update</a> / 
								<a class="removeuser" id="removeuser-<?php echo $this->escape($users->user_id); ?>" href="">Delete</a>
							</td>
							<td><a href="event/history/<?php echo $this->escape($users->user_id); ?>">Click here to view Parent History</a></td>
						</tr>
					<?php endforeach; ?>
				</tbody>				
			</table>
			<input type="hidden" name="option" value="com_eventregister" />
			<input type="hidden" name="task" value="update_all_registrant" />
			<input type="hidden" name="event_id" value="<?php echo $this->event_id; ?>" />
			<?php echo JHtml::_('form.token'); ?>
		</form>
		
		<!-- WHO DID NOT ATTENTED TAB -->
		<?php echo JHtml::_('tabs.panel',JText::_('COM_EVENTREGISTER_USERS_WHO_DID_NOT_ATTENTED'), 'who_did_not' ); ?>
		<form action="<?php echo htmlspecialchars($this->action); ?>" method="post" name="adminForm" id="not_attended_users">
		
			<div class="userslist">
				<p align="right"><input type="submit" class="btn btn-success" value="<?php echo JText::_('COM_EVENT_REGISTER_USERS_UPDATE_ATTENDANCE'); ?>" /></p>
				<p><?php echo JText::_('COM_EVENT_REGISTER_USERS_TOTAL_REGSITRANTS') . ' - ' . count($this->who_did_not_attended); ?></p>
				<p><a href="#"><?php echo JText::_('COM_EVENT_REGISTER_USERS_EMAIL_ALL'); ?></a></p><br/>
			</div>
			
			<table class="userstable table-bordered table-striped" id="who-did-not">
				<thead>
					<tr>
						<th>S.No</th>
						<th id="users_list_attendance" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_ATTENDANCE'); ?></th>
						<th id="users_list_case_id" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_CASE_ID'); ?></th>
						<th id="users_list_name" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_NAME'); ?></th>
						<th id="users_list_phone" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_PHONE'); ?></th>
						<th id="users_list_email" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_EMAIL'); ?></th>
						<th id="users_list_address" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_ADDRESS'); ?></th>
						<th id="users_list_final_notice" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_FINAL_NOTICE'); ?></th>
						<th id="users_list_douglas_county" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_DOUGLAS_COUNTY'); ?></th>
						<th id="users_list_commets" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_COMMENTS'); ?></th>
						<th id="users_list_action" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_ACTION'); ?></th>
						<th id="users_list_history" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_USERS_TABLE_HISTORY'); ?></th>
					</tr>
				</thead>
				
				<tbody>
					<?php foreach ($this->who_did_not_attended as $users) : ?>
						<tr>
							<td></td>
							<td headers="event_register_attendance" align="left" valign="top" >
								<label class="hide_label"><?php echo $users->attendance; ?></label>
								<?php $checked = ($this->escape($users->attendance) == 1) ? "checked=checked value=1" : " value=0"; ?>
								<input type="checkbox" id="who-did-not-<?php echo $users->user_id; ?>" class="attendance" name="attendance[<?php echo $users->user_id; ?>]" <?php echo $checked; ?> >
								<input type="hidden" name="user_id[]" value="<?php echo $users->user_id; ?>" />
							</td>
							
							<input type="hidden" id="attendance-who-did-not-<?php echo $users->user_id; ?>" name="attendance[<?php echo $users->user_id; ?>]" value="<?php echo $this->escape($users->attendance); ?>">
							
							<td headers="event_register_case_id" align="left" valign="top" >
								<?php echo $this->escape($users->case_id); ?>
							</td>
							<td headers="event_register_name" align="left" valign="top" >
								<?php echo $this->escape($users->lastname) . ', ' . $this->escape($users->firstname); ?>
							</td>
							<td headers="event_register_phone" align="left" valign="top" >
								<?php 
									if($this->escape($users->homephone) != '')
										echo 'H:'. $this->escape($users->homephone) . '<br/>'; 
									if($this->escape($users->workphone) != '')
										echo 'W:'. $this->escape($users->workphone) . '<br/>'; 
									if($this->escape($users->cellphone) != '')
										echo 'C:'. $this->escape($users->cellphone); 
								?>
							</td>
							<td headers="event_register_email" align="left" valign="top" >
								<?php echo $this->escape($users->email); ?>
							</td>
							<td headers="event_register_address" align="left" valign="top" >
								<?php 
									if($this->escape($users->address) != '')
										echo $this->escape($users->address) . '<br/>'; 
									if($this->escape($users->city) != '' && $this->escape($users->state) != '')
										echo $this->escape($users->city) . ',' . $this->escape($users->state) . '<br/>'; 
									else if($this->escape($users->city) != '')
										echo $this->escape($users->city) . '<br/>'; 
									else if($this->escape($users->state) != '')
										echo $this->escape($users->state) . '<br/>'; 
									else{
										echo '';
									}
									if($this->escape($users->zip) != '')
										echo $this->escape($users->zip); 
								?>
							</td>
							<td headers="event_register_final_notice" align="left" valign="top" >
								<label class="hide_label"><?php echo $users->final_notice; ?></label>
								<?php $checked = ($this->escape($users->final_notice) == 1) ? "checked=checked value=1" : " value=0"; ?>
								<input type="checkbox" id="fn-<?php echo $users->user_id; ?>" class="final_notice" name="final_notice[<?php echo $users->user_id; ?>]" <?php echo $checked; ?> >
							</td>
							
							<input type="hidden" id="final_notice-<?php echo $users->user_id; ?>" name="final_notice[<?php echo $users->user_id; ?>]" value="<?php echo $this->escape($users->final_notice); ?>">
							
							<td headers="event_register_douglascounty" align="left" valign="top" >
								<?php echo ($this->escape($users->douglascounty) == 1) ? "Yes" : "No"; ?>
							</td>
							<td headers="event_register_comments" align="left" valign="top" >
								<?php echo $this->escape($users->comments); ?>
							</td>
							<td>
								<a href="event/update/<?php echo $this->escape($users->user_id); ?>">Update</a> / 
								<a class="removeuser" id="removeuser-<?php echo $this->escape($users->user_id); ?>" href="">Delete</a>
							</td>
							<td><a href="event/history/<?php echo $this->escape($users->user_id); ?>">Click here to view Parent History</a></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<input type="hidden" name="option" value="com_eventregister" />
			<input type="hidden" name="task" value="update_all_registrant" />
			<input type="hidden" id="event_id" name="event_id" value="<?php echo $this->event_id; ?>" />
			<?php echo JHtml::_('form.token'); ?>
		</form>
		<?php echo JHtml::_('tabs.end'); ?>
	</div>	
</div>
<script type="text/javascript">
jQuery(document).ready(function($){
	$(".tabs .tabs").click(function(event){
		location.reload();
	});
	
	$(".removeuser").live("click", function(event){
		event.preventDefault();		
		
		var event_id = $('#event_id').val();
		var user = this.id;
		var user_id = user.substr(11);
		
		$.confirm({
			title: 'Delete Confirmation',
			content: 'Are you sure want to delete this user?',
			buttons: {
				'Yes': {
					text: 'Yes',
					btnClass: 'btn-success',
					action: function () {			
						$.ajax({
							type: "POST",
							url: "index.php?option=com_eventregister&view=registered_users&task=removeuser",
							data: {
								event_id: event_id,
								user_id: user_id
							},
							cache: false,
							success: function(result){
								location.reload();
							}
						});
					}
				},
				'No': {
					text: 'No',
					btnClass: 'btn-red',
					action: function () {
						//return false;
					}
				},
			}
		});

	});
});
</script>