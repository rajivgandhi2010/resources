<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$app = JFactory::getApplication();
// get some menu parameters	
$menu = $app->getMenu()->getActive();
$this->showpageheading = (int)$menu->params->get('show_page_heading', 1);
$this->pageheading = $menu->params->get('page_heading');

//Escape strings for HTML output
$this->pageclass_sfx = htmlspecialchars($menu->params->get('pageclass_sfx'));

$user = JFactory::getUser();
$document = JFactory::getDocument();
$params = JComponentHelper::getParams( 'com_eventregister' );
$title = $menu->params->get('title', '');
?>
<script type="text/javascript">
	jQuery(document).ready(function($) {	
		var t = $('#registrant_history').DataTable({
			responsive: true,
			columnDefs: [
				{ targets: [0,1,2,3,4,5,6,7,8,9], orderable: false}
			],
			dom: 'Bfrtip',
			lengthMenu: [
				[ 10, 25, 50, -1 ],
				[ '10 rows', '25 rows', '50 rows', 'Show all' ]
			],
			buttons: [
				'pageLength'
			],
			"order": [[ 10, 'desc' ]]
		});
	 
		t.on( 'order.dt search.dt', function () {
			t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
				cell.innerHTML = i+1;
			} );
		} ).draw();
	});
</script>
<div class="item-page<?php echo $this->pageclass_sfx?>">
	<?php if ($title != '') : ?>
		<div class="page-header">
			<h2><a href="<?php echo $_SERVER["REQUEST_URI"]; ?>"><?php echo $title; ?></a></h2>
		</div>	
	<?php endif; ?>
	
	<div class="history_list">
		
		<h1><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_REGISTRANT_HISTORY'));?></h1>
		<br/>
		<table class="historytable table-bordered table-striped" id="registrant_history">
			<thead>
				<tr>
					<th id="history_sno" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_HISTORY_TABLE_SNO'); ?></th>
					<th id="history_caseid" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_HISTORY_TABLE_CASE_ID'); ?></th>
					<th id="history_name" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_HISTORY_TABLE_NAME'); ?></th>
					<th id="history_phone" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_HISTORY_TABLE_PHONE'); ?></th>
					<th id="history_email" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_HISTORY_TABLE_EMAIL'); ?></th>
					<th id="history_address" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_HISTORY_TABLE_ADDRESS'); ?></th>
					<th id="history_finalnotice" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_HISTORY_TABLE_FINAL_NOTICE'); ?></th>
					<th id="history_county" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_HISTORY_TABLE_COUNTY'); ?></th>
					<th id="history_comments" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_HISTORY_TABLE_COMMENTS'); ?></th>
					<th id="history_details" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_HISTORY_TABLE_DETAILS'); ?></th>
					<th id="history_reg_date" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTER_HISTORY_TABLE_REGISTERED_DATE'); ?></th>
				</tr>
			</thead>
			
			<tbody>
				<?php foreach ($this->histories as $history) : ?>
					<tr>
						<td></td>
						<td headers="event_register_case_id" align="left" valign="top" >
							<?php echo $this->escape($history->case_id); ?>
						</td>
						
						<td headers="event_register_name" align="left" valign="top" >
							<?php echo $this->escape($history->lastname) . ', ' . $this->escape($history->firstname); ?>
						</td>
						
						<td headers="event_register_phone" align="left" valign="top" >
							<?php 
								if($this->escape($history->homephone) != '')
									echo 'H:'. $this->escape($history->homephone) . '<br/>'; 
								if($this->escape($history->workphone) != '')
									echo 'W:'. $this->escape($history->workphone) . '<br/>'; 
								if($this->escape($history->cellphone) != '')
									echo 'C:'. $this->escape($history->cellphone); 
							?>
						</td>
						
						<td headers="event_register_email" align="left" valign="top" >
							<?php echo $this->escape($history->email); ?>
						</td>
						
						<td headers="event_register_address" align="left" valign="top" >
							<?php 
								if($this->escape($history->address) != '')
									echo $this->escape($history->address) . '<br/>'; 
								if($this->escape($history->city) != '' && $this->escape($history->state) != '')
									echo $this->escape($history->city) . ',' . $this->escape($history->state) . '<br/>'; 
								else if($this->escape($history->city) != '')
									echo $this->escape($history->city) . '<br/>'; 
								else if($this->escape($history->state) != '')
									echo $this->escape($history->state) . '<br/>'; 
								else{
									echo '';
								}
								if($this->escape($history->zip) != '')
									echo $this->escape($history->zip); 
							?>
						</td>
						
						<td headers="event_register_final_notice" align="left" valign="top" >
							<?php $checked = ($this->escape($history->final_notice) == 1) ? "checked=checked value=1" : " value=0"; ?>
							<input type="checkbox" class="final_notice" name="final_notice[]" <?php echo $checked; ?> >
						</td>
						
						<td headers="event_register_douglascounty" align="left" valign="top" >
							<?php echo ($this->escape($history->douglascounty) == 1) ? "Yes" : "No"; ?>
						</td>
						
						<td headers="event_register_comments" align="left" valign="top" >
							<?php echo $this->escape($history->comments); ?>
						</td>
						
						<td headers="event_register_comments" align="left" valign="top" >
							<?php echo $this->escape($history->event_detail); ?>
						</td>
						
						<td headers="event_register_comments" align="left" valign="top" >
							<?php echo $this->escape($history->reg_date); ?>
						</td>						
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>	
</div>
