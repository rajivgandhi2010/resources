<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');
 
/**
 * HTML View class for the Event Register Component
 */
class EventRegisterViewHistory extends JViewLegacy
{
	protected $state;
	protected $item;
	protected $form;
	
    protected $params;
	
	// Overwriting JView display method
    public function display($tpl = null)
    {
		$app  = JFactory::getApplication();
		$user = JFactory::getUser();
		$uri  = JFactory::getURI();
		$document    = JFactory::getDocument();
		$jinput      = $app->input;
		$task  = $jinput->getCmd('task', '');

		$this->state	= $this->get('State');
		$this->item		= $this->get('Item');
		$this->form		= $this->get('Form');
		$this->action	= $uri->toString();
		
		$id = $app->input->getInt('id', 0);
		$this->user_id = $id;

		//redirect if not logged in
		if (!$user->get('id')) {
			$app->enqueueMessage(JText::_('You are not authorized to view this page. Please login and try again.'), 'error');
			return false;
		}
		if($id == 0) {
			$app->enqueueMessage(JText::_('You are trying to access an invalid URL.'), 'error');
			return false;
		}
		
		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
            throw new Exception(implode("\n", $errors));
		}

		// Assign data from the model to the view
        $this->histories = $this->get('Items');
		
        if (count($errors = $this->get('Errors'))) 
        {
            JError::raiseError(500, implode('<br />', $errors));
            return false;
        }
		
		JHtml::_('behavior.keepalive');
		JHtml::_('jquery.framework');
		
		// Load Css
		JHtml::stylesheet('com_eventregister/dataTables.jqueryui.css', array(), true);
		JHtml::stylesheet('com_eventregister/buttons.dataTables.min.css', array(), true);
		JHtml::stylesheet('com_eventregister/responsive.dataTables.min.css', array(), true);
		JHtml::stylesheet('com_eventregister/eventregister.css', array(), true);
		
		
		// Load scripts
		$document->addScript('media/com_eventregister/js/jquery.dataTables.js');
		
		//Datatable export JS
		$document->addScript('media/com_eventregister/js/datatable/dataTables.buttons.min.js');
		$document->addScript('media/com_eventregister/js/datatable/dataTables.responsive.min.js');
		
		// Prepare the document
		$this->_prepareDocument();
		// Display the view
        parent::display($tpl);
    }
	
	/**
	 * Prepares the document
	 */
	protected function _prepareDocument()
	{
		$app  = JFactory::getApplication();
		$menu = $app->getMenu()->getActive();
		$params = JComponentHelper::getParams( 'com_eventregister' );
		//echo "<pre>";print_r($menu);exit;
		$this->pagetitle = $menu->params->get('page_title');
		$title = null;

		$title = $this->pagetitle;
		
		// Check for empty title and add site name if param is set
		if (empty($title)) {
			$title = $app->getCfg('sitename');
		}
		elseif ($app->getCfg('sitename_pagetitles', 0) == 1) {
			$title = JText::sprintf('JPAGETITLE', $app->getCfg('sitename'), $title);
		}
		elseif ($app->getCfg('sitename_pagetitles', 0) == 2) {
			$title = JText::sprintf('JPAGETITLE', $title, $app->getCfg('sitename'));
		}
		
		$this->document->setTitle($title);

		$style =$params->get('css_style', '');
		$this->document->addStyleDeclaration( $style );
		
	}
	
}
