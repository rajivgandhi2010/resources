<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$app = JFactory::getApplication();
// get some menu parameters	
$menu = $app->getMenu()->getActive();
$this->showpageheading = (int)$menu->params->get('show_page_heading', 1);
$this->pageheading = $menu->params->get('page_heading');

//Escape strings for HTML output
$this->pageclass_sfx = htmlspecialchars($menu->params->get('pageclass_sfx'));

$user = JFactory::getUser();
$document = JFactory::getDocument();
$params = JComponentHelper::getParams( 'com_eventregister' );
$title = $menu->params->get('title', '');
?>
<script type="text/javascript">
	Joomla.submitbutton = function(task) {
		if (document.formvalidator.isValid(document.id('signupform'))) {
			jQuery.confirm({
				title: 'Submit Confirmation',
				content: 'Are you sure?',
				buttons: {
					'Yes': {
						text: 'Yes',
						btnClass: 'btn-success',
						action: function () {
							jQuery("form#signupform").submit();
						}
					},
					'No': {
						text: 'No',
						btnClass: 'btn-red',
						action: function () {
							//return false;
						}
					},
				}
			});
		}
		else {
			
		}
	}
</script>
<script type="text/javascript">
jQuery( document ).ready(function($) {
	document.formvalidator.setHandler('cellphone', function (value) {
		return validatePhone(value);
	});
	
	document.formvalidator.setHandler('mail', function (value) {
		return isValidEmailAddress( value );
	});
	
	document.formvalidator.setHandler('zip', function (value) {
		return (/(^\d{5}$)|(^\d{5}-\d{4}$)/).test(value);
	});

	document.formvalidator.setHandler('homephone', function (value) {
		return validatePhone(value);
	});

	document.formvalidator.setHandler('workphone', function (value) {
		return validatePhone(value);
	});

	//On Cancel Button Click
	$("#cancelbutton").confirm({
		title: 'Cancel Confirmation',
		content: 'Are you sure?',
		buttons: {
			'Yes': {
				text: 'Yes',
				btnClass: 'btn-success',
				action: function () {
					window.location.href = "<?php echo JURI::base(); ?>events";
				}
			},
			'No': {
				text: 'No',
				btnClass: 'btn-red',
				action: function () {
					//return false;
				}
			},
		}
	});
	/*Douglas county - Yes /No toggle*/
	$('#radioBtn a').on('click', function(){
		var sel = $(this).data('title');
		var tog = $(this).data('toggle');
		$('#'+tog).prop('value', sel);
		
		$('a[data-toggle="'+tog+'"]').not('[data-title="'+sel+'"]').removeClass('active').addClass('notActive');
		$('a[data-toggle="'+tog+'"][data-title="'+sel+'"]').removeClass('notActive').addClass('active');
	});
	
	/*Comments validaion
	* Not allow user to enter more than 150 characters
	*/
	$("#comments").keyup(function (e) {
		description_value = $(this);
		if(description_value.val().length >= 150){
			description_value.val( description_value.val().substr(0, 150) );
		}
	});
	
	/*Phone number - Auto format fields*/
	$('#homephone').mask('000-000-0000');
	$('#workphone').mask('000-000-0000');
	$('#cellphone').mask('000-000-0000');
	
});
function validatePhone(phone_number) {
    //var a = document.getElementById(Phone).value;
    var filter = /^\(?(\d{3})\)?[-\. ]?(\d{3})[-\. ]?(\d{4})$/;
    if (filter.test(phone_number)) {
        return true;
    }
    else {
        return false;
    }
}
function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
};
</script>
	
<div class="item-page<?php echo $this->pageclass_sfx?>">
	<?php if ($title != '') : ?>
		<div class="page-header">
			<h2><a href="<?php echo $_SERVER["REQUEST_URI"]; ?>"><?php echo $title; ?></a></h2>
		</div>	
	<?php endif; ?>
	
	<div class="signup-form">
		
		<h1><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_SIGNUP_EVENT'));?></h1>
		
		<!--Event Details -->
		<div class="control-group">
			<h3><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_SIGNUP_EVENT_INFORMATION')); ?></h3>
			<p><strong><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_SIGNUP_EVENT_NAME')); ?></strong> : <?php echo $this->event_details[0]->title; ?></p>
			<p><strong><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_SIGNUP_EVENT_LOCATION')); ?></strong> : <?php echo $this->event_details[0]->location; ?></p>
			<p><strong><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_SIGNUP_EVENT_DATETIME')); ?></strong> : 
				<?php 	
					$date = date('D, d F Y,', strtotime($this->event_details[0]->eventdate));
					echo $date . ' ' . $this->event_details[0]->starttime . ' h - ' . $this->event_details[0]->endtime . ' h';
				?>
			</p><br/>
		</div>

		<form action="<?php echo JRoute::_('index.php?option=com_eventregister'); ?>" method="post" name="signupform" id="signupform" class="form-validate form-horizontal">
		
			<!-- Sign up for a Class - Form -->
			<div class="form-group">	
				<!-- Case ID -->
				<div class="col-md-4">
					<label class="control-label hasTip hasPopover required" for="case_id" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_CASE_ID_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_CASE_ID')); ?></label>  
					<input class="form-control required" name="case_id" id="case_id" type="text" value="" />
				</div>
				
				<!-- First Name -->
				<div class="col-md-4">
					<label class="control-label hasTip hasPopover required" for="firstname" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_FIRSTNAME_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_FIRSTNAME')); ?></label>  
					<input id="firstname" name="firstname" type="text" class="form-control required">	
				</div>	
				
				<!-- Last Name -->
				<div class="col-md-4">
					<label for="lastname" class="control-label hasTip hasPopover required" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_LASTNAME_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_LASTNAME')); ?></label>
					<input class="form-control required" name="lastname" id="lastname" type="text" value="" />
				</div>
			</div>
			
			<div class="form-group">	
				<!-- Address -->
				<div class="col-md-4">
					<label for="address" class="control-label hasTip hasPopover" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_ADDRESS_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_ADDRESS')); ?></label>
					<input class="form-control" name="address" id="address" type="text" value="" />
				</div>
				
				<!-- City -->
				<div class="col-md-4">
					<label for="city" class="control-label hasTip hasPopover" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_CITY_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_CITY')); ?></label>
					<input class="form-control" name="city" id="city" type="text" value="" />
				</div>	
				
				<!-- State -->
				<div class="col-md-4">
					<label for="state" class="control-label hasTip hasPopover" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_STATE_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_STATE')); ?></label>
					<?php echo $this->state_details; ?>
				</div>
			</div>
			
			<div class="form-group">	
				<!-- Zip -->
				<div class="col-md-4">
					<label for="zip" class="control-label hasTip hasPopover" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_ZIP_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_ZIP')); ?></label>
					<input class="validate-zip form-control" name="zip" id="zip" type="text" value="" />
				</div>
				
				<!-- Email -->
				<div class="col-md-4">
					<label for="email" class="control-label hasTip hasPopover required" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_EMAIL_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_EMAIL')); ?> *</label>
					<input class="required validate-mail form-control" name="email" id="email" type="text" value="" />
				</div>
				
				<!-- Home Phone -->
				<div class="col-md-4">
					<label for="homephone" class="control-label hasTip hasPopover" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_HOMEPHONE_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_HOMEPHONE')); ?></label>
					<input class="validate-homephone form-control" name="homephone" id="homephone" type="text" value="" />
				</div>
			</div>
			
			<div class="form-group">	
				<!-- Work Phone -->
				<div class="col-md-4">
					<label for="workphone" class="control-label hasTip hasPopover" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_WORKPHONE_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_WORKPHONE')); ?></label>
					<input class="validate-workphone form-control" name="workphone" id="workphone" type="text" value="" />
				</div>
				
				<!-- Cell Phone -->
				<div class="col-md-4">
					<label for="cellphone" class="control-label hasTip hasPopover required" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_CELLPHONE_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_CELLPHONE')); ?> *</label>
					<input class="required validate-cellphone form-control" name="cellphone" id="cellphone" type="text" value="" />
				</div>	
				
				<!-- Douglas County - Yes / No -->
				<div class="col-md-4">
					<label for="douglascounty " class="control-label hasTip hasPopover required" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_COUNTY_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_COUNTY')); ?> *</label>
					<div class="input-group">
						<div id="radioBtn" class="btn-group">
							<a class="btn btn-primary btn-sm active" data-toggle="douglascounty" data-title="1">YES</a>
							<a class="btn btn-primary btn-sm notActive" data-toggle="douglascounty" data-title="0">NO</a>
						</div>
						<input type="hidden" name="douglascounty" id="douglascounty" >
					</div>
				</div>
			</div>
			
			<div class="form-group">	
				<!-- Comments -->
				<div class="col-md-8">
					<label for="comments" class="control-label hasTip hasPopover" data-content="<?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_COMMENTS_DESC')); ?>"><?php echo htmlspecialchars(JText::_('COM_EVENTREGISTER_FIELD_COMMENTS')); ?></label>
					<textarea class="form-control" name="comments" id="comments" rows="4" cols="50"></textarea>					
				</div>
			</div>
	
			<div><hr /></div>
			
			<!-- Buttons -->
			<div class="form-group button-div">			 
				<div class="col-md-12 text-center">
					<button type="button" class="btn btn-success" id="submitbutton" onclick="Joomla.submitbutton('event.save')"><?php echo JText::_('JSAVE') ?></button>
					<button type="button" id="cancelbutton" class="btn btn-success" ><?php echo JText::_('COM_EVENTREGISTER_FORM_CANCEL'); ?></button>
				</div>
				
				<input type="hidden" name="option" value="com_eventregister" />
				<input type="hidden" name="task" value="register_user" />
				<input type="hidden" name="event_id" value="<?php echo $this->event_details[0]->id; ?>" />
				<?php echo JHtml::_('form.token'); ?>
			</div>
		</form>
	</div>	
</div>