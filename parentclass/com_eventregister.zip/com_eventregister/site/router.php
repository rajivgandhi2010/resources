<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
defined('_JEXEC') or die;

function eventregisterBuildRoute(&$query)
{
	$segments = array();
	
	if (isset($query['view'])) {
		$segments[] = $query['view'];
		unset($query['view']);
	}

	if (isset($query['id'])) {
		$segments[] = $query['id'];
		unset($query['id']);
	};
	return $segments;
}

function eventregisterParseRoute($segments)
{
	$vars = array();

	// Count segments
	$count = count($segments);

	// Handle View and Identifier
	switch ($segments[0])
	{
		case 'signup':
		{
			$vars['view'] = 'eventregister';
			if(isset($segments[1]) && $segments[1] !='update')
				$vars['id'] = $segments[1];
			else{
				$vars['id'] = $segments[2];
			}
		}
		break;
		case 'users':
		{
			$vars['view'] = 'registered_users';
			if(isset($segments[1]))
				$vars['id'] = $segments[1];
		}
		break;
		case 'update':
		{
			$vars['view'] = 'update_users';
			if(isset($segments[1]))
				$vars['id'] = $segments[1];
		}
		break;
		
		case 'history':
		{
			$vars['view'] = 'history';
			if(isset($segments[1]))
				$vars['id'] = $segments[1];
		}
		break;
		
		default:
		{
			$vars['id'] = $segments[0];
		}
		break;
	}
	return $vars;
}
?>