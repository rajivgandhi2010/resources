<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
/**
 * Event Register Model
 */
class EventRegisterModelRegistered_Users extends JModelList
{
	/**
	 * Get the Event Details
	 */
    protected function getListQuery()
    {
		$app  = JFactory::getApplication();
		$id = $app->input->getInt('id', 0);
		
        // Create a new query object.         
        $db = JFactory::getDBO();
        $query = $db->getQuery(true); 		 
		$query->select('id, location, eventdate, starttime, endtime, title');
        $query->from('#__event_registration_events');
		$query->where('id = '. $id);
        return $query;
    }
	
	/**
	 * Get the Users list who are all registered for an event
	 */
	public static function getAllUsers()
    {
		$app  = JFactory::getApplication();
		$users = array();
		$id = $app->input->getInt('id', 0);
		
		$db = JFactory::getDBO();
        $query = $db->getQuery(true); 	
		
		$query->select('a.user_id, a.attendance, a.final_notice,b.*');
        $query->from('#__event_registration_registered_users_map as a');
		
		$query->join('LEFT', $db->quoteName('#__event_registration_registered_users', 'b') . ' ON (' . $db->quoteName('a.user_id') . ' = ' . $db->quoteName('b.id') . ')');
		
		$query->where('a.event_id = '. $id);
		$query->where('a.status = 1');
		$query->where('b.status = 1');
	
		$db->setQuery($query);
		$users = $db->loadObjectList();

		return $users;
	}
	
	/**
	 * Get the Users list who are all attended the event
	 */
	public static function getWhoAttended()
    {
		$app  = JFactory::getApplication();
		$users = array();
		$id = $app->input->getInt('id', 0);
		
		$db = JFactory::getDBO();
        $query = $db->getQuery(true); 	
		
		$query->select('a.user_id, a.attendance, a.final_notice,b.*');
        $query->from('#__event_registration_registered_users_map as a');
		
		$query->join('LEFT', $db->quoteName('#__event_registration_registered_users', 'b') . ' ON (' . $db->quoteName('a.user_id') . ' = ' . $db->quoteName('b.id') . ')');
		
		$query->where('a.event_id = '. $id);
		$query->where('a.attendance = 1');
		$query->where('a.status = 1');
		$query->where('b.status = 1');
	
		$db->setQuery($query);
		$users = $db->loadObjectList();

		return $users;
	}
	
	/**
	 * Get the Users list who are all not attended the event
	 */
	public static function getWhoDidNotAttended()
    {
		$app  = JFactory::getApplication();
		$users = array();
		$id = $app->input->getInt('id', 0);
		
		$db = JFactory::getDBO();
        $query = $db->getQuery(true); 	
		
		$query->select('a.user_id, a.attendance, a.final_notice,b.*');
        $query->from('#__event_registration_registered_users_map as a');
		
		$query->join('LEFT', $db->quoteName('#__event_registration_registered_users', 'b') . ' ON (' . $db->quoteName('a.user_id') . ' = ' . $db->quoteName('b.id') . ')');
		
		$query->where('a.event_id = '. $id);
		$query->where('a.attendance = 0');
		$query->where('a.status = 1');
		$query->where('b.status = 1');
	
		$db->setQuery($query);
		$users = $db->loadObjectList();

		return $users;
	}
	
	/**
	 * Set the query limit
	 */
	protected function populateState($ordering=null, $direction=null)
	{
		$this->setState('list.limit', 0);
	}
}