<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
/**
 * Event Register Model
 */
class EventRegisterModelEventRegister extends JModelList
{
    protected function getListQuery()
    {
		$app  = JFactory::getApplication();
		$id = $app->input->getInt('id', 0);
		
        // Create a new query object.         
        $db = JFactory::getDBO();
        $query = $db->getQuery(true); 		 
		$query->select('id, location, eventdate, starttime, endtime, title');
        $query->from('#__event_registration_events');
		$query->where('id = '. $id);
        return $query;
    }
	
	public function getStates()
    {
		$db = JFactory::getDBO();
        $query = $db->getQuery(true);
		
		$query->select('state_abbr as value,state_name as text');
        $query->from('#__event_states');
        $query->order('state_name ASC');
		$db->setQuery($query);
		$states = $db->loadObjectList();
		return $states;
	}
	
	protected function populateState($ordering=null, $direction=null)
	{
		$this->setState('list.limit', 0);
	}
}