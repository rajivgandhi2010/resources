<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
/**
 * Event Register Model
 */
class EventRegisterModelUpdate_Users extends JModelList
{
    protected function getListQuery()
    {
		$app  = JFactory::getApplication();
		$id = $app->input->getInt('id', 0);
		
        // Create a new query object.         
        $db = JFactory::getDBO();
        $query = $db->getQuery(true); 		 
		$query->select('*');
        $query->from('#__event_registration_registered_users');
		$query->where('id = '. $id);
        return $query;
    }
	
	/*Get state values from event_states table to generate a States Dropdown*/
	public function getStates()
    {
		$db = JFactory::getDBO();
        $query = $db->getQuery(true);
		
		$query->select('state_abbr as value,state_name as text');
        $query->from('#__event_states');
        $query->order('state_name ASC');
		$db->setQuery($query);
		$states = $db->loadObjectList();
		return $states;
	}
	
	/*Get event values to generate a Event Name Dropdown*/
	public function getEvents()
    {
		$db = JFactory::getDBO();
		$id = $this->getRegistered_event();
       
		//$query = $db->getQuery(true);
		/*$query->select("id as value,CONCAT(title,' -- ',eventdate, ' ' , starttime, ' to ', endtime) as text");
        $query->from('#__event_registration_events');
        $query->order('title ASC');*/
		
		$query = "select a.id as value,CONCAT(a.title,' -- ',a.eventdate, ' ' , a.starttime, ' to ', a.endtime) as text from #__event_registration_events as a where a.maxplaces > 
		(select count(*) from #__event_registration_registered_users_map as b where b.event_id = a.id and a.id != $id and b.status = 1) 
		and a.status = 1 order by a.title ASC";
		
		//echo $query;
		$db->setQuery($query);
		$event_details = $db->loadObjectList();
		
		return $event_details;
	}
	
	/*Get Event Id from UserID*/
	public function getRegistered_event()
    {
		$app  = JFactory::getApplication();
		$db = JFactory::getDBO();
        $query = $db->getQuery(true);
		$id = $app->input->getInt('id', 0);
		
		$db = JFactory::getDBO();
        $query = $db->getQuery(true); 	
		
		$query->select('event_id');
        $query->from('#__event_registration_registered_users_map');
		
		$query->where('user_id = '. $id);
		$query->where('status = 1');
	
		$db->setQuery($query);
		$registered_event_id = $db->loadResult();
		
		return $registered_event_id;
		
	}
	protected function populateState($ordering=null, $direction=null)
	{
		$this->setState('list.limit', 0);
	}
}