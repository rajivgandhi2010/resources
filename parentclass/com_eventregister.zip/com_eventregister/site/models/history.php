<?php
/**
 * @version 1.0
 * @package Event Register
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
/**
 * Event Register Model
 */
class EventRegisterModelHistory extends JModelList
{
	/**
	 * Get the Event Details
	 */
    protected function getListQuery()
    {
		$app  = JFactory::getApplication();
		$id = $app->input->getInt('id', 0);
		
        // Create a new query object.         
        $db = JFactory::getDBO();
        $query = $db->getQuery(true); 	

		$query->select("a.*,b.*,CONCAT(c.title,' -- ',c.eventdate, ' ' , c.starttime, ' to ', c.endtime) as event_detail");
        $query->from('#__event_registration_registered_users_map as a');
		
		$query->join('LEFT', $db->quoteName('#__event_registration_registered_users', 'b') . ' ON (' . $db->quoteName('a.user_id') . ' = ' . $db->quoteName('b.id') . ')');
		
		$query->join('LEFT', $db->quoteName('#__event_registration_events', 'c') . ' ON (' . $db->quoteName('a.event_id') . ' = ' . $db->quoteName('c.id') . ')');
		
		$query->where('a.user_id = '. $id);
		$query->order('a.reg_date DESC ');
		
        return $query;
    }
	
	/**
	 * Set the query limit
	 */
	protected function populateState($ordering=null, $direction=null)
	{
		$this->setState('list.limit', 0);
	}
}