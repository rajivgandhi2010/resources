jQuery(document).ready(function($) {

	/*From Date*/
	$('#fromdate').datetimepicker({
		language : 'fr',
		weekStart : 1,
		todayBtn : 0,
		autoclose : true,
		todayHighlight : 0,
		startView : 2,
		minView : 2,
		//format : 'mm/dd/yyyy'
		format : 'yyyy-mm-dd'
	}).on('changeDate', function(e){
		var startDate = $('#fromdate').val();
		$('#todate').datetimepicker('setStartDate', startDate);
	});
	
	/*TO Date*/
	$('#todate').datetimepicker({
		language : 'fr',
		weekStart : 1,
		todayBtn : 0,
		autoclose : true,
		todayHighlight : 0,
		startView : 2,
		minView : 2,
		format : 'yyyy-mm-dd'
	});
});