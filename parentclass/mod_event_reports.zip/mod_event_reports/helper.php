<?php
/**
 * @version 1.0
 * @package Event Reports Module
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

JHtml::_('bootstrap.framework', true);

/**
 * Helper class for Event Reports module
 * @subpackage Modules
 * @license        GNU/GPL
 */
class modEventReportsHelper
{
	public function __construct($config = array())
	{
		parent::__construct($config);
	}
	
 	/**
     * Retrieves the Event records
	 *	return search_results
   	*/
	public static function getEventDatesAjax() 
	{
		$app  = JFactory::getApplication();
		$db = JFactory::getDBO();
        $query = $db->getQuery(true);
		
		$event_details = $_REQUEST['event_details'];
		$query->select("eventdate");
        $query->from('#__event_registration_events');
		$query->where('title = "'. $event_details.'"');
		
		$db->setQuery($query);
		$result = $db->loadObjectList();
		
		$data = '<div class="col-md-2">
					<label class="control-label" for="event_date">Date : </label>
				</div>
				<div class="col-md-4">
					<select name="event_date" id="event_date" class="form-control input-md">';
		foreach($result as $key => $row)
		{
			$data .= "<option>" . $row->eventdate . "</option>";
		}
		$data .= '</select></div>';
		return $data;
	}
	
	
	/**
     * Retrieves the Event records
	 *	return search_results
   	*/
	public static function getEventResultsAjax() 
	{
		$app  = JFactory::getApplication();
		$db = JFactory::getDBO();
        $query = $db->getQuery(true); 

		// Form Data
		$event_details = $_REQUEST['event_details'];
		$event_date = $_REQUEST['event_date'];
		$type = $_REQUEST['type'];	
		
		//Build a Query
		$query->select("a.*,b.*,c.*,CONCAT(a.title,' -- ',a.eventdate, ' ' , a.starttime, ' to ', a.endtime) as event_detail");
        $query->from('#__event_registration_events as a');
		
		$query->join('RIGHT', $db->quoteName('#__event_registration_registered_users_map', 'b') . ' ON (' . $db->quoteName('a.id') . ' = ' . $db->quoteName('b.event_id') . ')');
		
		$query->join('LEFT', $db->quoteName('#__event_registration_registered_users', 'c') . ' ON (' . $db->quoteName('b.user_id') . ' = ' . $db->quoteName('c.id') . ')');
		
		//$query->where('b.status = 1');
		
		//if($type == 1 || $type == 2)
		//{
			$query->where('a.title = "'. $event_details.'"');
			$query->where('a.eventdate = "'. $event_date.'"');
		//}
		if($type == 2)
		{
			$query->where('b.attendance = 1');
		}
		if($type == 3)
		{
			$query->where('b.final_notice = 1');
		}
		if($type == 4)
		{
			$query->where('b.status = 0');
		}
		else
		{
			$query->where('b.status = 1');
		}
		
	
		
		$db->setQuery($query);
		$result = $db->loadObjectList();
		
		
		$data = "<script type='text/javascript'>
					jQuery(document).ready(function($) {
						var t = $('#search-results').DataTable({
							'order': [[ 2, 'asc' ]],
							responsive: true,
							columnDefs: [
								{ targets: [0, 1,3,4,5,6,7,8,9,10], orderable: false}
							],
							dom: 'Bfrtip',
							lengthMenu: [
								[ 10, 25, 50, -1 ],
								[ '10 rows', '25 rows', '50 rows', 'Show all' ]
							],
							buttons: [
								'pageLength',
								{
									extend: 'excelHtml5',
									exportOptions: {
										columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 ]
									}
								},
								{
									extend: 'pdfHtml5',
									exportOptions: {
										columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 ]
									}
								},
								{
									extend: 'print',
									exportOptions: {
										columns: [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 ]
									}
								}
							]
						});
						t.on( 'order.dt search.dt', function () {
							t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
								cell.innerHTML = i+1;
							} );
						} ).draw();
					});
				</script>
				<table class='eventtable' id='search-results' summary='search-results'>
					<thead>
						<tr>
							<th id='search_result_sno' class='sectiontableheader' align='left'>S. No</th>
							<th id='search_result_caseid' class='sectiontableheader' align='left'>Case ID</th>
							<th id='search_result_name' class='sectiontableheader' align='left'>Name</th>
							<th id='search_result_phone' class='sectiontableheader' align='left'>Phone</th>
							<th id='search_result_email' class='sectiontableheader' align='left'>Email</th>
							<th id='search_result_address' class='sectiontableheader' align='left'>Address</th>
							<th id='search_result_attendance' class='sectiontableheader' align='left'>Attendance</th>
							<th id='search_result_final_notice' class='sectiontableheader' align='left'>Final Notice</th>
							<th id='search_result_county' class='sectiontableheader' align='left'>Douglas County</th>
							<th id='search_result_comments' class='sectiontableheader' align='left'>Comments</th>
							<th id='search_result_details' class='sectiontableheader' align='left'>Event Details</th>
							<th id='search_result_registered_date' class='sectiontableheader' align='left'>Registered Date</th>
						</tr>
					</thead>
					<tbody>";
		foreach($result as $key => $row)
		{
			$phone = $address = '';
			$phone .= ($row->homephone != '') ? "H:$row->homephone <br/>" : '';
			$phone .= ($row->workphone != '') ? "W:$row->workphone <br/>" : '';
			$phone .= ($row->cellphone != '') ? "C:$row->cellphone" : '';
			
			$address .= ($row->address != '') ? "$row->address, <br/>" : '';
			$address .= ($row->city != '') ? "$row->city,$row->state<br/>" : '';
			$address .= ($row->zip != '') ? "$row->zip <br/>" : '';
			
			$data .= "<tr>";
			$data .= "<td></td>";
			$data .= "<td>" . $row->case_id . "</td>";
			$data .= "<td>" . $row->lastname . ', ' . $row->firstname . "</td>";
			$data .= "<td>" . $phone . "</td>";
			$data .= "<td>" . $row->email . "</td>";
			$data .= "<td>" . $address . "</td>";
			$data .= ($row->attendance == 1) ? "<td>Yes</td>" : "<td>No</td>";
			$data .= ($row->final_notice == 1) ? "<td>Yes</td>" : "<td>No</td>";
			$data .= ($row->douglascounty == 1) ? "<td>Yes</td>" : "<td>No</td>";
			$data .= "<td>" . $row->comments . "</td>";
			$data .= "<td>" . $row->event_detail . "</td>";
			$data .= "<td>" . $row->reg_date . "</td>";
			$data .= "</tr>";
		}
		$data .= "</tbody></table>";
		
		return $data;
	}
}
?>