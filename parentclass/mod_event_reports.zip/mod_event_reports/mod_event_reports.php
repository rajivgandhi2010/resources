<?php
/**
 * @version 1.0
 * @package Event Reports Module
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

// Include the syndicate functions only once
require_once( dirname(__FILE__).'/helper.php' );


JHtml::_('jquery.framework');
JHtml::script('modules/mod_' . $module->name . '/js/bootstrap-datepicker.js');
JHtml::script('modules/mod_' . $module->name . '/js/jquery.dataTables.js');
JHtml::script('modules/mod_' . $module->name . '/js/dataTables.buttons.min.js');
JHtml::script('modules/mod_' . $module->name . '/js/buttons.flash.min.js');
JHtml::script('modules/mod_' . $module->name . '/js/jszip.min.js');
JHtml::script('modules/mod_' . $module->name . '/js/pdfmake.min.js');
JHtml::script('modules/mod_' . $module->name . '/js/vfs_fonts.js');
JHtml::script('modules/mod_' . $module->name . '/js/buttons.html5.min.js');
JHtml::script('modules/mod_' . $module->name . '/js/buttons.print.min.js');
JHtml::script('modules/mod_' . $module->name . '/js/dataTables.responsive.min.js');
JHtml::script('modules/mod_' . $module->name . '/js/script.js');

require( JModuleHelper::getLayoutPath( 'mod_'.$module->name,$params->get('layout', 'default') ) );