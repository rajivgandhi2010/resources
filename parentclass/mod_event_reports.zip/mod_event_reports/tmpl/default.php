<?php
/**
 * @version 1.0
 * @package Event Reports Module
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

$document = JFactory::getDocument();

$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/dataTables.jqueryui.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/datepicker.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/icons.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/buttons.dataTables.min.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/responsive.dataTables.min.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/report_form.css' );
?>

<form class="event_report_form form-horizontal" name="event_report_form" method="POST">
	<fieldset>
		<div class="form-group">
			<div class="col-md-2">
				<label class="control-label" for="event_details">Event Details : </label>
			</div> 
			<div class="col-md-4">
				<select name="event_details" id="event_details" class="form-control input-md">
					<option value=""> - Select an Event - </option>
					<option value="Reaching Beyond Conflict - Women">Reaching Beyond Conflict - Women</option>
					<option value="Reaching Beyond Conflict - Men">Reaching Beyond Conflict - Men</option>
					<option value="What about the children">What about the children</option>
					<option value="What about the children - Spanish">What about the children - Spanish</option>
				</select>
			</div>
		</div>
		
		<div class="form-group date_field">
			
		</div>
		
		<div class="form-group">
			<div class="col-md-2">
				<label class="control-label" for="type">Report Type : </label>
			</div> 
			<div class="col-md-4">
				<select name="type" id="type" class="form-control input-md">
					<option value=""> - Choose the report type - </option>
					<option value="1">Number of people registered</option>
					<option value="2">Number of people attended</option>
					<option value="3">Number of Final Notices</option>
					<option value="4">Number of people cancelled</option>					
				</select>
			</div>
		</div>
		
		<div class="form-group button-div">			 
			<div class="col-md-12 text-center">
				<input id="submitbutton" class="submitbutton btn btn-success" type="button" value="Search">
				<input id="resetbutton" class="resetbutton btn btn-success" type="reset" value="Reset" name="Reset">
			</div>
		</div>

	</fieldset>
</form>



<div id="loading-image"><center><img src="modules/mod_event_reports/images/loading.gif" title="loading" alt="loading" /></center></div>
<div id="search_results"></div>

<script type="text/javascript">
	jQuery(document).ready(function($){
		$('#loading-image').hide();
		
		$(".resetbutton").on("click", function(event){
			$('#search_results').hide();
			$('.date_field').html('');
			//$('#submitbutton').attr('disabled','true');
		});
		
		/*Generate event date dropdown*/
		$("#event_details").on("change", function(event){
			if(this.value == '')
			{
				$('.date_field').html('');
				//$('#submitbutton').attr('disabled','true');
			}
			else{
				$.ajax({
					type: "POST",
					url: "index.php?option=com_ajax&module=event_reports&method=getEventDates&format=json",
					data: {
						event_details:$('#event_details').val()
					},
					cache: false,
					success: function(result){
						var data = result.data;
						$('.date_field').html(data);
					}
				});
			}
		});
		
		/*Generate Report - Submit button click event*/
		$(".submitbutton").on("click", function(event){
			var event_details = $('#event_details').val();
			var event_date = $('#event_date').val();
			var type = $('#type').val();
			
			if(event_details == '' || event_date == '' || type == '')
			{
				var error_msg = '<div class="alert alert-error"><button class="close" type="button" data-dismiss="alert">×</button>';
				if(event_details == '')
					error_msg += '<div>Invalid field: Event Details </div>';
				if(event_date == '')
					error_msg += '<div>Invalid field: Event Date </div>';
				if(type == '')
					error_msg += '<div>Invalid field: Report Type </div>';
				
				error_msg += '</div>';
				$('#system-message-container').html(error_msg);
				$('#search_results').html('');
			}
			else
			{				
				$('#loading-image').show();
				$('#search_results').hide();
				$('#system-message-container').html('');
				$.ajax({
					type: "POST",
					url: "index.php?option=com_ajax&module=event_reports&method=getEventResults&format=json",
					data: {
						event_details:$('#event_details').val(),
						event_date:$('#event_date').val(),
						type:$('#type').val()					
					},
					cache: false,
					success: function(result){
						var data = result.data;
						$('#search_results').show();
						$('#search_results').html(data);
					},
					complete: function(){
						$('#loading-image').hide();
					}
				});
			}
		});
	});
</script>