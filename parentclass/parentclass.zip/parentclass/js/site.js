/*Footer always in Bottom*/
jQuery( document ).ready(function() {
	var height = jQuery(document).height();
	var header = jQuery('header').outerHeight();
	var footer = jQuery('footer').outerHeight();
    
	var header_footer = header + footer;
	var container_height = height - header_footer;
	jQuery('.content-part .container').css('min-height',container_height);
});