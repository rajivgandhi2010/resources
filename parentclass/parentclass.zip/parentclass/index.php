<?php
/**
 * @package     Joomla.Site
 * @subpackage  Templates.Parentclass
 *
 * @copyright   Copyright (C) 2016 Sensiple Software Solutions. All rights reserved.
 */

defined('_JEXEC') or die;

JHtml::_('bootstrap.framework');
$app   = JFactory::getApplication();
$doc   = JFactory::getDocument();
$this->language = $doc->language;
$this->direction = $doc->direction;
$config = JFactory::getConfig();
$menu = $app->getMenu(); 
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
	<head>
    	<meta charset="utf-8">

        <!-- disable iPhone inital scale -->
        <meta name="viewport" content="width=device-width; initial-scale=1.0">
        <jdoc:include type="head" />  
        <!-- main css -->
		
		<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">

		<link href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css">
		<link href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/style.css" rel="stylesheet" type="text/css">
		
		<script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/bootstrap.min.js"></script>
		<script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/site.js"></script>
	</head>
    
    <body>
		<header>	
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav class="navbar navbar-default" role="navigation">
							<div class="navbar-header">
								 
								<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
									 <span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
								</button> 
								<a class="navbar-brand" href="<?php echo $this->baseurl ?>">Parent Class Registration</a>
							</div>
							
							<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
								<jdoc:include type="modules" name="menu" style="xhtml" />							
							</div>
							
						</nav>
					</div>
				</div>
			</div>
		</header>
		<div class="content-part">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<jdoc:include type="message" />
						<jdoc:include type="component" />
					</div>
				</div>
			</div>
		</div>
		<footer>
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<center>Copyrights&copy 2016. All Rights Reserved.</center>
					</div>
				</div>
			</div>
		</footer>
	</body>
</html>