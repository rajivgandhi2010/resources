This version includes:
- Import/Export view
- Multicategory support
- Parent category
- Ical output
- Gmap
- Calendar
- Option to Exclude categories in simplelistview
- 10 Custom fields
- Contact

Tips, suggestions are very welcome..




