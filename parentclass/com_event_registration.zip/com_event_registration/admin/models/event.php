<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
defined('_JEXEC') or die;

/**
 * Event model.
 */
class Event_RegistrationModelEvent extends JModelAdmin
{
	/**
	 * Returns a reference to the a Table object, always creating it.
	 *
	 * @param	type	The table type to instantiate
	 * @param	string	A prefix for the table class name. Optional.
	 * @param	array	Configuration array for model. Optional.
	 * @return	JTable	A database object
	 *
	 */
	public function getTable($type = 'Event', $prefix = 'Event_RegistrationTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param	array	$data		Data for the form.
	 * @param	boolean	$loadData	True if the form is to load its own data (default case), false if not.
	 * @return	mixed	A JForm object on success, false on failure
	 *
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_event_registration.event', 'event', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form)) {
			return false;
		}
		return $form;
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_event_registration.edit.event.data', array());

		if (empty($data)){
			$data = $this->getItem();
		}

		return $data;
	}

	/**
	 * Prepare and sanitise the table data prior to saving.
	 *
	 * @param $table JTable-object.
	 */
	protected function _prepareTable($table)
	{
		$jinput 		= JFactory::getApplication()->input;

		$db = $this->getDbo();
		$table->title = htmlspecialchars_decode($table->title, ENT_QUOTES);

		$table->starttime		= date('H:i',strtotime($table->starttime));
		$table->endtime = date('H:i',strtotime($table->endtime));
	}

	/**
	 * Method to save the form data.
	 *
	 * @param $data array
	 */
	public function save($data)
	{
		// Variables
		$date        = JFactory::getDate();
		$app         = JFactory::getApplication();
		$jinput      = $app->input;
		$event_registrationsettings = Event_RegistrationHelper::config();
		$fileFilter  = new JInput($_FILES);
		$table       = $this->getTable();

		// Check if we're in the front or back
		$backend = (bool)$app->isAdmin();
		$new     = (bool)empty($data['id']);

		// Variables
		$task             = $jinput->get('task', '', 'cmd');

		// convert international date formats...
		if (!empty($data['eventdate'])) {
			$d = JFactory::getDate($data['eventdate'], 'UTC');
			$data['eventdate'] = $d->format('Y-m-d', true, false);
		}

		// Save the event
		$saved = parent::save($data);

		return $saved;
	}
}