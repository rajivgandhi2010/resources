<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

/**
 * Event Registration Component Controller
 */
class Event_RegistrationController extends JControllerLegacy
{
	/**
	 * @var		string	The default view.
	 *
	 */
	protected $default_view = 'main';

	public function __construct()
	{
		parent::__construct();
	}


	/**
	 * Display the view
	 *
	 */
	public function display($cachable = false, $urlparams = false)
	{
		parent::display();
		return $this;
	}
}
?>