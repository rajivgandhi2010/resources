Drop table `#__event_registration_events`;
Drop table `#__event_registration_config`;