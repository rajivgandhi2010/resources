<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

// Access check.
require_once (JPATH_COMPONENT_SITE.'/factory.php');
if (!Event_RegistrationFactory::getUser()->authorise('core.manage', 'com_event_registration')) {
	return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}

// import joomla controller library
jimport('joomla.application.component.controller');

// Require the frontend base controller
require_once (JPATH_COMPONENT.'/controller.php');

// Get an instance of the controller
$controller = JControllerLegacy::getInstance('Event_Registration');

// Perform the Request task
$input = JFactory::getApplication()->input;
$controller->execute($input->getCmd('task'));

// Redirect if set by the controller
$controller->redirect();
?>