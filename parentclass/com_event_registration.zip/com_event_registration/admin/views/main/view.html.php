<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

/**
 * View class for the Event Registration home screen
 *
 * @package Event Registration
 */
class Event_RegistrationViewMain extends JViewLegacy {

	public function display($tpl = null)
	{
		//initialise variables
		$document	= JFactory::getDocument();
		$user 		= Event_RegistrationFactory::getUser();

		// Set the toolbar
        $this->addToolBar();
		parent::display($tpl);
	}
	/**
	 * Setting the toolbar
	 */
	public function addToolBar() 
	{
		JToolbarHelper::title(JText::_('COM_EVENT_REGISTRATION_EVENTS'), 'event_registration');
	}
}
?>