<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

// Component Helper
jimport('joomla.application.component.helper');
require_once(JPATH_SITE.'/components/com_event_registration/helpers/helper.php');

/**
 * Event Registration Component Route Helper
 * based on Joomla ContentHelperRoute
 *
 * @static
 * @package		Event Registration
 *
 */
abstract class Event_RegistrationHelperRoute
{
	protected static $lookup;
	const ARTIFICALID = 0;

	/**
	 * Determines an Event Registration Link
	 *
	 * @param int The id of an Event Registration item
	 * @param string The view
	 * @param string The category of the item
	 * @deprecated Use specific Route methods instead!
	 *
	 * @return string determined Link
	 */
	public static function getRoute($id, $view = 'event', $category = null)
	{
		// Deprecation warning.
		JLog::add('Event_RegistrationHelperRoute::getRoute() is deprecated, use specific route methods instead.', JLog::WARNING, 'deprecated');

		$needles = array(
			$view => array((int) $id)
		);

		if ($item = self::_findItem($needles)) {
			$link = 'index.php?Itemid='.$item;
		}
		else {
			// Create the link
			$link = 'index.php?option=com_event_registration&view='.$view.'&id='. $id;

			if ($item = self::_findItem($needles)) {
				$link .= '&Itemid='.$item;
			}
			elseif ($item = self::_findItem()) {
				$link .= '&Itemid='.$item;
			}
		}

		return $link;
	}

	public static function getEventRoute($id, $catid = null)
	{
		$settings 		= Event_RegistrationHelper::globalattribs();
		$defaultItemid 	= $settings->get('default_Itemid');

		$needles = array(
			'event' => array((int) $id)
		);

		// Create the link
		$link = 'index.php?option=com_event_registration&view=event&id='. $id;

		if ($item = self::_findItem($needles)) {
			$link .= '&Itemid='.$item;
		}
		elseif ($item = self::_findItem()) {
			if (isset($defaultItemid))
				{
					$link .= '&Itemid='.$defaultItemid;
				}
		}

		return $link;
	}


	protected static function getRouteWithoutId($my)
	{
		$settings 		= Event_RegistrationHelper::globalattribs();
		$defaultItemid 	= $settings->get('default_Itemid');

		$needles = array();
		$needles[$my] = array(self::ARTIFICALID);

		// Create the link
		$link = 'index.php?option=com_event_registration&view='.$my;

		if ($item = self::_findItem($needles)) {
			$link .= '&Itemid='.$item;
		}
		elseif ($item = self::_findItem()) {
			if (isset($defaultItemid))
				{
					$link .= '&Itemid='.$defaultItemid;
				} else {
					$link .= '&Itemid='.$item;
				}
		}

		return $link;
	}

	/**
	 * Determines the Itemid
	 *
	 * searches if a menuitem for this item exists
	 * if not the active menuitem will be returned
	 *
	 * @param array The id and view
	 *
	 *
	 * @return int Itemid
	 */
	protected static function _findItem($needles = null)
	{
		$app = JFactory::getApplication();
		$menus = $app->getMenu('site');

		// Prepare the reverse lookup array.
		if (self::$lookup === null) {
			self::$lookup = array();

			$component = JComponentHelper::getComponent('com_event_registration');
			$items = $menus->getItems('component_id', $component->id);

			if ($items) {
				foreach ($items as $item)
				{
					if (isset($item->query) && isset($item->query['view'])) {
						if (isset($item->query['layout']) && ($item->query['layout'] == 'calendar')) {
							continue; // skip calendars
						}

						$view = $item->query['view'];

						if (!isset(self::$lookup[$view])) {
							self::$lookup[$view] = array();
						}

						if (isset($item->query['id'])) {
							self::$lookup[$view][$item->query['id']] = $item->id;
						}
						// Some views have no ID, but we have to set one
						else {
							self::$lookup[$view][self::ARTIFICALID] = $item->id;
						}
					}
				}
			}
		}

		if ($needles) {
			foreach ($needles as $view => $ids)
			{
				if (isset(self::$lookup[$view])) {
					foreach($ids as $id)
					{
						if (isset(self::$lookup[$view][(int)$id])) {
							// TODO: Check on access. See commented code below
							return self::$lookup[$view][(int)$id];
						}
					}
				}
			}
		}
		else {
			$active = $menus->getActive();
			if ($active) {
				return $active->id;
			}
		}

		return null;
	}
}
?>