<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
defined('_JEXEC') or die;

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

// ensure Event_RegistrationFactory is loaded (because this class is used by modules or plugins too)
require_once(JPATH_SITE.'/components/com_event_registration/factory.php');

/**
 * Holds some usefull functions to keep the code a bit cleaner
 */
class Event_RegistrationHelper
{
	/**
	 * Pulls settings from database and stores in an static object
	 *
	 * @return object
	 *
	 */
	static function config()
	{
		static $config;

		if (!is_object($config)) {
			$event_registrationConfig = Event_RegistrationConfig::getInstance();
			$config = clone $event_registrationConfig->toObject(); // We need a copy to ensure not to store 'params' we add below!

			$config->params = JComponentHelper::getParams('com_event_registration');
		}

		return $config;
	}


	/**
	 * Pulls settings from database and stores in an static object
	 *
	 * @return object
	 *
	 */
	static function globalattribs()
	{
		static $globalregistry;
		if (!is_object($globalregistry)) {
			$globalregistry = new JRegistry(self::config()->globalattribs);
		}

		return $globalregistry;
	}


	/**
	 * Retrieves the CSS-settings from database and stores in an static object
	 */
	static function retrieveCss()
	{
		static $registryCSS;
		if (!is_object($registryCSS)) {
			$registryCSS = new JRegistry(self::config()->css);
		}

		return $registryCSS;
	}

	/**
	 * this method generate the date string to a date array
	 *
	 * @var string the date string
	 * @return array the date informations
	 * @access public
	 */
	static function generate_date($startdate, $enddate)
	{
		$validEnddate = Event_RegistrationHelper::isValidDate($enddate);

		$startdate = explode("-",$startdate);
		$date_array = array("year" => $startdate[0],
							"month" => $startdate[1],
							"day" => $startdate[2],
							"weekday" => date("w",mktime(1,0,0,$startdate[1],$startdate[2],$startdate[0])),
							"unixtime" => mktime(1,0,0,$startdate[1],$startdate[2],$startdate[0]));
		if ($validEnddate) {
			$enddate = explode("-", $enddate);
			$day_diff = (mktime(1,0,0,$enddate[1],$enddate[2],$enddate[0]) - mktime(1,0,0,$startdate[1],$startdate[2],$startdate[0]));
			$date_array["day_diff"] = $day_diff;
		}
		return $date_array;
	}

	/**
	 * return day number of the week starting with 0 for first weekday
	 *
	 * @param array of 2 letters day
	 * @return array of int
	 */
	static function convert2CharsDaysToInt($days, $firstday = 0)
	{
		$result = array();
		foreach ($days as $day)
		{
			switch (strtoupper($day))
			{
				case 'MO':
					$result[] = 1 - $firstday;
					break;
				case 'TU':
					$result[] = 2 - $firstday;
					break;
				case 'WE':
					$result[] = 3 - $firstday;
					break;
				case 'TH':
					$result[] = 4 - $firstday;
					break;
				case 'FR':
					$result[] = 5 - $firstday;
					break;
				case 'SA':
					$result[] = 6 - $firstday;
					break;
				case 'SU':
					$result[] = (7 - $firstday) % 7;
					break;
				default:
					JError::raiseWarning(500, JText::_('COM_EVENT_REGISTRATION_WRONG_EVENTRECURRENCE_WEEKDAY'));
			}
		}

		return $result;
	}

	/**
	 * Build the select list for access level
	 */
	static function getAccesslevelOptions($ownonly = false)
	{
		$db = JFactory::getDBO();
		$where = '';
		if ($ownonly) {
			$levels = JFactory::getUser()->getAuthorisedViewLevels();
			$where = ' WHERE id IN ('.implode(',', $levels).')';
		}

		$query = 'SELECT id AS value, title AS text'
				. ' FROM #__viewlevels'
				. $where
				. ' ORDER BY ordering, id'
				;
		$db->setQuery($query);
		$groups = $db->loadObjectList();

		return $groups;
	}

	/**
	 * return true is a date is valid (not null, or 0000-00...)
	 *
	 * @param string $date
	 * @return boolean
	 */
	static function isValidDate($date)
	{
		if (is_null($date)) {
			return false;
		}
		if ($date == '0000-00-00' || $date == '0000-00-00 00:00:00') {
			return false;
		}
		if (!strtotime($date)) {
			return false;
		}
		return true;
	}

	/**
	 * return true is a time is valid (not null, or 00:00:00...)
	 *
	 * @param string $time
	 * @return boolean
	 */
	static function isValidTime($time)
	{
		if (is_null($time)) {
			return false;
		}

		if (!strtotime($time)) {
			return false;
		}
		return true;
	}

	static function loadCss($css)
	{
		$settings = self::retrieveCss();

		if($settings->get('css_'.$css.'_usecustom','0')) {

			# we want to use custom so now check if we've a file
			$file = $settings->get('css_'.$css.'_customfile');
			$is_file = false;


			# something was filled, now check if we've a valid file
			if ($file) {
				$file = preg_replace('%^/([^/]*)%', '$1', $file); // remove leading single slash
				$is_file = JFile::exists(JPATH_SITE.'/'.$file);

				if ($is_file) {
					# at this point we do have a valid file but let's check the extension too.
					$ext =  JFile::getExt($file);
					if ($ext != 'css') {
						# the file is valid but the extension not so let's return false
						$is_file = false;
					}
				}
			}

			if ($is_file) {
				# we do have a valid file so we will use it.
				$css = JHtml::_('stylesheet', $file, array(), false);
			} else {
				# unfortunately we don't have a valid file so we're looking at the default
				$css = JHtml::_('stylesheet', 'com_event_registration/'.$css.'.css', array(), true);
			}
		} else {
			# here we want to use the normal css
			$css = JHtml::_('stylesheet', 'com_event_registration/'.$css.'.css', array(), true);
		}

		return $css;
	}

	/**
	 * get a variable from the manifest file (actually, from the manifest cache).
	 *
	 * $column = manifest_cache(1),params(2)
	 * $setting = name of setting to retrieve
	 * $type = compononent(1), plugin(2)
	 * $name = name to search in column name
	 */
	static function getParam($column,$setting,$type,$name)
	{
		switch ($column) {
			case 1:
				$column = 'manifest_cache';
				break;
			case 2:
				$column = 'params';
				break;
		}

		switch ($type) {
			case 1:
				$type = 'component';
				break;
			case 2:
				$type = 'plugin';
				break;
			case 3:
				$type = 'module';
				break;
		}

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select(array($column));
		$query->from('#__extensions');
		$query->where(array('name = '.$db->quote($name),'type = '.$db->quote($type)));
		$db->setQuery($query);

		$manifest = json_decode($db->loadResult(), true);
		$result = $manifest[ $setting ];

		if (empty($result)) {
			$result = 'N/A';
		}
		return $result;
	}

	/**
	 * This method transliterates a string into a URL
	 * safe string or returns a URL safe UTF-8 string
	 * based on the global configuration
	 *
	 * @param   string  $string  String to process
	 *
	 * @return  string  Processed string
	 *
	 * @see     JApplication, JApplicationHelper
	 * @since   2.1.7
	 */
	public static function stringURLSafe($string)
	{
		if (version_compare(JVERSION, '3.2', 'ge')) {
			return JApplicationHelper::stringURLSafe($string);
		} else {
			return JApplication::stringURLSafe($string);
		}
	}
}
