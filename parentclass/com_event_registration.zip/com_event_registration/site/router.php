<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
defined('_JEXEC') or die;

function event_registrationBuildRoute(&$query)
{
	$segments = array();

	if (isset($query['view'])) {
		$segments[] = $query['view'];
		unset($query['view']);
	}

	if (isset($query['id'])) {
		$segments[] = $query['id'];
		unset($query['id']);
	};

	return $segments;
}

function event_registrationParseRoute($segments)
{
	$vars = array();

	// Count segments
	$count = count($segments);

	// Handle View and Identifier
	switch ($segments[0])
	{
		case 'event':
			{
				if ($count == 2) {
					$id = explode(':', $segments[1]);
					$vars['id'] = $id[0];
					$vars['view'] = 'event';
				} else {
					$vars['view'] = 'event';
				}
			}
			break;

		case 'eventslist':
			{
				$vars['view'] = 'eventslist';
			}
			break;
		
		default:
			{
				$vars['view'] = $segments[0];
			}
			break;
	}
	return $vars;
}
?>