<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

jimport('joomla.application.component.modellist');
// ensure Event_RegistrationFactory is loaded (because model is used by modules too)
require_once(JPATH_SITE.'/components/com_event_registration/factory.php');

/**
 * Model-Eventslist
 **/
class Event_RegistrationModelEventslist extends JModelList
{
	/**
	 * Constructor.
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
					'id', 'a.id',
					'title', 'a.title',
					'eventdate', 'a.eventdate',
					'starttime', 'a.starttime',
					'city', 'a.city',
					'state', 'a.state',
					'created', 'a.created',
					'created_by', 'a.created_by',
			);
		}
		parent::__construct($config);
	}


	/**
	 * Method to auto-populate the model state.
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		$app         = JFactory::getApplication();
		$event_registrationsettings = Event_RegistrationHelper::config();
		$jinput      = $app->input;
		$task        = $jinput->getCmd('task','');
		$format      = $jinput->getCmd('format',false);
		$itemid      = $jinput->getInt('id', 0) . ':' . $jinput->getInt('Itemid', 0);
		$user        = Event_RegistrationFactory::getUser();
		$userId      = $user->get('id');

		$params = $app->getParams();
		$this->setState('params', $params);

		$this->setState('filter.groupby',array('a.id'));

		parent::populateState('a.eventdate', 'ASC');
	}

	/**
	 * set limit
	 */
	function setLimit($value)
	{
		$this->setState('list.limit', 0);
	}

	/**
	 * Method to get a store id based on model configuration state.
	 */
	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('list.limit');
		return parent::getStoreId($id);
	}


	/**
	 * Build the query
	 */
	protected function getListQuery($type='NULL')
	{		
		$app       = JFactory::getApplication();
		$jinput    = JFactory::getApplication()->input;
		$task      = $jinput->getCmd('task', '');
		$itemid    = $jinput->getInt('id', 0) . ':' . $jinput->getInt('Itemid', 0);
		$params    = $app->getParams();
		$settings  = Event_RegistrationHelper::globalattribs();
		$user      = Event_RegistrationFactory::getUser();
		$this->setState('list.limit', 0);
		# Query
		$db 	= JFactory::getDBO();
		$query = $db->getQuery(true);

		# event
		$query->select(
				$this->getState(
				'list.select',	
				'a.created,a.created_by, a.eventdate,a.location,a.endtime, a.description,a.id, a.maxplaces,a.modified,a.modified_by,a.status,a.starttime,a.title,DAYOFMONTH(a.eventdate) AS created_day, YEAR(a.eventdate) AS created_year, MONTH(a.eventdate) AS created_month,count(b.event_id) as registered_users, b.status as user_map_status'
			)
		);
		$query->from('#__event_registration_events as a');
		
		$query->join('LEFT', $db->quoteName('#__event_registration_registered_users_map', 'b') . ' ON (' . $db->quoteName('a.id') . ' = ' . $db->quoteName('b.event_id') . ') and  b.status = 1');
		$query->where('a.status = 1');
		
		# Filter by a single or group of events.
		$eventId = $this->getState('filter.event_id');

		if (is_numeric($eventId)) {
			$type = $this->getState('filter.event_id.include', true) ? '= ' : '<> ';
			$query->where('a.id '.$type.(int) $eventId);
		}
		elseif (is_array($eventId) && !empty($eventId)) {
			JArrayHelper::toInteger($eventId);
			$eventId = implode(',', $eventId);
			$type = $this->getState('filter.event_id.include', true) ? 'IN' : 'NOT IN';
			$query->where('a.id '.$type.' ('.$eventId.')');
		}

		# Group
		$group = $this->getState('filter.groupby');
		if ($group) {
			$query->group($group);
		}

		# ordering
		$orderby = $this->getState('filter.orderby');

		if ($orderby) {
			$query->order($orderby);
		}
		//echo $query;exit;
		return $query;
	}

	
	/**
	 * Method to get a list of events.
	 */
	public function getItems()
	{
		$items	= parent::getItems();

		if (empty($items)) {
			return array();
		}

		$user	= Event_RegistrationFactory::getUser();
		$userId	= $user->get('id');
		$guest	= $user->get('guest');
		$groups = $user->getAuthorisedViewLevels();
		$input	= JFactory::getApplication()->input;

		# Get the global params
		$globalParams = JComponentHelper::getParams('com_event_registration', true);
		
		# Convert the parameter fields into objects.
		foreach ($items as $index => $item)
		{
			$eventParams = new JRegistry;

			$stateParams = $this->getState('params');
			if (empty($stateParams)) {
				$item->params = new JRegistry;
				$item->params->merge($eventParams);
			} else {
				$item->params = clone $stateParams;
				$item->params->merge($eventParams);
			}

		} // foreach
		return $items;
	}
}
?>