<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

/**
 * Event Registration user class with additional functions.
 * Because JUser::getInstance has different paramters on different versions
 *  we must split out class.
 *
 * @package Event Registration
 */
abstract class Event_RegistrationUserAbstract extends JUser
{
	/**
	 * @var    array  Event_RegistrationUser instances container.
	 */
	protected static $instances_event_registrationuser = array();


	static protected function _getInstance($id = 0)
	{
		$id = (int)$id;

		// Check if the user ID is already cached.
		if (empty(self::$instances_event_registrationuser[$id]) || !(self::$instances_event_registrationuser[$id] instanceof Event_RegistrationUser))
		{
			$user = new Event_RegistrationUser($id);
			self::$instances_event_registrationuser[$id] = $user;
		}

		return self::$instances_event_registrationuser[$id];
	}
}

if (version_compare(JVERSION, '3.4', 'lt')) {
	// on Joomla prior 3.4.0 getInstance expects only one parameter

	/**
	 * Event Registration user class with additional functions.
	 * Compatible with Joomla prior 3.4.0.
	 *
	 * @package Event Registration
	 *
	 * @see Event_RegistrationUserAbstract
	 */
	class Event_RegistrationUser extends Event_RegistrationUserAbstract
	{
		static function getInstance($id = 0)
		{
			return parent::_getInstance($id);
		}
	}

} else {
	// since Joomla 3.4.0 getInstance has a second parameter

	/**
	 * Event Registration user class with additional functions.
	 * Compatible with Joomla since 3.4.0.
	 *
	 * @package Event Registration
	 *
	 * @see Event_RegistrationUserAbstract
	 */
	class Event_RegistrationUser extends Event_RegistrationUserAbstract
	{
		static function getInstance($id = 0, JUserWrapperHelper $userHelper = null)
		{
			// we don't need this helper
			return parent::_getInstance($id);
		}
	}

}
