<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
defined('_JEXEC') or die;

// ensure Event_RegistrationFactory is loaded (because this class is used by modules or plugins too)
require_once(JPATH_SITE.'/components/com_event_registration/factory.php');

/**
 * Holds the logic for all output related things
 */
class Event_RegistrationOutput
{
	/**
	 * Creates the edit button
	 *
	 * @param int $Itemid
	 * @param int $id
	 * @param array $params
	 * @param int $allowedtoedit
	 * @param string $view
	 * @param string $IconText
	 *
	 * Views:
	 * Event
	 */
	static function editbutton($item, $params, $attribs, $allowedtoedit, $view,$IconText='Null')
	{
		if ($allowedtoedit) {
			$app = JFactory::getApplication();

			if ($app->input->get('print','','int')) {
				return;
			}

			// Ignore if the state is negative (trashed).
			if ($item->status < 0) {
				return;
			}

			// Initialise variables.
			$user   = Event_RegistrationFactory::getUser();
			$userId = $user->get('id');
			$uri    = JFactory::getURI();
			$settings = Event_RegistrationHelper::globalattribs();

			//JHtml::_('behavior.tooltip');

			// On Joomla Edit icon is always used regardless if "Show icons" is set to Yes or No.
			$showIcon = 1; //$settings->get('global_show_icons', 1);

			switch ($view)
			{
				case 'editevent':
					if (property_exists($item, 'checked_out') && property_exists($item, 'checked_out_time') && $item->checked_out > 0 && $item->checked_out != $userId) {
						$checkoutUser = JFactory::getUser($item->checked_out);
						$button = JHtml::_('image', 'system/checked_out.png', NULL, NULL, true);
						$date = JHtml::_('date', $item->checked_out_time);
						return '<span '.Event_RegistrationOutput::tooltip(JText::_('JLIB_HTML_CHECKED_OUT'), htmlspecialchars(JText::sprintf('COM_EVENT_REGISTRATION_GLOBAL_CHECKED_OUT_BY', $checkoutUser->name).' <br /> '.$date, ENT_COMPAT, 'UTF-8')).'>'.$button.'</span>';
					}

					if ($showIcon) {
						$image = JHtml::_('image', 'com_event_registration/calendar_edit.png', JText::_('COM_EVENT_REGISTRATION_EDIT_EVENT'), NULL, true);
					}else {
						$image = JText::_('COM_EVENT_REGISTRATION_EDIT_EVENT');
					}
					if ($IconText != 'Null'){
						$image = $IconText;
					}
					$id = isset($item->did) ? $item->did : $item->id;
					$url = 'index.php?option=com_event_registration&task=event.edit&a_id='.$id.'&return='.base64_encode($uri);
				break;
			}

			if (!$url) {
				return; // we need at least url to generate useful output
			}

			$output = JHtml::_('link', JRoute::_($url), $image, '');

			return $output;
		}
	}

	/**
	 * Formats date
	 *
	 * @param string $date
	 * @param string $format
	 * @return string $formatdate
	 */
	static function formatdate($date, $format = "")
	{
		$settings 	= Event_RegistrationHelper::config();
		$check 		= Event_RegistrationHelper::isValidDate($date);
		$timezone	= null;

		if ($check == true) {
			$jdate = new JDate($date,$timezone);
			if (!$format) {
				// If no format set, use long format as standard
				$format = $settings->formatdate;
			}

			return $jdate->format($format);
		} else {
			return false;
		}
	}

	/**
	 * Formats time
	 *
	 * @param string $time
	 * @return string $formattime
	 */
	static function formattime($time, $format = "", $addSuffix = true)
	{
		$settings	= Event_RegistrationHelper::config();
		$check 		= Event_RegistrationHelper::isValidTime($time);

		if (!$check)
		{
			return;
		}

		if(!$format) {
			// If no format set, use settings format as standard
			$format = $settings->formattime;
		}

		$formattedTime = strftime($format, strtotime($time));

		if ($addSuffix && !empty($settings->timename)) {
			$formattedTime .= ' '.$settings->timename;
		}

		return $formattedTime;
	}

	/**
	 * Formats the input dates and times to be used as a from-to string for
	 * events. Takes care of unset dates and or times.
	 * Values can be styled using css classes Event_Registration_date-1 and Event_Registration_time-1.
	 *
	 * @param  mixed  $dateStart Start date of event or an associative array with keys contained in
	 *                           {'dateStart','timeStart','dateEnd','timeEnd','dateFormat','timeFormat','addSuffix','showTime'}
	 *                           and values corresponding to parameters of the same name.
	 * @param  string $timeStart Start time of event
	 * @param  string $dateEnd End date of event
	 * @param  string $timeEnd End time of event
	 * @param  string $dateFormat Date Format
	 * @param  string $timeFormat Time Format
	 * @param  bool   $addSuffix if true add suffix specified in settings
	 * @param  bool   $showTime global setting to respect
	 * @return string Formatted date and time string to print
	 */
	static function formatDateTime($dateStart, $timeStart ='', $dateEnd = '', $timeEnd = '', $dateFormat = '', $timeFormat = '', $addSuffix = true, $showTime = true)
	{
		if (is_array($dateStart)) {
			foreach (array('timeStart','dateEnd','timeEnd','dateFormat','timeFormat','addSuffix','showTime') as $param) {
				if (isset($dateStart[$param])) {
					$$param = $dateStart[$param];
				}
			}
			$dateStart = isset($dateStart['dateStart']) ? $dateStart['dateStart'] : '';
		}

		$output = '';

		if (Event_RegistrationHelper::isValidDate($dateStart)) {
			$output .= '<span class="event_registration_date-1">'.self::formatdate($dateStart, $dateFormat).'</span>';

			if ($showTime && Event_RegistrationHelper::isValidTime($timeStart)) {
				$output .= ', <span class="event_registration_time-1">'.self::formattime($timeStart, $timeFormat, $addSuffix).'</span>';
			}

			// Display end date only when it differs from start date
			$displayDateEnd = Event_RegistrationHelper::isValidDate($dateEnd) && $dateEnd != $dateStart;
			if ($displayDateEnd) {
				$output .= ' - <span class="event_registration_date-1">'.self::formatdate($dateEnd, $dateFormat).'</span>';
			}

			// Display end time only when both times are set
			if ($showTime && Event_RegistrationHelper::isValidTime($timeStart) && Event_RegistrationHelper::isValidTime($timeEnd))
			{
				$output .= $displayDateEnd ? ', ' : ' - ';
				$output .= '<span class="event_registration_time-1">'.self::formattime($timeEnd, $timeFormat, $addSuffix).'</span>';
			}
		} else {
			$output .= '<span class="event_registration_date-1">'.JText::_('COM_EVENT_REGISTRATION_OPEN_DATE').'</span>';

			if ($showTime) {
				if (Event_RegistrationHelper::isValidTime($timeStart)) {
					$output .= ', <span class="event_registration_time-1">'.self::formattime($timeStart, $timeFormat, $addSuffix).'</span>';

					// Display end time only when both times are set
					if (Event_RegistrationHelper::isValidTime($timeEnd)) {
						$output .= ' - <span class="event_registration_time-1">'.self::formattime($timeEnd, $timeFormat, $addSuffix).'</span>';
					}
				}
			}
		}

		return $output;
	}

	/**
	 * Formats the input dates and times to be used as a from-to string for
	 * events. Takes care of unset dates and or times.
	 * First line is for (short) date, second line for time values.
	 * Lines can be styled using css classes event_registration_date-2 and event_registration_time-2.
	 *
	 * @param  mixed  $dateStart Start date of event or an associative array with keys contained in
	 *                           {'dateStart','timeStart','dateEnd','timeEnd','dateFormat','timeFormat','addSuffix','showTime'}
	 *                           and values corresponding to parameters of the same name.
	 * @param  string $timeStart Start time of event
	 * @param  string $dateEnd End date of event
	 * @param  string $timeEnd End time of event
	 * @param  string $dateFormat Date Format
	 * @param  string $timeFormat Time Format
	 * @param  bool   $addSuffix if true add suffix specified in settings
	 * @param  bool   $showTime global setting to respect
	 * @return string Formatted date and time string to print
	 */
	static function formatDateTime2Lines($dateStart, $timeStart = '', $dateEnd = '', $timeEnd = '', $dateFormat = '', $timeFormat = '', $addSuffix = true, $showTime = true)
	{
		if (is_array($dateStart)) {
			foreach (array('timeStart','dateEnd','timeEnd','dateFormat','timeFormat','addSuffix','showTime') as $param) {
				if (isset($dateStart[$param])) {
					$$param = $dateStart[$param];
				}
			}
			$dateStart = isset($dateStart['dateStart']) ? $dateStart['dateStart'] : '';
		}

		$output = '';
		$event_registrationconfig = Event_RegistrationHelper::config();

		if (empty($dateFormat)) {
			// Use format saved in settings if specified or format in language file otherwise
			$dateFormat = empty($event_registrationconfig->formatShortDate) ? JText::_('COM_EVENT_REGISTRATION_FORMAT_SHORT_DATE') : $event_registrationconfig->formatShortDate;
		}

		if (Event_RegistrationHelper::isValidDate($dateStart)) {
			$outDate = self::formatdate($dateStart, $dateFormat);

			if (Event_RegistrationHelper::isValidDate($dateEnd) && ($dateEnd != $dateStart)) {
				$outDate .= ' - ' . self::formatdate($dateEnd, $dateFormat);
			}
		} else {
			$outDate = JText::_('COM_EVENT_REGISTRATION_OPEN_DATE');
		}

		if ($showTime && Event_RegistrationHelper::isValidTime($timeStart)) {
			$outTime = self::formattime($timeStart, $timeFormat, $addSuffix);

			if (Event_RegistrationHelper::isValidTime($timeEnd)) {
				$outTime .= ' - ' . self::formattime($timeEnd, $timeFormat, $addSuffix);
			}
		}

		$output = '<span class="event_registration_date-2">' . $outDate . '</span>';
		if (!empty($outTime)) {
			$output .= '<br class="event_registration_break-2"><span class="event_registration_time-2">' . $outTime . '</span>';
		}
		return $output;
	}

	/**
	 * Formats the input dates and times to be used as a long from-to string for
	 * events. Takes care of unset dates and or times.
	 *
	 * @param  string $dateStart Start date of event or an associative array with keys contained in
	 *                           {'dateStart','timeStart','dateEnd','timeEnd','showTime'}
	 *                           and values corresponding to parameters of the same name.
	 * @param  mixed  $timeStart Start time of event
	 * @param  string $dateEnd End date of event
	 * @param  string $timeEnd End time of event
	 * @param  bool   $showTime global setting to respect
	 * @return string Formatted date and time string to print
	 */
	static function formatLongDateTime($dateStart, $timeStart = '', $dateEnd = '', $timeEnd = '', $showTime = true)
	{
		return self::formatDateTime(is_array($dateStart) ? $dateStart : array('dateStart' => $dateStart, 'timeStart' => $timeStart, 'dateEnd' => $dateEnd, 'timeEnd' => $timeEnd, 'addSuffix' => true, 'showTime' => $showTime));
	}

	/**
	 * Formats the input dates and times to be used as a short from-to string for
	 * events. Takes care of unset dates and or times.
	 *
	 * @param  string $dateStart Start date of event or an associative array with keys contained in
	 *                           {'dateStart','timeStart','dateEnd','timeEnd','showTime'}
	 *                           and values corresponding to parameters of the same name.
	 * @param  mixed  $timeStart Start time of event
	 * @param  string $dateEnd End date of event
	 * @param  string $timeEnd End time of event
	 * @param  bool   $showTime global setting to respect
	 * @return string Formatted date and time string to print
	 */
	static function formatShortDateTime($dateStart, $timeStart = '', $dateEnd = '', $timeEnd = '', $showTime = true)
	{
		$settings = Event_RegistrationHelper::config();

		$params = is_array($dateStart) ? $dateStart : array('dateStart' => $dateStart, 'timeStart' => $timeStart, 'dateEnd' => $dateEnd, 'timeEnd' => $timeEnd, 'showTime' => $showTime);
		$params['addSuffix'] = true;
		// Use format saved in settings if specified or format in language file otherwise
		$params['dateFormat'] = (isset($settings->formatShortDate) && $settings->formatShortDate) ? $settings->formatShortDate : JText::_('COM_EVENT_REGISTRATION_FORMAT_SHORT_DATE');

		if (isset($settings->datemode) && ($settings->datemode == 2)) {
			return self::formatDateTime2Lines($params);
		} else {
			return self::formatDateTime($params);
		}
	}

	static function formatSchemaOrgDateTime($dateStart, $timeStart = '', $dateEnd = '', $timeEnd = '', $showTime = true)
	{
		if (is_array($dateStart)) {
			foreach (array('timeStart','dateEnd','timeEnd','showTime') as $param) {
				if (isset($dateStart[$param])) {
					$$param = $dateStart[$param];
				}
			}
			$dateStart = isset($dateStart['dateStart']) ? $dateStart['dateStart'] : '';
		}

		$output  = '';
		$formatD = 'Y-m-d';
		$formatT = '%H:%M';

		if (Event_RegistrationHelper::isValidDate($dateStart)) {
			$content = self::formatdate($dateStart, $formatD);

			if ($showTime && $timeStart) {
				$content .= 'T'.self::formattime($timeStart, $formatT, false);
			}
			$output .= '<meta itemprop="startDate" content="'.$content.'" />';

			if (Event_RegistrationHelper::isValidDate($dateEnd)) {
				$content = self::formatdate($dateEnd, $formatD);

				if ($showTime && $timeEnd) {
					$content .= 'T'.self::formattime($timeEnd, $formatT, false);
				}
				$output .= '<meta itemprop="endDate" content="'.$content.'" />';
			}
		} else {
			// Open date

			if ($showTime) {
				if ($timeStart) {
					$content = self::formattime($timeStart, $formatT, false);
					$output .= '<meta itemprop="startDate" content="'.$content.'" />';
				}
				// Display end time only when both times are set
				if ($timeStart && $timeEnd) {
					$content .= self::formattime($timeEnd, $formatT, false);
					$output .= '<meta itemprop="endDate" content="'.$content.'" />';
				}
			}
		}
		return $output;
	}
}
?>
