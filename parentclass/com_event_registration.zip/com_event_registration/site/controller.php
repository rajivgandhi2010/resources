<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

jimport('joomla.application.component.controller');

/**
 * Event Registration Component Controller
 *
 * @package Event Registration
 *
 */
class Event_RegistrationController extends JControllerLegacy
{
	/**
	 * Constructor
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Display the view
	 */
	function display($cachable = false, $urlparams = false)
	{
		
		$document   = JFactory::getDocument();
		$user       = Event_RegistrationFactory::getUser();

		// Set the default view name and format from the Request.
		$jinput     = JFactory::getApplication()->input;
		$id         = $jinput->getInt('a_id', 0);
		$viewName   = $jinput->getCmd('view', 'eventslist');
		$viewFormat = $document->getType();
		$layoutName = $jinput->getCmd('layout', 'edit');

		// Check for edit form.
		if ($viewName == 'editevent' && !$this->checkEditId('com_event_registration.edit.event', $id)) {
			// Somehow the person just went to the form - we don't allow that.
			return JError::raiseError(403, JText::sprintf('JLIB_APPLICATION_ERROR_UNHELD_ID', $id));
		}

		$view = $this->getView($viewName, $viewFormat);
		if ($view) {
			// Do any specific processing by view.
			switch ($viewName) {
				case 'editevent':
				case 'event':
				case 'eventslist':
					$model = $this->getModel($viewName);
					break;
				default:
					$model = $this->getModel('eventslist');
					break;
			}

			$view->setModel($model, true);

			$view->setLayout($layoutName);

			// Push document object into the view.
			$view->document = $document;

			$view->display();
		}
	}

	
}
?>