<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

?>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$('#all-events').DataTable({
			"order": [[ 2, "asc" ]],
			responsive: true,
			columnDefs: [
				{ targets: [0, 1,3,4,5,6], orderable: false}
			],
			dom: 'Bfrtip',
			lengthMenu: [
				[ 10, 25, 50, -1 ],
				[ '10 rows', '25 rows', '50 rows', 'Show all' ]
			],
			buttons: [
				'pageLength',
				{
					extend: 'excelHtml5',
					exportOptions: {
						columns: [ 0, 1, 2, 3, 5 ]
					}
				},
				{
					extend: 'pdfHtml5',
					exportOptions: {
						columns: [ 0, 1, 2, 3, 5 ]
					}
				},
				{
					extend: 'print',
					exportOptions: {
						columns: [ 0, 1, 2, 3, 5 ]
					}
				}
			]
		});
	});
</script>

<table class="eventtable table-bordered table-striped" id="all-events" style="width:<?php echo $this->event_registrationsettings->tablewidth; ?>;" summary="event_registration">
	<thead>
		<tr>
			<th id="event_registration_title" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTRATION_TABLE_TITLE'); ?></th>
			<th id="event_registration_location" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTRATION_TABLE_LOCATION'); ?></th>
			<th id="event_registration_date" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTRATION_TABLE_DATE'); ?></th>
			<th id="event_registration_time" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTRATION_TABLE_TIME'); ?></th>
			<th id="event_registration_update" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTRATION_TABLE_UPDATE_EVENT'); ?></th>
			<th id="event_registration_view" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTRATION_TABLE_VIEW_REGISTRANTS'); ?></th>
			<th id="event_registration_signup" class="sectiontableheader" align="left"><?php echo JText::_('COM_EVENT_REGISTRATION_TABLE_SIGNUP'); ?></th>
		</tr>
	</thead>

	<tbody>
		<?php if ($this->noevents == 1) : ?>
			<tr align="center"><td colspan="20"><?php echo JText::_('COM_EVENT_REGISTRATION_NO_EVENTS'); ?></td></tr>
		<?php else : ?>
			<?php $this->rows = $this->getRows(); ?>
			<?php foreach ($this->rows as $row) : ?>
			
				<td headers="event_registration_title" align="left" valign="top" itemprop="name">
					<?php echo $this->escape($row->title); ?>
				</td>
				
				<td headers="event_registration_location" align="left" valign="top" >
					<?php echo $this->escape($row->location); ?>
				</td>

				<td headers="event_registration_date" align="left">
					<?php echo $this->escape($row->eventdate); ?>
				</td>
				
				<td headers="event_registration_time" align="left">
					<?php echo $this->escape($row->starttime); ?>
				</td>
				
				<td headers="event_registration_update" align="center">
					<?php echo Event_RegistrationOutput::editbutton($row, '', '', true, 'editevent','Update'); ?>
				</td>
				
				<td headers="event_registration_view" align="center">
					<?php
						echo ($row->registered_users >0) ? '<a href="event/users/'.$row->id.'">'.$row->registered_users.'</a>' : $row->registered_users;
					?>
				</td>
				
				<td headers="event_registration_signup" align="center">
					<?php if($row->registered_users < $row->maxplaces) { ?>
						<a href="event/signup/<?php echo $this->escape($row->id); ?>">Sign up</a>
					<?php } else { ?>
						<a href="" class="not_allowed">Sign up</a>
					<?php } ?>
				</td>
			</tr>
			<?php endforeach; ?>
		<?php endif; ?>
	</tbody>
</table>