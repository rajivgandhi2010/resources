<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
defined('_JEXEC') or die;

// Create shortcut to parameters.
$params		= $this->params;
?>

<script type="text/javascript">
	Joomla.submitbutton = function(task) {
		if (document.formvalidator.isValid(document.id('adminForm'))) {
			jQuery.confirm({
				title: 'Submit Confirmation',
				content: 'Are you sure?',
				buttons: {
					'Yes': {
						text: 'Yes',
						btnClass: 'btn-success',
						action: function () {
							Joomla.submitform(task);
						}
					},
					'No': {
						text: 'No',
						btnClass: 'btn-red',
						action: function () {
							//return false;
						}
					},
				}
			});
		} else {
		}
	}
</script>

<script type="text/javascript">
jQuery( document ).ready(function($) {
	$("#jform_eventdate").attr("readonly","readonly");
	
	//zip code validation
	document.formvalidator.setHandler('zip', function (value) {
		return (/(^\d{5}$)|(^\d{5}-\d{4}$)/).test(value);
	});
	
	//On Cancel Button Click
	$("#cancelbutton").confirm({
		title: 'Cancel Confirmation',
		content: 'Are you sure?',
		buttons: {
			'Yes': {
				text: 'Yes',
				btnClass: 'btn-success',
				action: function () {
					window.location.href = "<?php echo JURI::base(); ?>events";
				}
			},
			'No': {
				text: 'No',
				btnClass: 'btn-red',
				action: function () {
					//return false;
				}
			},
		}
	});
	
    $("#jform_noofparticipants").keydown(function (e) {
		if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 || (e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) ||(e.keyCode >= 35 && e.keyCode <= 40)) 
		{
			return;
		}
		// Ensure that it is a number and stop the keypress
		if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
			e.preventDefault();
		}
	});
	
	/*Comments validaion
	* Not allow user to enter more than 150 characters
	*/
	$("#jform_description").keyup(function (e) {
		description_value = $(this);
		if(description_value.val().length >= 150){
			description_value.val( description_value.val().substr(0, 150) );
		}
	});
	
	/**Timepicker**/
	$('#jform_starttime').timepicker();
	$('#jform_endtime').timepicker({
		'maxTime': '11:30pm'
	});
	$('#jform_starttime').on('changeTime', function() {
		$('#endtime_div').css('display','block');
		$('#jform_endtime').timepicker('setTime', $(this).val());
		$('#jform_endtime').timepicker('option',{'minTime': $(this).val()});
	});
	
});
</script>

<div id="event_registration" class="event_registration_editevent<?php echo $this->pageclass_sfx; ?>">
	<div class="edit item-page">
		<?php if ($params->get('show_page_heading')) : ?>
			<h1><?php echo $this->escape($params->get('page_heading')); ?></h1>
		<?php endif; ?>

		<form enctype="multipart/form-data" action="<?php echo JRoute::_('index.php?option=com_event_registration&a_id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate form-horizontal">
			<fieldset class="adminform">
				
				<div class="form-group">			  
					<div class="col-md-4">
						<?php echo $this->form->getLabel('title'); ?>
						<?php echo $this->form->getInput('title'); ?>				
					</div>
					<div class="col-md-4">
						<?php echo $this->form->getLabel('location'); ?>
						<?php echo $this->form->getInput('location'); ?>			
					</div>
					<div class="col-md-4">
						<?php echo $this->form->getLabel('address'); ?>
						<?php echo $this->form->getInput('address'); ?>
					</div>
				</div>
				
				<div class="form-group">			  
					<div class="col-md-4">
						<?php echo $this->form->getLabel('city'); ?>
						<?php echo $this->form->getInput('city'); ?>				
					</div>
					<div class="col-md-4">
						<?php echo $this->form->getLabel('state'); ?>
						<?php echo $this->form->getInput('state'); ?>			
					</div>
					<div class="col-md-4">
						<?php echo $this->form->getLabel('zip'); ?>
						<?php echo $this->form->getInput('zip'); ?>
					</div>
				</div>
				
				<div class="form-group">			  
					<div class="col-md-4">
						<?php echo $this->form->getLabel('eventdate'); ?>
						<?php echo $this->form->getInput('eventdate'); ?>				
					</div>
					<div class="col-md-4">
						<?php echo $this->form->getLabel('starttime'); ?>
						<?php echo $this->form->getInput('starttime'); ?>			
					</div>
					<div class="col-md-4">
						<?php echo $this->form->getLabel('endtime'); ?>
						<?php echo $this->form->getInput('endtime'); ?>
					</div>
				</div>
				
				<div class="form-group">			  
					<div class="col-md-4">
						<?php echo $this->form->getLabel('maxplaces'); ?>
						<?php echo $this->form->getInput('maxplaces'); ?>				
					</div>
					<div class="col-md-8">
						<?php echo $this->form->getLabel('description'); ?>
						<?php echo $this->form->getInput('description'); ?>			
					</div>
				</div>
				
				<div class="form-group button-div">			 
					<div class="col-md-12 text-center">
						<button type="button" class="btn btn-success" id="submitbutton" onclick="Joomla.submitbutton('event.save')"><?php echo JText::_('JSAVE') ?></button>
						<button type="button" class="btn btn-success" id="cancelbutton"><?php echo JText::_('JCANCEL') ?></button>
					</div>
				</div>
			</fieldset>			

			<input type="hidden" name="task" value="" />
			<input type="hidden" name="return" value="<?php echo $this->return_page;?>" />
			<?php if($this->params->get('enable_category', 0) == 1) :?>
			<input type="hidden" name="jform[catid]" value="<?php echo $this->params->get('catid', 1);?>"/>
			<?php endif;?>
			<?php echo JHtml::_('form.token'); ?>
		</form>
	</div>
</div>
