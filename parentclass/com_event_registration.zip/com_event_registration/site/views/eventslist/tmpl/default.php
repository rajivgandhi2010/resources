<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
defined('_JEXEC') or die;

?>
<div id="event_registration" class="event_registration_eventslist<?php echo $this->pageclass_sfx;?>">
	<?php if ($this->params->get('show_page_heading', 1)) : ?>
		<h1 class="componentheading">
			<?php echo $this->escape($this->params->get('page_heading')); ?>
		</h1>
	<?php endif; ?>

	<div class="clr"></div>

	<?php if ($this->params->get('showintrotext')) : ?>
		<div class="description no_space floattext">
			<?php echo $this->params->get('introtext'); ?>
		</div>
	<?php endif; ?>

	<form action="<?php echo htmlspecialchars($this->action); ?>" method="post" name="adminForm" id="adminForm">
		<?php
			$options = array(
				'startOffset' => 0,  // 0 starts on the first tab, 1 starts the second, etc...
				'useCookie' => false, // this must not be a string. Don't use quotes.
			);
		?>
		<?php echo JHtml::_('tabs.start', 'det-pane', $options); ?>
		
		<!-- PRESENT EVENTS TAB -->
		<?php echo JHtml::_('tabs.panel',JText::_('COM_EVENT_REGISTRATION_PRESENT_EVENT_TAB'), 'present-eventtab' ); ?>
			<?php echo $this->loadTemplate('events_table'); ?>
			
		<!-- PAST EVENTS TAB -->
		<?php echo JHtml::_('tabs.panel',JText::_('COM_EVENT_REGISTRATION_PAST_EVENT_TAB'), 'past-eventtab' ); ?>
			<?php echo $this->loadTemplate('pastevents_table'); ?>
			
		<!-- FUTURE EVENTS TAB -->
		<?php echo JHtml::_('tabs.panel',JText::_('COM_EVENT_REGISTRATION_FUTURE_EVENT_TAB'), 'future-eventtab' ); ?>
			<?php echo $this->loadTemplate('futureevents_table'); ?>
			
		<!-- ALL EVENTS TAB -->
		<?php echo JHtml::_('tabs.panel',JText::_('All'), 'all-eventtab' ); ?>
			<?php echo $this->loadTemplate('allevents_table'); ?>
			

		<input type="hidden" name="task" value="<?php echo $this->task; ?>" />
		<input type="hidden" name="view" value="eventslist" />
	</form>

	<?php if ($this->params->get('showfootertext')) : ?>
		<div class="description no_space floattext">
			<?php echo $this->params->get('footertext'); ?>
		</div>
	<?php endif; ?>
</div>