<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
defined('_JEXEC') or die;

require JPATH_COMPONENT_SITE.'/classes/view.class.php';

/**
 * Eventslist-View
*/
class Event_RegistrationViewEventslist extends Event_RegistrationView
{
	function __construct($config = array())
	{
		parent::__construct($config);

		// additional path for common templates + corresponding override path
		$this->addCommonTemplatePath();
	}

	/**
	 * Creates the Simple List View
	 */
	function display($tpl = null)
	{
		// Initialize variables
		$app         = JFactory::getApplication();
		$event_registrationsettings = Event_RegistrationHelper::config();
		$settings    = Event_RegistrationHelper::globalattribs();
		$menu        = $app->getMenu();
		$menuitem    = $menu->getActive();
		$document    = JFactory::getDocument();
		$params      = $app->getParams();
		$uri         = JFactory::getURI();
		$jinput      = $app->input;
		$task        = $jinput->getCmd('task', '');
		$pathway     = $app->getPathWay();
		$user        = Event_RegistrationFactory::getUser();
		$itemid      = $jinput->getInt('id', 0) . ':' . $jinput->getInt('Itemid', 0);

		// Load css
		Event_RegistrationHelper::loadCss('event_registration');
		Event_RegistrationHelper::loadCss('dataTables.jqueryui');
		Event_RegistrationHelper::loadCss('jquery-confirm');
		JHtml::stylesheet('com_eventregister/responsive.dataTables.min.css', array(), true);
		
		//Datatable export CSS
		Event_RegistrationHelper::loadCss('buttons.dataTables.min');
		
		
		JHtml::_('jquery.framework');
		$document->addScript('media/com_event_registration/js/jquery.dataTables.js');
		$document->addScript('media/com_event_registration/js/jquery-confirm.js');
		
		//Datatable export JS
		$document->addScript('media/com_event_registration/js/datatable/dataTables.buttons.min.js');
		$document->addScript('media/com_event_registration/js/datatable/buttons.flash.min.js');
		$document->addScript('media/com_event_registration/js/datatable/jszip.min.js');
		$document->addScript('media/com_event_registration/js/datatable/pdfmake.min.js');
		$document->addScript('media/com_event_registration/js/datatable/vfs_fonts.js');
		$document->addScript('media/com_event_registration/js/datatable/buttons.html5.min.js');
		$document->addScript('media/com_event_registration/js/datatable/buttons.print.min.js');
		$document->addScript('media/com_eventregister/js/datatable/dataTables.responsive.min.js');

		// Get data from model
		$rows = $this->get('Items');

		// Are events available?
		$noevents = (!$rows) ? 1 : 0;

		// params
		$pagetitle     = $params->def('page_title', $menuitem ? $menuitem->title : JText::_('COM_EVENT_REGISTRATION_EVENTS'));
		$pageheading   = $params->def('page_heading', $params->get('page_title'));
		$pageclass_sfx = $params->get('pageclass_sfx');

		// pathway
		if ($menuitem) {
			$pathway->setItemName(1, $menuitem->title);
		}

		// Add site name to title if param is set
		if ($app->getCfg('sitename_pagetitles', 0) == 1) {
			$pagetitle = JText::sprintf('JPAGETITLE', $app->getCfg('sitename'), $pagetitle);
		}
		elseif ($app->getCfg('sitename_pagetitles', 0) == 2) {
			$pagetitle = JText::sprintf('JPAGETITLE', $pagetitle, $app->getCfg('sitename'));
		}

		// Set Page title
		$document->setTitle($pagetitle);
		$document->setMetaData('title' , $pagetitle);

		// add alternate feed link
		$link    = 'index.php?option=com_event_registration&view=eventslist&format=feed';
		$attribs = array('type' => 'application/rss+xml', 'title' => 'RSS 2.0');
		$document->addHeadLink(JRoute::_($link.'&type=rss'), 'alternate', 'rel', $attribs);
		$attribs = array('type' => 'application/atom+xml', 'title' => 'Atom 1.0');
		$document->addHeadLink(JRoute::_($link.'&type=atom'), 'alternate', 'rel', $attribs);

		//$this->lists			= $lists;
		$this->rows				= $rows;
		$this->noevents			= $noevents;
		$this->params			= $params;
		$this->action			= $uri->toString();
		$this->task				= $task;
		$this->event_registrationsettings		= $event_registrationsettings;
		$this->settings			= $settings;
		$this->pagetitle		= $pagetitle;
		$this->pageclass_sfx	= htmlspecialchars($pageclass_sfx);

		$this->_prepareDocument();
		parent::display($tpl);
	}

	/**
	 * Prepares the document
	 */
	protected function _prepareDocument()
	{
		// TODO: Refactor with parent _prepareDocument() function

		$app	= JFactory::getApplication();
		$menus	= $app->getMenu();
		$title	= null;

		if ($this->params->get('menu-meta_description'))
		{
			$this->document->setDescription($this->params->get('menu-meta_description'));
		}

		if ($this->params->get('menu-meta_keywords'))
		{
			$this->document->setMetadata('keywords', $this->params->get('menu-meta_keywords'));
		}

		if ($this->params->get('robots'))
		{
			$this->document->setMetadata('robots', $this->params->get('robots'));
		}
	}
	
	
}
?>
