<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers');

// Create shortcuts to some parameters.
$params  = $this->item->params;

?>
<div id="event_registration" class="event_id<?php echo $this->item->did; ?> event_registration_event<?php echo $this->pageclass_sfx;?>"
	itemscope="itemscope" itemtype="http://schema.org/Event">

	<!-- Event -->
	<h2 class="event_registration">
		<?php
			echo JText::_('COM_EVENT_REGISTRATION_EVENT');
			echo Event_RegistrationOutput::editbutton($this->item, $params, '', 1, 'editevent');
		?>
	</h2>
	<div class="row">
		<div class="col-md-12">
			<form class="form-horizontal">

				<div class="form-group">
				  <div class="col-md-3">
					 <label class="control-label" for="textinput"><?php echo JText::_('COM_EVENT_REGISTRATION_TITLE'); ?></label>      
				  </div> 
				  <div class="col-md-9">
					<?php echo $this->escape($this->item->title); ?> 
				  </div>
				</div>

				<div class="form-group">
				  <div class="col-md-3">
					 <label class="control-label"><?php echo JText::_('COM_EVENT_REGISTRATION_WHEN'); ?></label>      
				  </div> 
				  <div class="col-md-9">
					<?php echo Event_RegistrationOutput::formatLongDateTime($this->item->eventdate, $this->item->starttime,$this->item->eventdate, $this->item->endtime);	?>   
				  </div>
				</div>

				<div class="form-group">
				  <div class="col-md-3">
					 <label class="control-label"><?php echo JText::_('COM_EVENT_REGISTRATION_WHERE'); ?></label>      
				  </div> 
				  <div class="col-md-9">
					<?php echo $this->escape($this->item->location); ?>
				  </div>
				</div>
				
				<div class="form-group">
				  <div class="col-md-3">
					 <label class="control-label"><?php echo JText::_('COM_EVENT_REGISTRATION_EDITEVENT_FIELD_CITY'); ?></label>      
				  </div> 
				  <div class="col-md-9">
					<?php echo $this->escape($this->item->city); ?>
				  </div>
				</div>
				
				<div class="form-group">
				  <div class="col-md-3">
					 <label class="control-label"><?php echo JText::_('COM_EVENT_REGISTRATION_EDITEVENT_FIELD_STATE'); ?></label>      
				  </div> 
				  <div class="col-md-9">
					<?php echo $this->escape($this->item->state); ?>
				  </div>
				</div>
				
				<div class="form-group">
				  <div class="col-md-3">
					 <label class="control-label"><?php echo JText::_('COM_EVENT_REGISTRATION_EDITEVENT_FIELD_ZIP'); ?></label>      
				  </div> 
				  <div class="col-md-9">
					<?php echo $this->escape($this->item->zip); ?>
				  </div>
				</div>
				
				<div class="form-group">
				  <div class="col-md-3">
					 <label class="control-label"><?php echo JText::_('COM_EVENT_REGISTRATION_EDITEVENT_FIELD_PARTICIPANTS'); ?></label>      
				  </div> 
				  <div class="col-md-9">
					<?php echo $this->escape($this->item->maxplaces); ?>
				  </div>
				</div>

				
			 
			</form>
		</div>
	</div>

	<!-- DESCRIPTION -->
	<?php if ($params->get('event_show_description','1') && ($this->item->description != '' && $this->item->description != '<br />' || $this->item->description != '' && $this->item->description != '<br />')) { ?>
		<h2 class="description event_registration"><?php echo JText::_('COM_EVENT_REGISTRATION_EVENT_DESCRIPTION'); ?></h2>
		<div class="description event_desc" itemprop="description">
			<?php	echo $this->item->description;?>
		</div>
	<?php } ?>
	<br/><br/><br/><br/>
</div>