<?php
/**
 * @version 1.0
 * @package Event Registration
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

// Can't use JPATH_COMPONENT_SITE because factory maybe used in module or plugin!
require_once (JPATH_SITE.'/components/com_event_registration/classes/user.class.php');
require_once (JPATH_SITE.'/components/com_event_registration/classes/config.class.php');


/**
 * Event Registration Factory class
 *
 * @package  Event Registration
 * @since    2.1.5
 */
abstract class Event_RegistrationFactory extends JFactory
{
	/**
	 * Get a Event Registration user object.
	 *
	 * Returns the global {@link Event_RegistrationUser} object, only creating it if it doesn't already exist.
	 *
	 * @param   integer  $id  The user to load - Must be an integer or null for current user.
	 *
	 * @return  Event_RegistrationUser object
	 *
	 * @see     Event_RegistrationUser
	 * @since   2.1.5
	 */
	public static function getUser($id = null)
	{
		if (is_null($id))
		{
			$instance = self::getSession()->get('user');
			$id = ($instance instanceof JUser) ? $instance->id : 0;
		}

		return Event_RegistrationUser::getInstance($id);
	}

	/**
	 * Get the Event Registration configuration object.
	 *
	 * Returns the global {@link Event_RegistrationConfig} object, only creating it if it doesn't already exist.
	 *
	 * @return  Event_RegistrationConfig object
	 *
	 * @note    Because parent's getConfig() is limited to php files we don't override this function.
	 *
	 * @see     Event_RegistrationConfig
	 * @since   2.1.6
	 */
	public static function getEvent_RegistrationConfig()
	{
		return Event_RegistrationConfig::getInstance();
	}

	/**
	 * Get the dispatcher.
	 *
	 * Returns the static {@link JDispatcher} or {@link JEventDispatcher} object, depending on Joomla version.
	 *
	 * @return  JDispatcher or JEventDispatcher object
	 *
	 * @see     JDispatcher, JEventDispatcher
	 * @since   2.1.7
	 */
	public static function getDispatcher()
	{
		if (version_compare(JVERSION, '3.0', 'ge')) {
			return JEventDispatcher::getInstance();
		} else {
			return JDispatcher::getInstance();
		}
	}
}
