<?php
/**
 * @version 1.0
 * @package Event Search Module
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

$document = JFactory::getDocument();

$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/dataTables.jqueryui.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/datepicker.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/icons.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/buttons.dataTables.min.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/responsive.dataTables.min.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/search_form.css' );
?>

<form class="event_search_form form-horizontal" name="event_search_form" method="POST">
	<fieldset>
		<div class="form-group">
			<div class="col-md-2">
				<label class="control-label" for="event_details">Event Details : </label>
			</div> 
			<div class="col-md-4">
				<select name="event_details" id="event_details" class="form-control input-md">
					<option value=""> - Select an Event - </option>
					<option value="Reaching Beyond Conflict - Women">Reaching Beyond Conflict - Women</option>
					<option value="Reaching Beyond Conflict - Men">Reaching Beyond Conflict - Men</option>
					<option value="What about the children">What about the children</option>
					<option value="What about the children - Spanish">What about the children - Spanish</option>
				</select>
			</div>
		</div>
		
		<div class="form-group">
			<div class="col-md-2">
				<label class="control-label" for="fromdate">From Date : </label>
			</div> 
			<div class="col-md-4">
				<input name="fromdate" class="form-control datepicker" id="fromdate" type="text" placeholder="From Date" readonly>
			</div>
		</div>
		
		<div class="form-group">
			<div class="col-md-2">
				<label class="control-label" for="todate">To Date : </label>
			</div> 
			<div class="col-md-4">
				<input name="todate" class="form-control datepicker" id="todate" type="text" placeholder="To Date" readonly>
			</div>
		</div>
		
		<div class="form-group">
			<div class="col-md-2">
				<label class="control-label" for="firstname">First Name : </label>
			</div> 
			<div class="col-md-4">
				<input class="form-control" id="firstname" type="text" name="firstname">
			</div>
		</div>
		
		<div class="form-group">
			<div class="col-md-2">
				<label class="control-label" for="lastname">Last Name : </label>
			</div> 
			<div class="col-md-4">
				<input class="form-control" id="lastname" type="text" name="lastname">
			</div>
		</div>
		
		<div class="form-group">
			<div class="col-md-2">
				<label class="control-label" for="case_id">Case ID : </label>
			</div> 
			<div class="col-md-4">
				<input class="form-control" id="case_id" type="text" name="case_id">
			</div>
		</div>
		
		<div class="form-group">
			<div class="col-md-2">
				<label class="control-label" for="email">Email : </label>
			</div> 
			<div class="col-md-4">
				<input class="form-control" id="email" type="text" name="email">
			</div>
		</div>
		
		<div class="form-group">
			<div class="col-md-2">
				<label class="control-label" for="final_notice">Final Notice : </label>
			</div> 
			<div class="col-md-4">
				<select name="final_notice" id="final_notice" class="form-control input-md">
					<option value=""> - Choose Yes/No - </option>
					<option value="1">Yes</option>
					<option value="0">No</option>
				</select>
			</div>
		</div>
		
		<div class="form-group button-div">			 
			<div class="col-md-12 text-center">
				<input id="submitbutton" class="submitbutton btn btn-success" type="button" value="Search">
				<input id="resetbutton" class="resetbutton btn btn-success" type="reset" value="Reset" name="Reset">
			</div>
		</div>

	</fieldset>
</form>



<div id="loading-image"><center><img src="modules/mod_event_search/images/loading.gif" title="loading" alt="loading" /></center></div>
<div id="search_results"></div>

<script type="text/javascript">
	jQuery(document).ready(function($){
		$('#loading-image').hide();
		
		$(".resetbutton").on("click", function(event){
			$('#search_results').hide();
		});
		$(".submitbutton").on("click", function(event){
			$('#loading-image').show();
			$('#search_results').hide();
			$.ajax({
				type: "POST",
				url: "index.php?option=com_ajax&module=event_search&method=getEventResults&format=json",
				data: {
					fromdate:$('#fromdate').val(),
					todate: $('#todate').val(),
					firstname: $('#firstname').val(),
					lastname : $('#lastname').val(),
					case_id : $('#case_id').val(),
					email : $('#email').val(),
					final_notice: $('#final_notice').val(),
					event_details:$('#event_details').val()
				},
				cache: false,
				success: function(result){
					var data = result.data;
					$('#search_results').show();
					$('#search_results').html(data);
				},
				complete: function(){
					$('#loading-image').hide();
				}
			});
		});
	});
</script>