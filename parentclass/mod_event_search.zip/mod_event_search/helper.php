<?php
/**
 * @version 1.0
 * @package Event Search Module
 * @copyright (C) 2016 sensiple.com
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

JHtml::_('bootstrap.framework', true);

/**
 * Helper class for Event Search module
 * @subpackage Modules
 * @license        GNU/GPL
 */
class modEventSearchHelper
{
	public function __construct($config = array())
	{
		parent::__construct($config);
	}
	
 	/**
     * Retrieves the Event Search records
	 *	return search_results
   	*/
	public static function getEventResultsAjax() 
	{
		$app  = JFactory::getApplication();
		$db = JFactory::getDBO();
        $query = $db->getQuery(true); 

		// Form Data
		$event_details = $_REQUEST['event_details'];
		$fromdate = $_REQUEST['fromdate'];
		$todate = $_REQUEST['todate'];
		$firstname = $_REQUEST['firstname'];
		$lastname = $_REQUEST['lastname'];
		$case_id = $_REQUEST['case_id'];
		$email = $_REQUEST['email'];
		$final_notice = $_REQUEST['final_notice'];	
		
		//Build a Query
		$query->select("a.*,b.*,c.*,CONCAT(a.title,' -- ',a.eventdate, ' ' , a.starttime, ' to ', a.endtime) as event_detail");
        $query->from('#__event_registration_events as a');
		
		$query->join('RIGHT', $db->quoteName('#__event_registration_registered_users_map', 'b') . ' ON (' . $db->quoteName('a.id') . ' = ' . $db->quoteName('b.event_id') . ')');
		
		$query->join('LEFT', $db->quoteName('#__event_registration_registered_users', 'c') . ' ON (' . $db->quoteName('b.user_id') . ' = ' . $db->quoteName('c.id') . ')');
		
		$query->where('b.status = 1');
		
		/*Conditions*/
		if($event_details !='')
			$query->where('a.title = "'. $event_details.'"');
		
		if($fromdate !='' && $todate != '')
			$query->where('a.eventdate between "'. $fromdate . '" and "' . $todate . '"');
		
		if($firstname !='')
			$query->where($db->quoteName('c.firstname') . " LIKE '%$firstname%'");
		
		if($lastname !='')
			$query->where($db->quoteName('c.lastname') . " LIKE '%$lastname%'");
		
		if($case_id !='')
			$query->where($db->quoteName('c.case_id') . " LIKE '%$case_id%'");
		
		if($email !='')
			$query->where($db->quoteName('c.email') . " LIKE '%$email%'");
		
		if($final_notice !='')
			$query->where('b.final_notice = "'. $final_notice.'"');
		
		
		$db->setQuery($query);
		$result = $db->loadObjectList();
		
		
		$data = "<script type='text/javascript'>
					jQuery(document).ready(function($) {
						var t = $('#search-results').DataTable({
							'order': [[ 2, 'asc' ]],
							responsive: true,
							columnDefs: [
								{ targets: [0, 1,3,4,5,6,7,8,9,10], orderable: false}
							],
							dom: 'Bfrtip',
							lengthMenu: [
								[ 10, 25, 50, -1 ],
								[ '10 rows', '25 rows', '50 rows', 'Show all' ]
							],
							buttons: [
								'pageLength'
							]
						});
						t.on( 'order.dt search.dt', function () {
							t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
								cell.innerHTML = i+1;
							} );
						} ).draw();
					});
				</script>
				<table class='eventtable' id='search-results' summary='search-results'>
					<thead>
						<tr>
							<th id='search_result_sno' class='sectiontableheader' align='left'>S. No</th>
							<th id='search_result_caseid' class='sectiontableheader' align='left'>Case ID</th>
							<th id='search_result_name' class='sectiontableheader' align='left'>Name</th>
							<th id='search_result_phone' class='sectiontableheader' align='left'>Phone</th>
							<th id='search_result_email' class='sectiontableheader' align='left'>Email</th>
							<th id='search_result_address' class='sectiontableheader' align='left'>Address</th>
							<th id='search_result_attendance' class='sectiontableheader' align='left'>Attendance</th>
							<th id='search_result_final_notice' class='sectiontableheader' align='left'>Final Notice</th>
							<th id='search_result_county' class='sectiontableheader' align='left'>Douglas County</th>
							<th id='search_result_comments' class='sectiontableheader' align='left'>Comments</th>
							<th id='search_result_details' class='sectiontableheader' align='left'>Event Details</th>
						</tr>
					</thead>
					<tbody>";
		foreach($result as $key => $row)
		{
			$phone = $address = '';
			$phone .= ($row->homephone != '') ? "H:$row->homephone <br/>" : '';
			$phone .= ($row->workphone != '') ? "W:$row->workphone <br/>" : '';
			$phone .= ($row->cellphone != '') ? "C:$row->cellphone" : '';
			
			$address .= ($row->address != '') ? "$row->address, <br/>" : '';
			$address .= ($row->city != '') ? "$row->city,$row->state<br/>" : '';
			$address .= ($row->zip != '') ? "$row->zip <br/>" : '';
			
			$data .= "<tr>";
			$data .= "<td></td>";
			$data .= "<td>" . $row->case_id . "</td>";
			$data .= "<td>" . $row->lastname . ', ' . $row->firstname . "</td>";
			$data .= "<td>" . $phone . "</td>";
			$data .= "<td>" . $row->email . "</td>";
			$data .= "<td>" . $address . "</td>";
			$data .= ($row->attendance == 1) ? "<td>Yes</td>" : "<td>No</td>";
			$data .= ($row->final_notice == 1) ? "<td>Yes</td>" : "<td>No</td>";
			$data .= ($row->douglascounty == 1) ? "<td>Yes</td>" : "<td>No</td>";
			$data .= "<td>" . $row->comments . "</td>";
			$data .= "<td>" . $row->event_detail . "</td>";
			$data .= "</tr>";
		}
		$data .= "</tbody></table>";
		
		return $data;
	}
}
?>