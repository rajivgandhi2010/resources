jQuery( window ).load(function() {	 
	jQuery('img').each(function(){   	
		var $img = jQuery(this);
		if(!jQuery.trim(jQuery(this).attr("alt")))
		{	
			var filename = $img.attr('src') 
			var filename1 =  filename.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,\? ])+/g, ' ').replace(/^(-)+|(-)+$/g,' ');
			var fileNameIndex = filename1.lastIndexOf("/") + 1;
			var filename2 = filename1.substr(fileNameIndex);
			$img.attr('alt', filename2.substring(0, filename2.lastIndexOf('.')));
		}
	});	
	
	jQuery("img").each(function() {
		if(jQuery(this).attr("src") == "https://www.google.com/images/logos/google_logo_41.png") {
			jQuery(this).remove();
		}
	});

	jQuery("iframe").each(function() {
		if(jQuery(this).attr("src") == "") {
			jQuery(this).remove();
		}
	});

	jQuery('#goog-gt-tt').empty(); 
	jQuery('.goog-te-combo').prop('title', 'goog-te-combo');
	jQuery('iframe[id^="oauth2relay"]').prop('title', 'oauthrelay');
});

jQuery(function(){
	// scroll body to 0px on click
	jQuery('#back-top a').click(function () {
		jQuery('body,html').animate({
			scrollTop: 0
		}, 800);
		return false;
	});
	
	//How Do I Menu
	jQuery('.howdoi').hover(function(){
		jQuery('.howdoiArea').css("visibility","visible");
	});
	jQuery('.howdoiArea').hover(function(){
		jQuery('.howdoiArea').css("visibility","visible");
	});
	jQuery('.howdoi').mouseleave(function(){
		jQuery('.howdoiArea').css("visibility","hidden");
	});
	jQuery('.howdoiArea').mouseleave(function(){
		jQuery('.howdoiArea').css("visibility","hidden");
	});
	jQuery('.howdoi').click(function(){
		jQuery('.howdoiArea').toggle();
	});

	jQuery(".howdoiArea").mCustomScrollbar({
		scrollButtons:{
			enable:true
	  	}
  	});
	
	var ulcount = jQuery(".mCSB_container > ul").length;
	if(ulcount == 0) {
		jQuery('.mCSB_container').html( "<p>No records found.</p>" );
	}
	jQuery(".scrollpanel").mCustomScrollbar({
		scrollButtons:{
			enable:true
	  	}
  	});
	
	// Content slider
	jQuery('.flexslider').flexslider({
    	animation: "slide",
    	start: function(slider){
      		jQuery('body').removeClass('loading');
      	}	
	});
	
	jQuery('.newsslider').flexslider({
    	animation: "slide",
		slideshow: false,
		direction: "vertical",
		start:0,
		move:1,   
		minItems:3,
		animationDuration: 2000,
    	start: function(slider){
      		jQuery('body').removeClass('loading');
      	}	
	});
	
});

//Font size resize
var font = 15.25;
var a = 0;
var b = 3;
function larger() 
{
	if(font>18)
	return false;
	document.getElementById("content_pane").style.fontSize = ++font + "px";
	a = parseInt(a)+1; 
	if(a == 1)
		b=1;
	if(a == 3)
		b=3;
}

function smaller() 
{
	if(b<=0 || a == 0)
	return false;
	document.getElementById("content_pane").style.fontSize = --font + "px";
	b = parseInt(b)-1; 
	a = parseInt(a)-1;
	if(b == 1)
		a = 1;
	if (b == 0)
		a = 0;
} 
