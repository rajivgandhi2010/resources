<?php
/**
 * @package     Joomla.Site
 * @subpackage  Templates.Cityofomaha
 *
 * @copyright   Copyright (C) 2014 Sensiple Software Solutions. All rights reserved.
 */

defined('_JEXEC') or die;
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);  

JHtml::_('bootstrap.framework');
$app   = JFactory::getApplication();
$doc   = JFactory::getDocument();
$this->language = $doc->language;
$this->direction = $doc->direction;
$config = JFactory::getConfig();
$menu = $app->getMenu(); 
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
	<head>
    	<meta charset="utf-8">

        <!-- disable iPhone inital scale -->
        <meta name="viewport" content="width=device-width; initial-scale=1.0">
        <jdoc:include type="head" />  
        <!-- main css -->

		<link href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/style.css" rel="stylesheet" type="text/css">
        <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed' rel='stylesheet' type='text/css' />
		<!-- media queries css -->
		<link href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/media-queries.css" rel="stylesheet" type="text/css">

		<!--slider-style-->
		<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/flexslider.css" type="text/css" media="screen" />
       
        <link href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css" media="screen" />
		
        <link href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/mobile_menu.css" type="text/css" rel="stylesheet" />
		<!-- html5.js for IE less than 9 -->
		<!--[if lt IE 9]>
			<script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/html5.js"></script>
		<![endif]-->

		<!-- css3-mediaqueries.js for IE less than 9 -->
		<!--[if lt IE 9]>
			<script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/css3-mediaqueries.js"></script>
		<![endif]-->
        <?php
		// Template color
		if ($this->params->get('templateBackgroundColor'))
		{
		?>
		<style type="text/css">
			body {background-color: <?php echo $this->params->get('templateBackgroundColor');?>	}
		</style>
		<?php
		}
		?>
        
        <?php
		// Template Image
		if ($this->params->get('bgimage'))
		{
		?>
		<style type="text/css">
			#shell {background-image: url("<?php echo $this->baseurl . '/' .$this->params->get('bgimage');?>");}
		</style>
		<?php
		}
		?>
        
        <?php
		// Logo
		if ($this->params->get('logoimage'))
			$logo_url = $this->params->get('logoimage');
		else
			$logo_url = $this->baseurl . '/templates/' . $this->template . '/images/logo.png';
		
		// Site Title
		if ($this->params->get('sitetitle'))
			$site_title = $this->params->get('sitetitle');
			
		// Subtitle
		if ($this->params->get('subtitle'))
			$subtitle = $this->params->get('subtitle');
		
		?>

		<script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/jquery.flexslider.js" type="text/javascript"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/jquery.mCustomScrollbar.concat.min.js" type="text/javascript"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/mobile_menu.js"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/site.js"></script>
		
	</head>
    
    <body class="loading" id="top">
    	<?php if ($this->countModules('global_note')) : ?>
            <jdoc:include type="modules" name="global_note" style="xhtml" />   
        <?php endif; ?>
		<div class="topnavbg">
			<nav id="top-nav">
				<a id="pull" href="#" class="responsiveMenu4 toggleMenu isDesktop" style="display: inline-block;"></a>
				
				<jdoc:include type="modules" name="top_menu" style="xhtml" />
				<div id="responsiveMenuTheme4Cnt">
				<input type="hidden" class="maxMobileWidth" value="800" name="maxMobileWidth">
				<jdoc:include type="modules" name="mobile_menu" style="xhtml" />
				</div>
			</nav>
        </div>
		<div id="shell">
			<div id="pagewrap">
            	
            	<?php if ($menu->getActive() == $menu->getDefault())  { ?>
				<header id="header" class="clearfix"> 
                <?php } else { ?>
                <header id="header-inner" class="clearfix">
				<?php } ?>
                	
        
        			<div class="search-panel">
        				<span class="search"><jdoc:include type="modules" name="search" style="xhtml" /></span>
                        <span class="trends">
                        	<jdoc:include type="modules" name="trends" style="xhtml" />
                       </span>
                        <span class="lang-skip">
                            <jdoc:include type="modules" name="translator" style="xhtml" />
                            <a href="#content_pane">Skip Navigation</a>
                        </span>
		        	</div>
                   
        			 <?php if ($this->countModules('howdoimenu')) : ?>
                    <div class="howdoi-box">
                		<a class="howdoi">How Do I?</a>
                		<div class="howdoiArea" style="visibility: hidden;">
                       		<jdoc:include type="modules" name="howdoimenu" style="none" />
                		</div>
                	</div>
                    <?php endif; ?>
                   
                                   
                                 <?php if ($this->countModules('omaha_logo')) : ?>
						<jdoc:include type="modules" name="omaha_logo" style="xhtml" />
                    <?php endif; ?>
                
					

        			<span class="logo">
        				<a href="<?php echo $this->baseurl ?>"><img src="<?php echo $logo_url; ?>" alt="City of Omaha" /></a>
       				</span>
        			
                    <h1 class="w-title"><?php echo $site_title; ?><span><?php echo $subtitle; ?></span></h1>
        
	       			<div id="slideshow"><jdoc:include type="modules" name="news_slider" style="none" /></div>
       
                    <div id="social-media"><jdoc:include type="modules" name="social_icons" style="xhtml" /></div>
    			</header>
				<!-- /#header -->
    
                <nav id="mid-nav" class="clearfix">
                     <span class="contact-number"><jdoc:include type="modules" name="phone_number" style="xhtml" /> </span>
                    <jdoc:include type="modules" name="header_menu" style="xhtml" /> 
                </nav>
    
    			<div id="content-container" class="clearfix">
        			<div id="content">
                    	<?php if ($menu->getActive() == $menu->getDefault())  { ?>
                         
        				<div class="callout">
                        	<?php if ($this->countModules('callout_1')) : ?>
        						<article class="cal-facebook"><jdoc:include type="modules" name="callout_1" style="xhtml" /></article>
            				<?php endif; ?>
                            <?php if ($this->countModules('callout_2')) : ?>
            					<article class="cal-twitter"><jdoc:include type="modules" name="callout_2" style="xhtml" /></article>
            				<?php endif; ?>
							<?php if ($this->countModules('callout_3')) : ?>
            					<article class="cal-crimestop"><jdoc:include type="modules" name="callout_3" style="xhtml" /></article>
                           	<?php endif; ?>
            			</div>
                       
            			<?php } ?>
            			<article class="container-text" id="content_pane">
            				<header>
                    			<div class="font-resizer">Text Size&nbsp; &nbsp;<a onClick="smaller();return false;">-</a> | <a onClick="larger();return false;">+</a></div>
                                <div class="share-social-icons">
                                   	<jdoc:include type="modules" name="social_share" style="xhtml" />
                                </div>
                 			</header>
                            <jdoc:include type="message" />
                            <jdoc:include type="component" />
                            <jdoc:include type="modules" name="content_bottom" style="xhtml" /> 
            			</article>
            
            			<div class="info-container"><jdoc:include type="modules" name="news_information" style="xhtml" /></div>            
            			<article class="info-carousel"><jdoc:include type="modules" name="video_slider" style="xhtml" /></article>
            		</div>
    
        			<aside id="sidebar">
        				<section class="left-nav">
                            <jdoc:include type="modules" name="main_menu" style="xhtml" /> 
            			</section>
            
                        <section class="location-panel">
                            <?php if ($this->countModules('locator')) : ?>
                        		<jdoc:include type="modules" name="locator" style="xhtml" />
                            <?php endif; ?>
                            <div class="l-buttons">
                            	<jdoc:include type="modules" name="left_menu" style="xhtml" /> 
                            </div>
                        </section>
                        <section class="accuweather">
                        	<jdoc:include type="modules" name="weather" style="xhtml" />
                        </section>          
        			</aside>
        			<p id="back-top"><a href="#top"><span>&nbsp;</span></a></p>
    			</div>
			</div>
			<!-- /#pagewrap -->   

			<footer class="footer-shell">
				<div id="footer">
    				<div class="sitemap-links"><jdoc:include type="modules" name="main_menu" style="xhtml" /></div>
                    
    				<div class="clearfix">
                    	<div class="footer_address"><jdoc:include type="modules" name="footer_address" style="xhtml" /></div>
                        <div class="f-socialmedia">
                        	<jdoc:include type="modules" name="social_icons" style="xhtml" />
                        </div>
    				</div>
 				</div>   
			</footer>
			<!-- /#footer --> 
 		</div>
	</body>
</html>