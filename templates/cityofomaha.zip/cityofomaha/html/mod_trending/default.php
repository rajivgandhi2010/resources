<?php 
	// no direct access
	defined( '_JEXEC' ) or die( 'Restricted access' ); 
	Jhtml::_('behavior.framework', true);
	// add the script
	JHtml::stylesheet(JURI::base().'modules/'.$module->module.'/css/trending.css');
?>
<!-- This is the view part of max-hits -->
<div class = 'trending' >
	<p class = 'trending-container'>
    	<!--<li > <span class = 'trending-heading' >TRENDING:</span> </li>-->
    	<?php
		$url  = isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
		
		if(count($items)!=0)
		{
		    
        foreach($items as $value){
			?>
            
				<a href="<?php echo $url.$_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME'];?>/search-results?searchword=<?php echo strtolower($value);?>">
					<?php echo $value;?>
                </a>
           
            
		<?php }
		}?>
    </p>
</div>


