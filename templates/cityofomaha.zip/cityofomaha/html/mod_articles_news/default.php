<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_articles_news
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
?>

<div id="newsmain">
    <div class="slider">
        <div class="newsslider">
            <ul class="slides">
            <?php
			$count = count($list);
			for($i = 0; $i < count($list); $i++)
			{
				$title = strip_tags($list[$i]->title);
				$introtext = strip_tags($list[$i]->introtext);
				if(strlen($title) > 55)
					$title = substr($title,0,55) . ' ...';
				if(strlen($introtext) > 220)
					$introtext = substr($introtext,0,220) . ' ...';
				$link = $list[$i]->link;
				
				$intro_image = $list[$i]->images;
				
				$intro_image = json_decode($intro_image);
				@$intro_image_src = $intro_image->image_intro;
				if($intro_image_src)
					$image_src = $intro_image_src;
				else
					$image_src = "images/news-thumb.png";
				

				echo '<li>
                        <div class="news-blog clearfix">
                        	<span class="news-thumb-image"><img src="'.$image_src.'" alt=""></span>
                            <div class="news-desc">
                                <h4><a href="' . $link . '">' . $title . '</a></h4>
								<span>'.$list[$i]->publish_up.'</span>
                                <p>' . $introtext . '</p>
                            </div>
                        </div>';	
				echo '</li>';
			}
			?>
            </ul>
        </div>
    </div>
</div>
<!--<div class="newsflash<?php echo $moduleclass_sfx; ?>">
<?php
foreach ($list as $item) :
	require JModuleHelper::getLayoutPath('mod_articles_news', '_item');
endforeach;
?>
</div>-->
