<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_articles_latest
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
if(count($list))
{
?>

<div id="main">
    <div class="slider">
        <div class="flexslider">
            <ul class="slides">
            <?php
			foreach ($list as $item) :
			
			/*echo "<pre>";
			print_r($item);
			exit;*/
			$item->title = strip_tags($item->title);
			$item->introtext = strip_tags($item->introtext);
			if(strlen($item->title) > 30)
				$item->title = substr($item->title,0,30) . ' ...';
			if(strlen($item->introtext) > 100)
				$item->introtext = substr($item->introtext,0,100) . ' ...';
				
			//$url = $item->category_alias . '/' . $item->id . '-' . $item->alias;
			//$url = JRoute::_('index.php?option=com_content&view=article&id='.$item->id);
			?>
                <li>
                    <h1><?php echo $item->title; ?></h1>
                    <p><?php echo $item->introtext; ?></p>
                    <a href="<?php echo $item->link; ?>" class="readmore">Read More</a>                
                </li>  
			<?php
			endforeach;?>
            </ul>
        </div>
    </div>
</div>
<?php } ?>