jQuery(function (){
	
	jQuery('.center-header').hover(function(){
		jQuery('.howdoiArea').css("visibility","visible");
	});
	
	jQuery('.how-do').mouseleave(function(){
		jQuery('.howdoiArea').css("visibility","hidden");
	});
	
	jQuery('.center-header').click(function(){
		jQuery('.howdoiArea').toggle();
	});

	$('.left-main-navigation ul li a, .drop_menu-2 ul li a').click(function(){
		$(this).next('ul.left-submenus').slideToggle();
	});
	
	jQuery('.toggle_btn').click (function(){
		jQuery('#drop_menu ul').slideToggle(500);
	});
	
	jQuery('#skipNav').click(function(){
		/*var pos = jQuery("#content-bg").position().top;*/
		
		jQuery(window).scrollTop(207);
	});
	
	jQuery('#drop-down-bottom').click (function(e){
		e.preventDefault();
		jQuery('nav#leftNav').slideToggle(500);
	});
	
	jQuery('.slider1').bxSlider({
		slideWidth: 130,
		minSlides: 0,
		maxSlides: 3,
		moveSlides: 1,
		slideMargin: 17,
		speed:300,
		auto:true,
		pager:true,
		captions:true
	  });
	  
	  
	  jQuery('.go-to-top').click(function () {
		  jQuery('html,body').animate({
			  scrollTop: 0
		  }, 500);
		  return false;
	  });
	  
	  jQuery('.bxslider').bxSlider({
		mode:'fade',
		speed:3000,
		auto: true,
		controls: false,
		captions: true
	  });
	  
	  jQuery(window).scroll(function () {
		  if (jQuery(this).scrollTop() > 100) {
			  jQuery('.backtotop').fadeIn();
		  } else {
			  jQuery('.backtotop').fadeOut();
		  }
  	  });
	

	  jQuery("#content_1").mCustomScrollbar({
		  scrollButtons:{
			  enable:true
		  }
	  });

	  jQuery(".youtubeThumbnails").click(function(){
		  
		  
		  if(navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/BlackBerry/i) || navigator.userAgent.match(/webOS/i))
		  {
			yURL = "http://www.youtube.com/watch?v="+jQuery(this).attr('id');
			jQuery('.youtubePopup').show();
			  jQuery('.youtubeContainer').show();
			  jQuery('.youtubeContainer').html('<img src="'+imageFolderPath+'/images/cross.png" height="35" width="35" class="closeYoutubePopup" /><iframe width="100%" height="100%" src="//www.youtube.com/embed/'+jQuery(this).attr('id')+'" frameborder="0" allowfullscreen></iframe>');
			/*window.open(
			  yURL,
			  '_blank' // <- This is what makes it open in a new window.
			);*/
		  }
		  else
		  {
			  yURL = "http://www.youtube.com/v/"+jQuery(this).attr('id');
			  jQuery('.youtubePopup').show();
			  jQuery('.youtubeContainer').show();
			  jQuery('.youtubeContainer').html('<img src="'+imageFolderPath+'/images/cross.png" height="35" width="35" class="closeYoutubePopup" /><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"><param name="movie" value="'+yURL+'"><param name="wmode" value="transparent"><param name="allowfullscreen" value="true"><embed src="'+yURL+'" type="application/x-shockwave-flash" wmode="transparent" allowfullscreen="true"></object>');
		  }	  
	  });


	  jQuery("body").on('click', '.closeYoutubePopup',function(){
	  		jQuery('.youtubePopup').hide(); 
			jQuery('.youtubeContainer').html('');
	  		jQuery('.youtubeContainer').hide();
	  });
	  
});