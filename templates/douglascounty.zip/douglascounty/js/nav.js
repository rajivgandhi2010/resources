$(document).ready(function(){
  $("#nav > li > a").on("mouseover", function(e){
    if($(this).parent().has("ul")) {
      e.preventDefault();
    }
    
    if(!$(this).hasClass("open")) {
      // hide any open menus and remove all other classes
      $("#nav li ul").delay(100).slideUp(400);
      $("#nav li a").removeClass("open");
      
      // open our new menu and add the open class
      $(this).next("ul").delay(200).slideDown(400);
      $(this).addClass("open");
    }
    
    else if($(this).hasClass("open")) {
      $(this).removeClass("open");
      $(this).next("ul").delay(100).slideUp(400);
    }

    //alert("calling");
  });

  /*$("#nav > li > a").on("mouseleave", function(e){
      if($(this).hasClass("open")) {
        $(this).removeClass("open");
      }
  }); */
});