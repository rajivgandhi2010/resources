
<?php // no direct access

defined( '_JEXEC' ) or die( 'Restricted access' ); 
Jhtml::_('behavior.framework', true);
// add the script
JHtml::stylesheet(JURI::base().'modules/'.$module->module.'/css/maxhits.css');
?>
<!-- This is the view part of max-hits -->
<div class = 'max-hits' >
	<ul class = 'max-hits-container'>
    	<li > <span class = 'max-hits-heading' >TRENDING:</span> </li>
    	<?php
		$url  = isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
        foreach($items as $value){
			?>
            <li>
				<a href="<?php echo $url.$_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME'];?>/search-this-site/?searchword=<?php echo strtolower($value);?>">
					<?php echo strtoupper($value);?>
                </a>
            </li>
		<?php }?>
    </ul>
</div>


