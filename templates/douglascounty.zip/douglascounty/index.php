<?php
defined('_JEXEC') or die('Restricted access');
//JPlugin::loadLanguage( 'tpl_SG1' );
$app = JFactory::getApplication();
$sitename = $app->get('sitename');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width">
      <!-- tell Internet Explorer to not use compatiblity view -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <?php require __DIR__ . '/jsstrings.php'; ?>
        <jdoc:include type="head" />
        <!-- start style for template-->
        <link href="templates/<?php echo $this->template ?>/css/style.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="templates/<?php echo $this->template ?>/css/jquery.bxslider.css"/>
        <link rel="stylesheet" type="text/css" href="templates/<?php echo $this->template ?>/css/jquery.mCustomScrollbar.css"/>
        
        <script type="text/javascript">
      var imageFolderPath = "<?php echo JURI::base() ?>templates/<?php echo $this->template; ?>";
        </script>
        <script type="text/javascript" src="templates/<?php echo $this->template ?>/js/md_stylechanger.js">
        </script>
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
        <script type="text/javascript" src="templates/<?php echo $this->template ?>/js/nav.js">
        </script>

        <!-- end style for template-->
        <!--Google Analytics Start-->
        <script type="text/javascript">
        <jdoc:include type="modules" name="google_analytics_script" />
        </script>
        <!--Google Analytics End-->

        </head>

        <body id="page_bg">


          <!-- Google Tag Manager -->
          <!-- End Google Tag Manager -->  




          <?php
          // Logo file or site title param
          if ($this->params->get('logoFile')) {
            $logo = '<img src="' . JUri::root() . $this->params->get('logoFile') . '" alt="' . $sitename . '" />';
          } elseif ($this->params->get('sitetitle')) {
            $logo = '<span class="site-title" title="' . $sitename . '">' . htmlspecialchars($this->params->get('sitetitle')) . '</span>';
          } else {
            $logo = '<span class="site-title" title="' . $sitename . '">' . $sitename . '</span>';
          }
          ?>
          <jdoc:include type="modules" name="position-4" />
          <div id="wrapper">
            <div class="header clearfix">
              <div class="top-header-main clearfix">
                <div class="inner-top-header">
                  <div class="topheader-left">
                    <div class="toggle"> <span class="toggle_btn"><img src="templates/<?php echo $this->template ?>/images/toggle.png"></span><span class="right-te">MENU</span> </div>
                  </div>
                  <!--end topheader-left-->
                  <div class="topheader-right">
                    <!-- start topmenuright-->
                    <jdoc:include type="modules" name="position-0" />
                    <!-- end topmenuright-->
                  </div>
                  <!--end topheader-right--> 
                </div>
                <!--end inner-top-header--> 
              </div>
              <!--end top-header-->
              <div class="clear"></div>
              <div class="middle-header clearfix">
                <div class="inner-middle-header clearfix">
                  <div class="logo2">
                    <ul>
                      <li><a href='<jdoc:include type="modules" name="logo_link" />' title="Douglas County Main Website" target="_blank"><img src="images/logo.jpg" alt="Douglas County Seal" /></a></li>
                      <li><jdoc:include type="modules" name="title_link" /></li>
                      <li><jdoc:include type="modules" name="seal" /><!--img src="images/usimage.jpg" alt="Flag" class="header-logo-flag" /--></li>
                    </ul>

                  </div>
                  <!--end logo-->
                  <?php if ($this->countModules('howdoimenu')) : ?>
                    <div class="how-do">
                      <div class="center-header"> <a href="javascript:void(0)" id="howdoiSwitch">HOW DO I?</a> </div>
                      <!--end center-header--> 
                      <span class="boxsh-out-side"></span>
                      <div class="howdoiArea">
                        <div id="content_1" class="content">
                          <jdoc:include type="modules" name="howdoimenu" />
                        </div>
                      </div>
                    </div>
                  <?php endif; ?>
                  <!--end how-do-->
                  <div class="right-middle-header">
                    <div class="lan-section">
                      <ul>
                        <!--<li><jdoc:include type="modules" name="google_translate" /></li>-->
						<li><?php include('topmenu.php');?></li>
                        <li><a id="skipNav" href="javascript:void(0)" title="Skip Navigation" >SKIP NAVIGATION</a></li>
                      </ul>
                    </div>
                    <!--end language section-->
                    <div class="clear"></div>
                    <p class="search-box">
                      <jdoc:include type="modules" name="position-15" />
                    </p>
                    <div class="clear"></div>
                    <span class="trends">
                        <jdoc:include type="modules" name="position-18" style="xhtml" />
                     </span>
                    <div class="clear"></div>
                    <div class="social-icon top-social">
                      <!-- start topsocialicons-->
                      <jdoc:include type="modules" name="position-22" />
                      <!-- end topsocialicons-->
                    </div>
                  </div>
                  <!--end right-middle-header--> 
                </div>
                <!--end inner-middle-header--> 
              </div>
              <!--end middle-header-->
              <div class="top-header-main clearfix" style="height:36px; ">
                <div class="navigation condesk midium">
                  <jdoc:include type="modules" name="position-6" />
                  <div class="drop_menu"  id="drop_menu">
                    <jdoc:include type="modules" name="mobile_menu" />
                  </div>
                  <!--end naviation--> 
                </div>
                <!--end inner-top-header--> 
              </div>
              <!--end top-header-main--> 
            </div>
            <!--end header-->
            <jdoc:include type="modules" name="position-2" />
            <!--<jdoc:include type="modules" name="position-17" />-->

            <div id="override">
              <div class="bxslider">
                <?php
                $bSliderPath = 'images/background-slider/';
                foreach (glob($bSliderPath . '*.*') as $filename) {
                  ?>
                  <img src="<?php echo $filename; ?>" alt="Background Image">
                    <?php
                  }
                  ?>
              </div>
            </div>
            <div class="main-content-bg" id="content-bg">
              <div class="box-shedow-div">
                <div class="inner-content clearfix">
                  <div class="left-part">
                    <div class="left-main-navigation">
                      <jdoc:include type="modules" name="position-8" />
                    </div>
                    <div class="clear left-main-navigation left-user-navigation">
                      <jdoc:include type="modules" name="user-menu" />
                    </div>
                    <!--end left-mian-navigation-->
                    <!--end topmenu-->

                    <div class="clear"></div>
                    <p class="adobePlace "><a title="opens in new window" target="_blank" href="http://get.adobe.com/reader"><img src="images/get_adobe_reader.png" alt="Get Adobe Reader" border="0" /></a></p>
                    <div class="clear"></div>
                    <div class="clear"></div>
                    <p class="douglasimag "><a title="opens in new window" onclick="myFunction()" href="javascript:void(0);"><img src="templates/<?php echo $this->template ?>/images/douglas_county.png" alt="Douglas County Video Tour" border="0" /></a></p>
                    <div class="clear"></div>

                    <!--<div class="map">
                      <h4>LOCATION MAPS & INFO</h4>
                      <div class="map-img">
                        <img src="templates/<?php //echo $this->template ?>/images/map-img.jpg" alt="map" width="240" height="120"/>
                      </div>
                      <div class="clear"></div>
                      <div class="form-left">
                        <p>Enter name, address or property id</p>
                        <jdoc:include type="modules" name="position-15" />
                        <p>Get quick access to maps and information about a location.</p>
                      </div>
                    </div>-->
                    <!--end map--> 
                  </div>
                  <!--end left-part-->

                  <div class="right-part clearfix">
                    <div class="content-dou">
                      <div id="fontsize"></div>
                      <jdoc:include type="message" />
                      <jdoc:include type="modules" name="position-3" />
                      <jdoc:include type="component" />
                      <jdoc:include type="modules" name="position-10" />
                    </div>
                    <div class="clear"></div>        
                  </div>
                  <!--end right-part-->
                  <div class="clear"></div>
                </div>
                <!--end inne-content-->
                <div class="responsive-con320">
                  <div class="clear"></div>
                  <p class="adobePlace condtion320-adobePlace"><a title="opens in new window" target="_blank" href="http://get.adobe.com/reader"><img src="images/get_adobe_reader.png" alt="Get Adobe Reader" border="0" /></a></p>
                  <div class="clear"></div>
                  <div class="clear"></div>
                  <p class="douglasimag condtion320-douglasimag"><a title="opens in new window" onclick="myFunction()" href="javascript:void(0);"><img src="templates/<?php echo $this->template ?>/images/douglas_county.png" alt="Douglas County Video Tour" border="0" /></a></p>
                  <div class="clear"></div>
                  <!--<div class="map condtion320-map">
                    <h4>LOCATION MAPS & INFO</h4>
                    <div class="map-img">
                      <img src="templates/<?php echo $this->template ?>/images/map-img.jpg"  alt="map" width="240" height="120"/>
                    </div>
                    <div class="form-right form-left">
                      <p>Enter name, address or property id</p>
                      <jdoc:include type="modules" name="position-15" />
                      <p>Get quick access to maps and information about a location.</p>
                    </div> 
                  </div>-->
                  <!--end map--> 
                </div>
                <!--end boc-shedow-div--> 
              </div>
            </div>
            <!--end main-content-bg-->

            <div class="clear"></div>
            <div class="responsive-con320">
              <div class="bottom-content  inner-content-bottom clearfix">
                <div class="left-part">
                  <jdoc:include type="modules" name="position-19" />
                  <jdoc:include type="modules" name="position-9" />
                </div>
                <!--end left-part-->
                <div class="right-part clearfix ">
                  <div class="download_forms">
                    <jdoc:include type="modules" name="position-20" />
                  </div>
                  <div class="product-scroller">
                    <jdoc:include type="modules" name="position-5" />
                  </div>
                  <!--end product-scroller-->
                </div>
              </div>
              <!--end bottom-content--> 
            </div>
            <!--end responsive-con320--> 
          </div>

          <!-- Youtube Popup -->
          <div class="youtubePopup"></div>
          <div class="youtubeContainer"></div>
          <!-- -->

          <div class="backtotop" style="display:none;">
            <a class='go-to-top' href='#wrap' title='back to top'>Back to Top</a>
          </div>
          <div class="clear"></div>
		  <div class="footer">
  <div class="inner-footre">
    <div class="footer-main-navegation"> 
        <jdoc:include type="modules" name="position-21" />
    </div>
    <!--end footer-main-navegation-->
    <div class="clear"></div>
    <div class="bottom-footer">
      <div class="bottom-footer-left">
        <div class="left-add">
          <jdoc:include type="modules" name="position-13" />
        </div>
        <div class="left-add clearfix">
          <jdoc:include type="modules" name="position-14" />
        </div>
      </div>
      <!--end bottom-footer-left-->
      <div class="bottom-footer-right clearfix">
        <div class="left-add bottom-soc">
          <div class="social-icon">
            <jdoc:include type="modules" name="position-22" />
          </div>
          <div class="clear"></div>
          <jdoc:include type="modules" name="footer" />
        </div>
      </div><!--end bottom-footer-right-->
    </div><!--end bottom-footer-->
   	<jdoc:include type="modules" name="copyright" />
    
  </div>
  <!--end inner-footer--> 
  
</div>
          <!--<div class="footer">
            <div class="inner-footre">
              <div class="footer-main-navegation"> 
                <jdoc:include type="modules" name="position-21" />
              </div>
              <div class="footer-main-navegation ft-mn2"> 
                <jdoc:include type="modules" name="position-23" />
              </div>
              <div class="clear"></div>
              <div class="bottom-footer">
                <div class="bottom-footer-left">
                  <div class="left-add">
                    <jdoc:include type="modules" name="position-13" />
                  </div>
                  <div class="left-add clearfix">
                    <jdoc:include type="modules" name="position-14" />
                  </div>
                </div>
                <div class="bottom-footer-right clearfix">
                  <div class="left-add bottom-soc">
                    <div class="social-icon">
                      <jdoc:include type="modules" name="position-22" />
                    </div>
                    <div class="clear"></div>
                    <jdoc:include type="modules" name="footer" />
                  </div>
                </div>
              </div>
              <jdoc:include type="modules" name="copyright" />

            </div>
            

          </div>-->

          <!--start script for footer--> 
          <?php
          $document = JFactory::getDocument(); //remove is this line is already being used
          $js = "jQuery(document).ready(function(){
          jQuery('[rel=tooltip]').tooltip();
       });";
          $document->addScriptDeclaration($js);
          ?>
          <script src="templates/<?php echo $this->template ?>/js/jquery-1.10.2.min.js"></script> 
          <script type="text/javascript" src="templates/<?php echo $this->template ?>/js/jquery.bxslider.min.js"></script>
          <script type="text/javascript" src="templates/<?php echo $this->template ?>/js/jquery.mCustomScrollbar.concat.min.js"></script> 
          <script type="text/javascript" src="templates/<?php echo $this->template ?>/js/header.js"></script> 
          <!-- Council member selection dropdown --> 

          <script language="JavaScript" type="text/JavaScript">
            function changePage(newLoc)
            {
            nextPage = newLoc.options[newLoc.selectedIndex].value

            if (nextPage != "")
            {
            document.location.href = nextPage
            }
            }
          </script> <!-- end selection dropdown -->
          <script type="text/javascript">
          function myFunction() {
            var myWindow = window.open("http://www.elocallink.tv/clients3/ne/douglascounty/tourplay.php?movie=dougcone11_wel_rev1_iwd&spon=welcome", "", "width=800, height=800");

          }
          </script>
        </body>
        </html>