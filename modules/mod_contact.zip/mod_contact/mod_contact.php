<?php
/**
 * @package Contact Form with Captcha and Email - Joomla Module
 * @author Sensiple
 * @website http://sensiple.com
 * @copyright 2016
 **/

//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

// Include the syndicate functions only once
require_once( dirname(__FILE__).'/helper.php' );
 
require( JModuleHelper::getLayoutPath( 'mod_'.$module->name,$params->get('layout', 'default') ) );