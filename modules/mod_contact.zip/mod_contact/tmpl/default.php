<?php
/**
 * @package Contact Form with Captcha and Email - Joomla Module
 * @author Sensiple
 * @website http://sensiple.com
 * @copyright 2016
 **/
 
//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
JHtml::_('behavior.framework', true);
//JHtml::_('behavior.formvalidator');
$document = JFactory::getDocument();
$document->addScript(JURI::base() . 'modules/mod_' . $module->name . '/js/jquery.validate.min.js');
$document->addScript(JURI::base() . 'modules/mod_' . $module->name . '/js/script.js');
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/contact_form.css' );
//require('recaptchalib.php');

$module = JModuleHelper::getModule('mod_contact');
$params = new JRegistry($module->params);
$publickey = $params->get('public_key');

if(isset($_POST) && !empty($_POST))
{
	$mail_status = modContactHelper::sendMail();
	if($mail_status)
	{
		echo "<p class='success_msg'>". $params->get('success_message') . "</p>";
	}
	else{
		echo "<p class='error_msg'>". $params->get('error_message') . "</p>";
	}
}
?>
<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer></script>
<script type="text/javascript">
	var onloadCallback = function() {
		grecaptcha.render('captcha_element', {
			'sitekey' : '<?php echo $publickey; ?>'
		});
	};
</script>
<form class="esb_form" id="esb_form" name="esb_form" method="POST" >
	<div class="esb_form_fields">
		<label>Enter your Name : </label>
		<input id="name" type="text" name="name" class="required">
	</div>
	
	<div class="esb_form_fields">
		<label>E-mail address : </label>
		<input id="email" type="text" name="email" class="required validate-email">
	</div>
	
	<div class="esb_form_fields">
		<label>Subject : </label>
		<input id="subject" type="text" name="subject" class="required" value="<?php echo $params->get('default_subject'); ?>">
	</div>
	
	<div class="esb_form_fields">
		<label>Message : </label>
		<textarea name="message" maxlength="150" id="message" rows="3" class="form textarea required" cols="" rows=""></textarea>
	</div>	
	
	<?php if($params->get('copy_email')) { ?>
	<div class="esb_form_fields">
		<input type="checkbox" name="copy_email" id="copy_email" value="copy_email">E-mail a copy of this message to your own address<br>
	</div>	
	<?php } ?>
	
	<div class="esb_form_fields">
		<?php //echo recaptcha_get_html($publickey); ?>
		<div id="captcha_element"></div>
		<label class="error" id="recaptcha-error" style="display: none;">Invalid captcha. </label>
	</div>	
	
	<div class="esb_form_fields esb_form_buttons">
		<input type="submit" value="Submit">
		<input id="button" type="reset" value="Reset" name="Reset">
	</div>
	
</form>	