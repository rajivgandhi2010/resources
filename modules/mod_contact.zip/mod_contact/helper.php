<?php
JHtml::_('behavior.framework', true);
/**
 * Helper class for Contact Form with Captcha and Email - Joomla Module
 * @subpackage Modules
 * @website http://sensiple.com
 * @copyright 2016
 */
class modContactHelper
{
	public static function sendMail()
	{
		/*Get Module params*/
		$module = JModuleHelper::getModule('mod_contact');
		$params = new JRegistry($module->params);
				
		/*Submitted form details*/
		$name = JRequest::getVar('name');
		$email = JRequest::getVar('email');
		$subject = JRequest::getVar('subject');
		$message = JRequest::getVar('message');
		
		$msg = "Here is the information received from the website:\n<br/><br/>";
		$msg .= "Name :      \t$name\n<br/>";
		$msg .= "Email :     \t$email\n<br/>";
		$msg .= "Subject :\t$subject\n<br/>";
		$msg .= "Message :   \t$message\n\n<br/>";
		
		/*Mail*/
		$mail = JFactory::getMailer();
		$recipient 	= $params->get('admin_email');
		$config = JFactory::getConfig();
        $sendet_from = $config->get('fromname');
		$sendet_email = $config->get('mailfrom');
		$sender = array($sendet_email, $sendet_from);
		//$subject = "PC Support Request";
		$mail->addRecipient($recipient);
		$mail->setSender($sender);
		if(JRequest::getVar('copy_email'))
		{
			$ccs = explode(', ',$email);
			foreach($ccs as $key => $email)
			{
				$mail->AddCC($email);
			}
			//$mail->addCC($email);
		}
		$mail->setSubject($subject);
		$mail->Encoding = 'base64';	
		$mail->setBody($msg);
		$mail->isHTML(true);
		
		//Send mail
		$status = $mail->Send();
		return $status;
	}
}
?>