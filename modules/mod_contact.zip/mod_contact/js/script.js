jQuery(function() {
	jQuery("#esb_form").validate({
		// Specify the validation rules
        rules: {
            name: "required",
			email: "required",
			message: "required"
        },
		// Specify the validation error messages
        messages: {
            name: "Please enter your name",
			email: "Please enter your valid email address",
			message: "Please enter your message"
        },
        
        submitHandler: function(form) {
			var response = grecaptcha.getResponse();
			if(response.length === 0)
			{
				jQuery('#recaptcha-error').show();
				return false;
			}
			else {
			  jQuery('#recaptcha-error').hide();
			  form.submit();
			  return true;
			}
        }
	});
});
