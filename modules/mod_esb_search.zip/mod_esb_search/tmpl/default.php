<?php
/**
 * @package ESB Search Joomla Module
 * @author Sensiple
 * @website http://sensiple.com
 * @copyright 2014
 **/
 
//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
JHtml::_('behavior.framework', true);
$document = JFactory::getDocument();

$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/search_form.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/jquery.tablesorter.pager.css' );
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/themes/blue/style.css' );

$document->addScript( JURI::base() . 'modules/mod_' . $module->name . '/js/jquery.tablesorter.js' );
$document->addScript( JURI::base() . 'modules/mod_' . $module->name . '/js/pager/jquery.tablesorter.pager.js' );
$document->addScript( JURI::base() . 'modules/mod_' . $module->name . '/js/scripts.js' );

$display_type = $params->get('display_type');

?>

<?php
/*echo "<pre>";
print_r($items);exit;*/
if($display_type =='search_form')
{
	if(isset($_POST['customername']))
	{ ?>
		<p align="right"><a href="small-and-emerging-business-program-directory">Go back to search page</a></p>
		<p align="right"><a href="javascript:window.print()">Print Page</a></p>
		<p>Results of search for 
		<?php 
		if (isset($_POST['customername']) & $_POST['customername'] != "" ){
			echo "<b>Customer Name: " . $_POST['customername'] . ", </b>";
		}
		if (isset($_POST['customertier1']) & $_POST['customertier1'] != "" ){
			echo "<b>Certification Type: " . $_POST['customertier1'] . ", </b>" ;
		}
		if (isset($_POST['naics']) & $_POST['naics'] != "" ){
			echo "<b>NAICS: " . $_POST['naics'] . ", </b>" ;
		}
		if (isset($_POST['naicsdesc']) & $_POST['naicsdesc'] != "" ){ 
			echo "<b>NAICS Description: " . $_POST['naicsdesc'] . ", </b>";
		}
		if (isset($_POST['pscode']) & $_POST['pscode'] != "" ){
			echo "<b>Purchasing Code: " . $_POST['pscode'] . ", </b>";
		}
		if ($_POST['customername'] == "" & $_POST['customertier1'] == "" & $_POST['naics'] == "" & $_POST['naicsdesc'] == "" & $_POST['pscode'] == ""){
			echo "<b>All Records </b>";
		}
		?>
		<div id="result_div">
		<table id="result_table" class="tablesorter" border="0" cellpadding="0" cellspacing="1">
			<thead>
				<tr>
					<th>Certification<br/>Type</th>
					<th>Date<br/>Certified</th>
					<th>Company<br/>Name</th>
					<th>Contact<br/>Person</th>
					<th>Phone<br/>No</th>
					<th>Fax No</th>
					<th>Address</th>
					<th>City</th>
					<th>State</th>
					<th>ZIP</th>
					<th>Email</th>
				</tr>
			</thead>
			<tbody>
				<?php
					foreach($items as $item)
					{
						echo '<tr>
							<td>'.$item->certType.'</td>
							<td>'.$item->CERTIFIED_DATE.'</td>
							<td><a target="_blank" href="'.JURI::current().'?customerid='.$item->customerid.'&ZIPCODE='.$item->ZIPCODE.'">'.$item->CUSTOMERNAME.'</a></td>
							<td>'.$item->CONTACTNAME.'</td>
							<td>'.$item->CONT_PHONE.'</td>
							<td>'.$item->CONTACTFAX.'</td>
							<td>'.$item->address.'</td>
							<td>'.$item->CITY.'</td>
							<td>'.$item->STATE.'</td>
							<td>'.$item->ZIPCODE.'</td>
							<td><a href="mailto:'.$item->CONTACTEMAIL.'">'.$item->CONTACTEMAIL.'</a></td>
						</tr>';
					}			
				?>
			</tbody>	
		</table>
		<div id="pager" class="pager">
			<form>
				<img src="<?php echo JURI::base() . 'modules/mod_' . $module->name; ?>/images/first.png" class="first" title="First" alt="First" />
				<img src="<?php echo JURI::base() . 'modules/mod_' . $module->name; ?>/images/prev.png" class="prev" title="Previous" alt="Previous" />
				<input type="text" class="pagedisplay"/>
				<img src="<?php echo JURI::base() . 'modules/mod_' . $module->name; ?>/images/next.png" class="next" title="Next" alt="Next" />
				<img src="<?php echo JURI::base() . 'modules/mod_' . $module->name; ?>/images/last.png" class="last" title="Last" alt="Last" />
				<select class="pagesize">
					<option selected="selected"  value="10">10</option>
					<option value="20">20</option>
					<option value="30">30</option>
					<option  value="40">40</option>
				</select>
			</form>
		</div>
		</div>
	<?php 
	}
	else if(isset($_GET['customerid']))
	{?>
		<p align="right"><a href="javascript:window.print()">Print Page</a></p>
		<h3><?php echo htmlentities(stripslashes($items->CUSTOMERNAME)); ?></h3>
		<p>
			<?php echo $items->certType; ?><br/>
			Date Certified: <?php echo $items->CERTIFIED_DATE; ?>
		</p>
		<p>
			<?php echo stripslashes($items->address); ?><br />
			<?php echo $items->CITY.", ".$items->STATE." ".$items->ZIPCODE; ?><br />
		</p>
		<p>
			Contact: <?php echo stripslashes($items->CONTACTNAME); ?><br />
			Phone: <?php echo $items->CONT_PHONE; ?><br />
			<?php 
				if($items->CONTACTFAX <> NULL && $items->CONTACTFAX <> "") echo "Fax: ".$items->CONTACTFAX . "<br />";
				if($items->CONTACTEMAIL <> NULL && $items->CONTACTEMAIL <> "") echo 'Email: <a href="mailto:'.$items->CONTACTEMAIL.'">'.$items->CONTACTEMAIL.'</a>';
			?>
		</p>
		<table id="detail_table" border="1" cellpadding="2" bordercolor="#000000" style="width:700px; margin-bottom:10px; border-collapse:collapse">
			<tr>
				<th><div align="left">NAICS Code No.</div></th>
				<th><div align="left">NAICS Description</div></th>
			</tr>
			<tr>
				<td><?php echo $items->NaicsCodes; ?></td>
				<td><?php echo $items->NaicsCodeDesc; ?></td>
			</tr>
		</table>
		<table style="margin-bottom:10px;">
			<tr>
				<td><b>Purchasing Code(s)</b></td>
			</tr>
			<tr>
				<td><?php echo $items->productClass; ?></td>

			</tr>
		</table>
	<?php
	}
	else
	{
	?>
		<h3>Search by any or all of the following:</h3>
		<form class="esb_form" name="esb_form" method="POST">
			<div class="esb_form_fields">
				<label>Company Name : </label>
				<input id="customername" type="text" name="customername">
			</div>
			
			<div class="esb_form_fields">
				<label>Certification Type : </label>
				<input id="customertier1" type="text" name="customertier1">
			</div>
			
			<div class="esb_form_fields">
				<label>NAICS : </label>
				<input id="naics" type="text" name="naics">
			</div>
			
			<div class="esb_form_fields">
				<label>NAICS Description : </label>
				<input id="naicsdesc" type="text" name="naicsdesc">
			</div>
			
			<div class="esb_form_fields">
				<label>Purchasing Code : </label>
				<input id="pscode" type="text" name="pscode">
			</div>
			
			<div class="esb_form_fields esb_form_buttons">
				<input type="submit" value="Submit">
				<input id="button" type="reset" value="Reset" name="Reset">
			</div>
			
		</form>
		
		<h2>Search Tips</h2>
		<p>For all records, leave fields blank and click Submit button.</p>
		<p>
			<strong>Name:</strong> enter any part of the business name<br>
			<strong>Certification Type:</strong>
		</p>
		<ul>
			<li><strong> Tier:</strong> 1 or 2</li>
			<li><strong>Classification:</strong> SB - Small Business, ESB - Emerging Small Business  </li>
		</ul>
		<p>
			<strong>NAICS:</strong> use one number from the <a onclick="return popcode('esb/naics.php')" href="esb/naics.php">NAICS listing</a><br>
			<strong>NAICS Description:</strong> enter any part of the NAICS description<br>
			<strong>Purchasing Code:</strong> use one number from the <a onclick="return popcode('esb/pslookup.php')" href="esb/pslookup.php">Product &amp; Service Classifications</a><br>
		</p>
		<p><strong>NOTICE: </strong>This directory is provided solely as a  convenience to companies doing business with the City. Entities whose names  appear in this directory have been certified by the City of Omaha, Human Rights  and Relations Department as a Tier I or Tier II Emerging Small Business (ESB)  or Small Business (SB). The City does not certify that these companies hold the  requisite licenses or qualifications to perform the type of work listed, and  this directory should not be viewed as a recommendation by the City.&nbsp; &nbsp;Companies  wishing to contract or subcontract with any of the listed entities should  exercise due diligence and ascertain which, if any, participant is qualified to  perform the work on a particular project.</p>
	<?php 
	}
} 
?>