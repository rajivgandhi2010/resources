//popups
function popcode(url){
	newwindow=window.open(url, 'name', 'height=800,width=450,scrollbars=yes');
	if(window.focus){newwindow.focus()}
	return false;
}

/*Result Table*/
jQuery(document).ready(function($) {
	$("#result_table").tablesorter({widthFixed: true, widgets: ['zebra']}).tablesorterPager({container: $("#pager")});;
});