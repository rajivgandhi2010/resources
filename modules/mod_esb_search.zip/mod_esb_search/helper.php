<?php
JHtml::_('behavior.framework', true);
/**
 * Helper class for ESB Search module
 * @subpackage Modules
 * @license        GNU/GPL
 */
class modEsbSearchHelper
{
	
	/*public function __construct($config = array())
	{
		parent::__construct($config);
 
		$option = array(); //prevent problems
 
		$option['driver']   = 'mysql';            			// Database driver name
		$option['host']     = $params->get('db_hostname');  // Database host name
		$option['user']     = $params->get('db_user');      // User for database authentication
		$option['password'] = $params->get('db_password');  // Password for database authentication
		$option['database'] = $params->get('db_name');      // Database name
		$option['prefix']   = '';             				// Database prefix (may be empty)
 
		$db = JDatabaseDriver::getInstance( $option );
		parent::setDbo($db);
	}*/
	
    /**
     * Retrieves the ESB Search records
     * Params : DB details
	 *	return items 
   	*/
	public static function getList($params) {
		$display_type = $params->get('display_type');
		
		/*DB Details From Admin panel*/
		$option = array(); //prevent problems
		$option['driver']   = 'mysql';            			// Database driver name
		$option['host']     = $params->get('db_hostname');  // Database host name
		$option['user']     = $params->get('db_user');      // User for database authentication
		$option['password'] = $params->get('db_password');  // Password for database authentication
		$option['database'] = $params->get('db_name');      // Database name
		$option['prefix']   = '';             				// Database prefix (may be empty)
 
		$db = JDatabaseDriver::getInstance( $option );
		$query = $db->getQuery(true);
		
		/*echo "<pre>";
		print_r($query);exit;*/
		
		if($display_type == 'search_form' && isset($_POST['customername']))
		{
			$search_custname = modEsbSearchHelper::escape_string($_POST['customername']);	
			$search_tier = modEsbSearchHelper::escape_string($_POST['customertier1']);	
			$search_naics = modEsbSearchHelper::escape_string($_POST['naics']);	
			$search_pscode = modEsbSearchHelper::escape_string($_POST['pscode']);	
			$search_naicsdesc = modEsbSearchHelper::escape_string($_POST['naicsdesc']);
			
			$query->select(array('c.*'));
			$query->from($db->quoteName('esb_rt','c'));
			$query->where($db->quoteName('c.CUSTOMERNAME') . 'LIKE \'%'.$search_custname.'%\'');
			$query->where($db->quoteName('c.certType') . 'LIKE \'%'.$search_tier.'%\'');
			$query->where($db->quoteName('c.NaicsCodes') . 'LIKE \'%'.$search_naics.'%\'');
			$query->where($db->quoteName('c.NaicsCodeDesc') . 'LIKE \'%'.$search_naicsdesc.'%\'');
			$query->where($db->quoteName('c.productClass') . 'LIKE \'%'.$search_pscode.'%\'');
			
			$query->order('c.CUSTOMERNAME ASC');
			
			$db->setQuery($query);
			$items = $db->loadObjectList();
		}
		else if($display_type == 'search_form' && isset($_GET['customerid']))
		{
			$customerid = $_GET['customerid'];
			$ZIPCODE = $_GET['ZIPCODE'];
			
			$query->select(array('c.*'));
			$query->from($db->quoteName('esb_rt','c'));
			$query->where($db->quoteName('c.customerid') . '= '.$customerid.'');
			$query->where($db->quoteName('c.ZIPCODE') . 'LIKE \'%'.$ZIPCODE.'%\'');
			$db->setQuery($query);
			$items = $db->loadObject();
		}
		else
		{
			$items = $display_type;
		}
		return $items;
	}  	
	
	public static function escape_string($string){
		$escapedString = str_replace("'","''",html_entity_decode($string));
		return $escapedString;
	}
	
	public static function validateint($inData){
		$intRetVal = -1;
		$intValue = intval($inData);
		$strValue = strval($intValue);
		
		if($strValue == $inData){
			$intRetVal = $intValue;
		}
		return $intRetVal;
	}
}
?>