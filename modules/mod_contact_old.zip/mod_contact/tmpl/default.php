<?php
/**
 * @package Contact Form with Captcha and Email - Joomla Module
 * @author Sensiple
 * @website http://sensiple.com
 * @copyright 2016
 **/
 
//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
JHtml::_('behavior.framework', true);
JHtml::_('behavior.formvalidator');
$document = JFactory::getDocument();
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/contact_form.css' );

if(isset($_POST) && !empty($_POST))
{
	$mail_status = modContactHelper::sendMail();
	if($mail_status)
	{
		echo "<p>Below is the information you submitted.</p>";
		echo 'Thank you for your submission.';
	}
	else{
		echo "There was some problem in submission. Please refresh the page and submit the form again.";
	}
}
?>
<form class="esb_form form-validate" name="esb_form" method="POST" >
	<div class="esb_form_fields">
		<label>Name : </label>
		<input id="name" type="text" name="name" class="required">
	</div>
			
	<div class="esb_form_fields">
		<label>Department : </label>
		<input id="department" type="text" name="department" class="required">
	</div>
	
	<div class="esb_form_fields">
		<label>Phone Number : </label>
		<input id="phone" type="text" name="phone" class="required">
	</div>
	
	<div class="esb_form_fields">
		<label>E-Mail : </label>
		<input id="email" type="text" name="email" class="required validate-email">
	</div>
	<div class="esb_form_fields">
		<label>Please state Ideas/Concerns : </label>
		<textarea name="problems" maxlength="150" id="problems" rows="3" class="form textarea required" cols="" rows=""></textarea>
	</div>
	<div class="esb_form_fields esb_form_buttons">
		<input type="submit" value="Submit">
		<input id="button" type="reset" value="Reset" name="Reset">
	</div>
	
</form>	