<?php
JHtml::_('behavior.framework', true);
/**
 * Helper class for Contact Form with Captcha and Email - Joomla Module
 * @subpackage Modules
 * @website http://sensiple.com
 * @copyright 2016
 */
class modContactHelper
{
	public static function sendMail()
	{
		/*Get Module params*/
		$module = JModuleHelper::getModule('mod_contact');
		$params = new JRegistry($module->params);
				
		/*Submitted form details*/
		$name = JRequest::getVar('name');
		$department = JRequest::getVar('department');
		$phone = JRequest::getVar('phone');
		$email = JRequest::getVar('email');
		$problems = JRequest::getVar('problems');
		
		$msg = "Here is the Intranet contact:\n";
		$msg .= "Name:      \t$name\n";
		$msg .= "Department:\t$department\n";
		$msg .= "Phone:     \t$phone\n";
		$msg .= "Email:     \t$email\n";
		$msg .= "Ideas/Concerns:   \t$problems\n\n";
		
		/*Mail*/
		$mail = JFactory::getMailer();
		$recipient 	= $params->get('admin_email');
		$sender = array($email, $name);
		$subject = "PC Support Request";
		$mail->setSender($sender);
		$mail->addRecipient($recipient);
		$mail->setSubject($subject);
		$mail->isHTML(true);
		$mail->Encoding = 'base64';	
		$mail->setBody($msg);
		
		//Send mail
		$status = $mail->Send();
		return $status;
	}
}
?>