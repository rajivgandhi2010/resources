<?php
/**
 # @package			Twitter Feeds
 # @sub_package		mod_twitterfeeds - Facebook Feeds module for Joomla! 3.3
 # @author			Sensiple Software Solutions
 # @copyright 		Copyright(C) 2012 QExtension.com. All Rights Reserved.
 # @license			GNU/GPL version 2 - http://www.gnu.org/licenses/gpl-2.0.html
 # @website			http://www.sensiple.com
**/

// no direct access
defined('_JEXEC') or die;
 
// Include the helper file
require_once dirname(__FILE__).'/helper.php';

// if cURL is disabled, then extension cannot work
if(!is_callable('curl_init')){
	$data = false;
	$curlDisabled = true;
}
else {
	$model = new modTwitterFeedsHelper();
	$model->addStyles($params);
	$data = $model->getData($params);
}

if($data) {
	require JModuleHelper::getLayoutPath('mod_twitterfeeds', $params->get('layout', 'default'));
}
else {
	require JModuleHelper::getLayoutPath('mod_twitterfeeds', 'error/error');
}
