<?php
/**
 # @package			Twitter Feeds
 # @sub_package		mod_twitterfeeds - Facebook Feeds module for Joomla! 3.3
 # @author			Sensiple Software Solutions
 # @copyright 		Copyright(C) 2012 QExtension.com. All Rights Reserved.
 # @license			GNU/GPL version 2 - http://www.gnu.org/licenses/gpl-2.0.html
 # @website			http://www.sensiple.com
**/
// no direct access
defined('_JEXEC') or die;
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);  

?>
<div class="blog-container scrollpanel">
	<div id="feed-container" style="background-color:<?php echo $params->get('bgd_color'); ?>">
		<?php foreach($data->tweets as $key => $tweet): ?>
            <div class="tweet-container <?php echo @end(array_keys($data->tweets)) == $key?' feed-last':'';?>">
                <div class="tweets">
                    <?php echo $tweet->text; ?>
                </div>
                <div class="tweet-data">
                    
                    <?php if($params->get('reply', 1) || $params->get('retweet', 1) || $params->get('favorite', 1)): ?>
                        &bull;
                    <?php endif; ?>
                    
                    <?php if($params->get('reply', 1)): ?>
                        <a href="https://twitter.com/intent/tweet?in_reply_to=<?php echo $tweet->id; ?>" target="_blank">reply</a>
                        <?php if($params->get('retweet', 1) || $params->get('favorite', 1)): ?>
                            &bull;
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php if($params->get('retweet', 1)): ?>
                        <a href="https://twitter.com/intent/retweet?tweet_id=<?php echo $tweet->id; ?>" target="_blank">retweet</a>
                        <?php if($params->get('favorite', 1)): ?>
                            &bull;
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php if($params->get('favorite', 1)): ?>
                        <a href="https://twitter.com/intent/favorite?tweet_id=<?php echo $tweet->id; ?>" target="_blank">favorite</a>
                    <?php endif; ?>
                    
                </div>
            </div>
            <hr />
        <?php endforeach; ?>
	</div>
</div>