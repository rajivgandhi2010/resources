<?php
/**
 # @package			Twitter Feeds
 # @sub_package		mod_twitterfeeds - Facebook Feeds module for Joomla! 3.3
 # @author			Sensiple Software Solutions
 # @copyright 		Copyright(C) 2012 QExtension.com. All Rights Reserved.
 # @license			GNU/GPL version 2 - http://www.gnu.org/licenses/gpl-2.0.html
 # @website			http://www.sensiple.com
**/

// no direct access
defined('_JEXEC') or die;
?>

<div class="blog-container scrollpanel">
	<?php if(isset($curlDisabled)): ?>
        <p>Your PHP doesn't have cURL extension enabled. Please contact your host and ask them to enable it.</p>
    <?php else: ?>
        <p>It seems that module parameters haven't been configured properly. Please make sure that you are using a valid twitter	 username, and that you have inserted the correct keys. Detailed instructions are written in the module settings page.</p>
    <?php endif; ?>
</div>