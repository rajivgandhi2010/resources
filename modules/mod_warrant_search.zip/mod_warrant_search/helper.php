<?php
/**
 * Helper class for Warrant Search! module
 * @subpackage Modules
 * @license        GNU/GPL, see LICENSE.php
 * mod_trending is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * Author Sensiple
 */
class modWarrantSearchHelper
{
    /**
     *	Retrieves the hello message
     *	no param
	 *	return items 
	 */
    public static function getList($params) {		
		$i = 0;
		$item =array();
		
		$db_hostname = $params->get('db_hostname'); 
		$db_port = $params->get('db_port');
		$db_name = $params->get('db_name');
		$db_user = $params->get('db_user');
		$db_password = $params->get('db_password');
		
		$connection = pg_connect("host='".$db_hostname."' port='".$db_port."' dbname='".$db_name."' user='".$db_user."' password='".$db_password."'");
		$result = array();
		if(isset($_POST['searchterm'])){
			$searchterm = strtoupper(pg_escape_string($_POST['searchterm']));
			$result = pg_query($connection, "SELECT * FROM combinedwarrants WHERE lastname LIKE '%$searchterm%' ORDER BY lastname ASC, firstname ASC;");
		}
		if(isset($_GET['searchterm'])){
			$searchterm = strtoupper(pg_escape_string($_GET['searchterm']));
			$result = pg_query($connection, "SELECT * FROM combinedwarrants WHERE lastname LIKE '$searchterm%' ORDER BY lastname ASC, firstname ASC;");
		}
		
		if(isset($_GET['wid'])){
			$id = $_GET['wid'];
			$query = "SELECT * FROM combinedwarrants WHERE warrantnumber = ".$id.";";
			$result = pg_query($connection,$query);
		}
		
		return $result;

		/*$data = pg_fetch_assoc($result);
		echo "<pre>";
		print_r($data);*/
	

		//exit;
		
		/* Select from trends table */
		/*$query = $db -> getQuery(true);
		$query -> select('title')
			   -> from('#__warrant_search')
			   -> where($db->quoteName('title').'!=""' );
			  
		$db->setQuery($query,0,3);
		$tradeResult = $db->loadObjectList();
		if($tradeResult && !empty($tradeResult)){
			foreach($tradeResult as $row){
				$searchItem = $row -> title;
				if(strlen($searchItem) < 10 && strlen($searchItem) > 0){
					$item[$i] = $searchItem; 
					$i++;
				}
			}
		}
		
		if($i >= 3){
			return $item;	
		}*/
		
		/* Select from #__core_log_searches table */
		/*$query = $db -> getQuery(true);
		$query -> select('search_term')
			   -> from('#__core_log_searches')
			   -> order('hits desc');
		$db->setQuery($query,0,4);
		$result = $db->loadObjectList();
		
		foreach($result as $row){
			$searchItem = $row -> search_term;
			if(strlen($searchItem) < 10 && strlen($searchItem) > 0){
				$item[$i] = $searchItem; 
				$i++;
			}
			if($i >= 3){
				return $item;
			}
		}*/
		return $item;	
	}  	
}

?>
