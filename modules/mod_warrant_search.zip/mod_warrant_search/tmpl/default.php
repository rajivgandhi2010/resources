<?php 
	// no direct access
	defined( '_JEXEC' ) or die( 'Restricted access' ); 
	Jhtml::_('behavior.framework', true);
	// add the script
	JHtml::stylesheet(JURI::base().'modules/'.$module->module.'/css/warrant_search.css');
?>
<!-- This is the view part of max-hits -->
<div class = 'warrant_search' >
	<?php
	if(!isset($_GET['wid']))
	{ ?>
        <form name="cwarrants" method="post" action="warrants">
            <p><label for="searchterm">Search by Last Name:</label></p>
            <input type="text" name="searchterm" id="searchterm" />
            <input type="submit" id="submit" name="submit" value="Submit" />
        </form>
        <p>Browse by Alphabet:</p>
        <a href="warrants?searchterm=A">A</a> 
        <a href="warrants?searchterm=B">B</a> 
        <a href="warrants?searchterm=C">C</a> 
        <a href="warrants?searchterm=D">D</a> 
        <a href="warrants?searchterm=E">E</a> 
        <a href="warrants?searchterm=F">F</a> 
        <a href="warrants?searchterm=G">G</a> 
        <a href="warrants?searchterm=H">H</a> 
        <a href="warrants?searchterm=I">I</a> 
        <a href="warrants?searchterm=J">J</a> 
        <a href="warrants?searchterm=K">K</a> 
        <a href="warrants?searchterm=L">L</a> 
        <a href="warrants?searchterm=M">M</a> 
        <a href="warrants?searchterm=N">N</a> 
        <a href="warrants?searchterm=O">O</a> 
        <a href="warrants?searchterm=P">P</a> 
        <a href="warrants?searchterm=Q">Q</a> 
        <a href="warrants?searchterm=R">R</a> 
        <a href="warrants?searchterm=S">S</a> 
        <a href="warrants?searchterm=T">T</a> 
        <a href="warrants?searchterm=U">U</a> 
        <a href="warrants?searchterm=V">V</a> 
        <a href="warrants?searchterm=W">W</a> 
        <a href="warrants?searchterm=X">X</a> 
        <a href="warrants?searchterm=Y">Y</a> 
        <a href="warrants?searchterm=Z">Z</a>
    
    
        <?php if( (isset($_POST['searchterm']) || isset($_GET['searchterm'])) ){ ?>
        <p class="back_to_warrants"><a href="warrants">Return to Warrant Search</a></p>
        <table class="warrants" border="1">
            <tr>
                <th>Name</th>
                <th>Warrant Number</th>
                <th>Age</th>
                <th>First Charge</th>
                <th>Agency</th>
            </tr>
            <?php
			$data = pg_fetch_array($items);
			//print_r(count($data));exit;
            if(count($data) == 1)
            {
                echo '<tr><td colspan="5">No Records found.</td></tr>';
            }
            else
            { 
                while($data = pg_fetch_array($items)){
                ?>
                <tr>
                    <td>
                        <a href="warrants?wid=<?php echo $data['warrantnumber']?>">
                            <?php echo $data['lastname'].", ".$data['firstname']." ".$data['initial'];
                            if ($data['namesuffix']) {
                                echo " ".$data['namesuffix'];
                            }?>
                        </a>
                    </td>
                    <td><?php echo $data['warrantnumber'];?> - <?php echo $data['jurisdiction']?></td>
                    <td><?php echo abs($data['age']);?></td>
                    <td><?php echo $data['desc1']; ?></td>
                    <td><?php
                        if ($data['agency'] == 'PL+') {?>
                            <a target="_blank" href="http://www.opd.ci.omaha.ne.us">Omaha Police</a>
                        <?php
                        } elseif ($data['agency'] == 'SH+') {?>
                            <a target="_blank" href="http://omahasheriff.org">Sheriff</a>
                        <?php
                        } else { echo "&nbsp;"; }?>
                    </td>
                </tr>	
                <?php } 
            }
            ?>
        </table>
        
        <?php } 
	}
	else
	{ ?>
    	<p class="back_to_warrants"><a href="warrants">Return to Warrant Search</a></p>
		<table border="0" id="warrant_details" cellpadding="5" cellspacing="10">
			<?php $result = pg_fetch_assoc($items); ?>
			<tr><td>Warrant Number:</td><td><?=$result['warrantnumber']?></td></tr>
			<tr>
            	<td>Name:</td>
                <td><?php echo $result['firstname']." ";
					if ($result['initial']) {echo $result['initial'].". ";}
					echo $result['lastname'];
					if ($result['namesuffix']){echo " ".$result['namesuffix'].".";}
					?>
             	</td>
          	</tr>
			<tr><td>Age:</td><td><?=abs($result['age']);?></td></tr>
			<tr>
            	<td>Address:</td>
                <td><?php echo abs($result['housenumber'])." ".$result['addressdirection']." ". $result['streetname']." " .$result['streetsuffix'].". ";
					if($result['apartment']) {
						echo "#".$result['apartment'];
					}	
					echo "<br>".$result['city']." ".$result['state']." ".$result['zipcode'];?>
            	</td>
          	</tr>
			<tr>
            	<td>Gender:</td>
                <td>
					<?php 
						switch($result['gender']) 
						{
							case 'M': 
							echo "Male";
							break;
							case 'F':
							echo "Female";
							break;
							default:
							echo "Unknown";
						}
					?>
            	</td>
        	</tr>
			<tr>
            	<td>Race:</td>
                <td>
					<?php 
						switch($result['race']) 
						{
							case 'W': 
							echo "White";
							break;
							case 'B':
							echo "Black";
							break;
							case 'I': 
							echo "American Indian or Alaskan Native";
							break;
							case 'A':
							echo "Asian or Pacific Islander";
							break;
							case 'H':		
							echo "Hispanic";
							break;
							case 'O':		
							echo "Other";
							break;
							default:
							echo "Unknown";
						}
					?>
               	</td>
        	</tr>
			<tr>
            	<td>Height:</td>
                <td>
					<?php echo substr($result['height'], 0, 1)." "."ft"." ".abs(substr($result['height'],1))." "."inches";?>
                </td>
          	</tr>
			<tr>
            	<td>Weight:</td>
                <td><?php echo $result['weight']." "."lbs";?></td>
         	</tr>
			<tr>
            	<td>Charges:</td>
               	<td>
                	<p><?php echo $result['desc1']?></p>
						<?php if($result['desc2']) echo "<p>".$result['desc2']."</p>";
                        if($result['desc3']) echo "<p>".$result['desc3']."</p>";
                        if($result['desc4']) echo "<p>".$result['desc4']."</p>";
                        if($result['desc5']) echo "<p>".$result['desc5']."</p>";
                        if($result['desc6']) echo "<p>".$result['desc6']."</p>";
                        if($result['desc7']) echo "<p>".$result['desc7']."</p>";
                        if($result['desc8']) echo "<p>".$result['desc8']."</p>";
                        if($result['desc9']) echo "<p>".$result['desc9']."</p>";
                        if($result['desc10']) echo "<p>".$result['desc10']."</p>";
                       ?>
 				</td>
        	</tr>
		</table>
	<?php 
	}
	?>
</div>