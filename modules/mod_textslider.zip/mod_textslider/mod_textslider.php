<?php
/**
 * Text Slider Module Entry Point
 * 
 * @package    Text Slider
 * @subpackage Modules
 * @license        GNU/GPL
 */
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Include the syndicate functions only once
require_once( dirname(__FILE__).'/helper.php' );
 
$items = modTextSliderHelper::getList( $params );

require( JModuleHelper::getLayoutPath( 'mod_textslider',$params->get('layout', 'default') ) );

?>