<?php
/**
 * Helper class for Text Slider module
 * @package    Text Slider
 * @subpackage Modules
 * @license        GNU/GPL
 */
class modTextSliderHelper
{
    /**
     * Retrieves the Text slider message 
     *	no param
	 *	return items 
   	*/
    public static function getList($params) {
		
		$count = $params->get('count');
		
		//Database Connection
		$db = JFactory::getDbo();
		
		//Initiate Query
		$query = $db->getQuery(true);
		
		// Select all records from the #__textslider table where the status is published.
		// Order it by the ordering field.
		$query->select($db->quoteName(array('title', 'description')));
		$query->from($db->quoteName('#__textslider'));
		$query->where($db->quoteName('state')." = 1");
		$query->order('ordering ASC');
		
		$query->setLimit($count);
		 
		// Reset the query using our newly populated query object.
		$db->setQuery($query);
		 
		// Load the results as a list of stdClass objects (see later for more options on retrieving data).
		$items = $db->loadObjectList();
		
		return $items;
	}  	
}
?>