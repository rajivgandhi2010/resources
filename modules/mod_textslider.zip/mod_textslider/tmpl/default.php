<?php // no direct access
	defined( '_JEXEC' ) or die( 'Restricted access' ); 
	Jhtml::_('behavior.framework', true);
	$document = JFactory::getDocument();
	$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/flexslider.css' );
	$document->addScript( JURI::base() . 'modules/mod_' . $module->name . '/js/jquery.flexslider.js' );
	
	$animation_style = $params->get('animation_style');
	$slide_speed = $params->get('slide_speed');
	$animation_speed = $params->get('animation_speed');
	$show_pager = $params->get('show_pager');
?>
<?php
 
	if(count($items)) {
		?>
   		<div id="slideshow">
        	<div id="main">
            	<div class="slider">
                	<div class="flexslider">
                  		<ul class="slides">
							<?php
                            foreach($items as $items){ ?>			
                           		<li>
							   		<h1><?php echo $items->title; ?></h1>
                        			<p><?php echo $items->description; ?></p>
							   	</li>
                            <?php
                            }
                            ?>
						</ul>
                 	</div>
               	</div>
           	</div>
      	</div>
		<?php
		$app = JFactory::getApplication();
		$template = $app->getTemplate();
	}
	else
	{
		echo "No Records Found.";
	}
?>

<script type="text/javascript">
jQuery(window).load(function(){
    jQuery('.flexslider').flexslider({
    	animation: "<?php echo $animation_style; ?>",
		slideshowSpeed:<?php echo $slide_speed; ?>,
		animationSpeed:<?php echo $animation_speed; ?>,
		controlNav: <?php echo $show_pager; ?>, 
   	 	start: function(slider){
      		jQuery('body').removeClass('loading');
      	}	
	});
});
</script>