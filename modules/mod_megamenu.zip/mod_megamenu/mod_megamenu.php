<?php
/**
 * Mega Menu Module
 * 
 * @package    Joomla.Modules
 * @subpackage Modules
 * @license        GNU/GPL, see LICENSE.php
 * mod_trending is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);  
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Include the syndicate functions only once
require_once( dirname(__FILE__).'/helper.php' );
$list = modMegamenuHelper::getMenuList($params);
$app = JFactory::getApplication();
$menu = $app->getMenu();
$active = $menu->getActive();
$active_id = isset($active) ? $active->id : $menu->getDefault()->id;
$path = isset($active) ? $active->tree : array();
$showAll = $params->get('showAllChildren');
$class_sfx = htmlspecialchars($params->get('class_sfx'));

require( JModuleHelper::getLayoutPath( 'mod_megamenu',$params->get('layout', 'default') ) );

?>