<?php
/**
 # @package			Facebook Wall Feed for Joomla! website
 # @sub_package		mod_fbwallfeed - Facebook Wall Feed for Joomla! 2.5
 # @author			NetQ Creative Software
 # @copyright 		Copyright(C) 2012 QExtension.com. All Rights Reserved.
 # @license			GNU/GPL version 2 - http://www.gnu.org/licenses/gpl-2.0.html
 # @website			http://www.qextensions.com
 # @support			http://www.qextensions.com/forum
**/
/**---------------------------------------------------------------------------
 * @file: mod_fbwallfeed.php 2.5.0 00001, Apr 2012 12:00:00Z QExtensions $
 *---------------------------------------------------------------------------*/
error_reporting(E_ALL);
ini_set('display_errors',TRUE);
ini_set('display_startup_errors',TRUE);
defined( '_JEXEC' ) or die( 'Restricted access' );

//define('DS','/');
	
require_once(dirname(__FILE__).'/resources/facebook-php-sdk-master/src/facebook.php');

require_once (dirname(__FILE__).'/helper.php');
$posts = FacebookFeeds::getWallFeed($params);
require( JModuleHelper::getLayoutPath( 'mod_facebookfeeds' ) ); 

?>