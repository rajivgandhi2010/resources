<?php
/**
 # @package			Facebook Feeds
 # @sub_package		mod_facebookfeeds - Facebook Feeds module for Joomla! 3.3
 # @author			Sensiple Software Solutions
 # @copyright 		Copyright(C) 2012 QExtension.com. All Rights Reserved.
 # @license			GNU/GPL version 2 - http://www.gnu.org/licenses/gpl-2.0.html
 # @website			http://www.sensiple.com
**/

defined( '_JEXEC' ) or die( 'Restricted access' );

class FacebookFeeds {
	public static function getWallFeed($params){
	
		// connect to app
		$config = array();
		$config['appId'] = $params->get('fb_app_id');
		$config['secret'] = $params->get('fb_app_secret');
		$config['fileUpload'] = false; // optional
	
		// instantiate
		$facebook = new Facebook($config);
		
		$fb_type = $params->get('type');
		
		// set page id
		$pageid = $params->get('fb_page_id');
		
		// Determine plugin type
		if ($fb_type == 'a.like_btn') {
			// Get Like Button Options
			$fb_url = $params->get('fb_url');	
			$fb_like_btn_layout = $params->get('like_btn_layout');	
			$fb_send = $params->get('fb_send');	
			
			if ($fb_url == '') 
			{
				$protocol = strpos(strtolower($_SERVER['SERVER_PROTOCOL']),'https') === FALSE ? 'http' : 'https';
				$host     = $_SERVER['HTTP_HOST'];
				$uri   = $_SERVER['REQUEST_URI'];
				$fb_url = $protocol . '://' . $host . $uri;
			}
			
			$fb_layout = substr($fb_like_btn_layout, 2);
			
			$spec_char = array(':', '/', '#');
			$html_ent = array('%3A', '%2F', '%23');
			$fb_url_dec = str_replace($spec_char, $html_ent, $fb_url);
						
			$result = '<iframe src="//www.facebook.com/plugins/like.php?href=' . $fb_url_dec . '&amp;layout=button&amp;action=like&amp;show_faces=false&amp;share=false&amp;height=30" scrolling="no" frameborder="0" style="border:none; overflow:hidden;width:50px;height:21px;" allowTransparency="true"></iframe>';
			//exit;
			//break;
			// Include plugin
			//$result = include_once("src/like_btn.php");
			return $result;
		}
		elseif ($fb_type == "a.like_box") {
			// now we can access various parts of the graph, starting with the feed
			$pagefeed = $facebook->api("/" . $pageid . "/feed");
			return $pagefeed;
		}
		else {
			 return "Not Selected";	
		 }
	}
}

?>