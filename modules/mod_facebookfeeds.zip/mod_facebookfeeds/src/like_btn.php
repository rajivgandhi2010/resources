<?php

/**
 * @copyright   Copyright (C) 2012 Brian Coale. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

// Set width
/*if ($fb_width == '') {
	$fb_width = "450";
}*/

// Set URL
if ($fb_url == '') {
	$protocol = strpos(strtolower($_SERVER['SERVER_PROTOCOL']),'https')
       === FALSE ? 'http' : 'https';
	$host     = $_SERVER['HTTP_HOST'];
	$uri   = $_SERVER['REQUEST_URI'];
	$fb_url = $protocol . '://' . $host . $uri;
}

//Set App ID
if ($pageid == "") {
	$pageid = "194674844095";
}

// Show Faces
/*if ($fb_faces == "0") {
	$fb_faces_boolean = "false";
} else {
	$fb_faces_boolean = "true";
}

// Responsive
if ($fb_rspsv == "0") {
	$fb_rspsv_boolean = "false";
} else {
	$fb_rspsv_boolean = "true";
}

// Show Send Button
if ($fb_send == "0") {
	$fb_send_boolean = "false";
} else {
	$fb_send_boolean = "true";
}*/

// Set Layout
$fb_layout = substr($fb_like_btn_layout, 2);

// Set Color
//$fb_color = substr($fb_color_scheme, 2);

// Set Verb
//$fb_verb_opt = substr($fb_verb, 2);

// Set Font Family
//$fb_font_fam = substr($fb_font, 2);

// Show Border
/*if ($fb_border_on == "0") {
	$fb_border_boolean = "false";
} else {
	$fb_border_boolean = "true";
}

// Show Border Radius
if ($fb_border_radius == "0") {
	$fb_border_radius_boolean = "false";
} else {
	$fb_border_radius_boolean = "true";
}*/

// Set Responsive CSS and Add Border Div
/*$rspsv_style = "";

if ($fb_rspsv_boolean == "true") {
	$rspsv_style = "<style type=\"text/css\">#fb-root {display: none;} .fb_iframe_widget, .fb_iframe_widget span, .fb_iframe_widget span iframe[style] {width: 100% !important; } .fb_border { width: 100%; padding: " . $fb_border_padding . "px; background-color: " . $fb_background_color . "; overflow: hidden; ";
	$fb_width = "";
} else {
	$rspsv_style = "<style type=\"text/css\"> .fb_border { width: " . $fb_width . "px; padding: " . $fb_border_padding . "px; background-color: " . $fb_background_color . "; overflow: hidden; ";
}

if ($fb_border_boolean == "true") {
	$rspsv_style .= "border-width: 1px; border-style: solid; border-color: " . $fb_border_color . "; ";
}

if ($fb_border_radius_boolean == "true") {
	$rspsv_style .= "border-radius: " . $fb_border_radius_px . "px; ";
}

$rspsv_style .= "} </style><div class=\"fb_border\">";*/

// Create Facebook Like Button
	$spec_char = array(':', '/', '#');
	$html_ent = array('%3A', '%2F', '%23');
	$fb_url_dec = str_replace($spec_char, $html_ent, $fb_url);
	$pageid = $params->get('fb_page_id');
	//$fb_bcolor_dec = str_replace($spec_char, $html_ent, $fb_border_color);
	echo $mod_data = "<iframe src=\"//www.facebook.com/plugins/like.php?href=" . $fb_url_dec . "&amp;layout=" . $fb_layout . "&amp;appId=" . $pageid . "\" scrolling=\"no\" frameborder=\"0\" style=\"border:none; overflow:hidden;\" allowTransparency=\"true\"></iframe></div>";
	
/*} elseif ($fb_render == 'a.html5') {
	
	$mod_data = $rspsv_style . "<div id=\"fb-root\"></div><script>(function(d, s, id) {  var js, fjs = d.getElementsByTagName(s)[0];  if (d.getElementById(id)) return;  js = d.createElement(s); js.id = id;  js.src = \"//connect.facebook.net/en_US/all.js#xfbml=1&appId=" . $fb_appid . "\";  fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script><div class=\"fb-like\" data-href=\"" . $fb_url . "\" data-width=\"" . $fb_width . "\" data-height=\"" . $fb_height . "\" data-colorscheme=\"" . $fb_color . "\" data-layout=\"" . $fb_layout . "\" data-font=\"" . $fb_font_fam . "\" data-action=\"" . $fb_verb_opt . "\" data-show-faces=\"" . $fb_faces_boolean . "\" data-send=\"" . $fb_send_boolean . "\"></div></div>";
	
} elseif ($fb_render == 'a.xfbml') {
	
	$mod_data = $rspsv_style . "<div id=\"fb-root\"></div><script>(function(d, s, id) {  var js, fjs = d.getElementsByTagName(s)[0];  if (d.getElementById(id)) return;  js = d.createElement(s); js.id = id;  js.src = \"//connect.facebook.net/en_US/all.js#xfbml=1&appId=" . $fb_appid . "\";  fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script><fb:like href=\"" . $fb_url . "\" width=\"" . $fb_width . "\" height=\"" . $fb_height . "\" colorscheme=\"" . $fb_color . "\" layout=\"" . $fb_layout . "\" font=\"" . $fb_font_fam . "\" action=\"" . $fb_verb_opt . "\" show_faces=\"" . $fb_faces_boolean . "\" send=\"" . $fb_send_boolean . "\"></fb:like></div>";

} else {
	$mod_data="Error: Rendering mode does not exist. Please re-save module using a known rendering method.";
}*/
?>