<?php
/**
 # @package			Facebook Feeds
 # @sub_package		mod_facebookfeeds - Facebook Feeds module for Joomla! 3.3
 # @author			Sensiple Software Solutions
 # @copyright 		Copyright(C) 2012 QExtension.com. All Rights Reserved.
 # @license			GNU/GPL version 2 - http://www.gnu.org/licenses/gpl-2.0.html
 # @website			http://www.sensiple.com
**/
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.utilities.string' );

$doc = JFactory::getDocument();
$limit_post = $params->get('post_limit');
$fb_type = $params->get('type');
?>
<?php 
if($fb_type == 'a.like_box') { ?>
<div class="blog-container scrollpanel">
	<?php
	$i = 0;
	if($posts && is_array($posts) && count($posts) > 0){
		foreach($posts['data'] as $post){
			if ($post['type'] == 'status' || $post['type'] == 'link' || $post['type'] == 'photo') {
				echo "<div class=\"fb-update\">";
				/*if ($post['type'] == 'status') {
					//echo "<h2>Status updated: " . date("jS M, Y", (strtotime($post['created_time']))) . "</h2>";
					if (empty($post['story']) === false) {
						echo "<p>" . $post['story'] . "</p>";
					} elseif (empty($post['message']) === false) {
						echo "<p>" . $post['message'] . "</p>";
					}
				}*/
				// check if post type is a photo
				if ($post['type'] == 'photo') {
					//echo "<h2>Photo posted on: " . date("jS M, Y", (strtotime($post['created_time']))) . "</h2>";
					if (empty($post['story']) === false) {
						echo "<p>" . $post['story'] . "</p>";
					} elseif (empty($post['message']) === false) {
						echo "<p>" . $post['message'] . "</p>";
					}
					//echo "<p><a href=\"" . $post['link'] . "\" target=\"_blank\">View photo &rarr;</a></p>";
					$i++;
					if ($i == $limit_post)
						break;
					else
						echo '<hr/>';
				}
				// check if post type is a link
				if ($post['type'] == 'link') {
					//echo "<h2>Link posted on: " . date("jS M, Y", (strtotime($post['created_time']))) . "</h2>";
					echo "<p>" . @$post['name'] . "</p>";
					echo "<p><a href=\"" . $post['link'] . "\" target=\"_blank\">" . $post['link'] . "</a></p>";
					$i++;
					if ($i == $limit_post)
						break;
					else
						echo '<hr/>';
				}echo "</div>";
			}
			
		}
	}
	?>
</div>
<?php } 
if($fb_type == 'a.like_btn')
{
	echo "<img src='images/fb-likebutton.png' class='like_button_img' />";
	echo $posts;
	
}

?>