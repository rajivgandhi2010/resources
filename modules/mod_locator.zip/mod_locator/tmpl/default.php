<?php 
	// no direct access
	defined( '_JEXEC' ) or die( 'Restricted access' ); 
	Jhtml::_('behavior.framework', true);
	$map_url = $params->get('map_url');	
	$map_picture = $params->get('map_picture');	
?>
<!-- This is the view part of max-hits -->
<div class="map">
    <a href="<?php echo $map_url; ?>" target="_blank"><img src="<?php echo $map_picture; ?>" alt="Locator"></a>
</div>


