<?php
/**
 * @package      Social Sharing Module
 * @author       Sensple
 * @copyright    Copyright (C) 2014 Todor. All rights reserved.
 * @license      http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */

// no direct access
defined('_JEXEC') or die;
JLoader::register('SocialsharingHelper', dirname(__FILE__) . DIRECTORY_SEPARATOR . 'helper.php');
$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));
$doc             = JFactory::getDocument();

// Loading style.css
$doc->addStyleSheet("modules/mod_socialsharing/style.css");

// URL
$url = JURI::getInstance()->toString();

// Filter the URL
$filter = JFilterInput::getInstance();
$url    = $filter->clean($url);

$title = $doc->getTitle();

$title = JString::trim($title);
require JModuleHelper::getLayoutPath('mod_socialsharing', $params->get('layout', 'default'));