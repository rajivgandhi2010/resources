<?php 
/**
 * @package      ITPrism Modules
 * @subpackage   ITPShare
 * @author       Todor Iliev
 * @copyright    Copyright (C) 2013 Todor Iliev <todor@itprism.com>. All rights reserved.
 * @license      http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */

defined('_JEXEC') or die;
?>
<div id="social-share" class="social-share-<?php echo $moduleclass_sfx;?>">
    <?php
     echo SocialsharingHelper::getLinkedIn($params, $url);
	echo SocialsharingHelper::getTwitter($params, $url, $title);
	echo SocialsharingHelper::getFacebookLike($params, $url);
	echo SocialsharingHelper::getGooglePlusOne($params, $url);
	echo SocialsharingHelper::getPinterest($params, $url, $title);
	
	
	
	
    echo SocialsharingHelper::getStumbpleUpon($params, $url);
   
    echo SocialsharingHelper::getTumblr($params, $url);
    echo SocialsharingHelper::getBuffer($params, $url, $title);
    
    echo SocialsharingHelper::getReddit($params, $url, $title);
    
    
    echo SocialsharingHelper::getGoogleShare($params, $url);
    echo SocialsharingHelper::getExtraButtons($params, $url, $title);
    ?>
</div>
<div style="clear:both;"></div>