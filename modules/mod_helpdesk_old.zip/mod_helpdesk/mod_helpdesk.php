<?php
/**
 * PC HelpDesk Request Form module
 * @package    PC HelpDesk Request Form
 * @subpackage Modules
 * @license        GNU/GPL
 */

// no direct access
defined('_JEXEC') or die;

// Include the syndicate functions only once
JHtml::_('behavior.framework');
$uniqid				= $module->id;
$name_text			= JText::_('NAME');
$email_text			= JText::_('EMAIL');
$subject_text		= JText::_('SUBJECT');
$msg_text			= JText::_('MESSAGE');
$send_msg			= JText::_('SEND_MESSAGE');
$err_msg			= JText::_('ERR_MSG');
$email_warn			= JText::_('EMAIL_WARN');
$wait_text			= JText::_('WAIT_TEXT');
$failed_text		= JText::_('FAILED_TEXT');

$document 			= JFactory::getDocument();
$document->addScript(JURI::base(true) . '/modules/mod_helpdesk/assets/js/mootools-core.js');
$document->addScript(JURI::base(true) . '/modules/mod_helpdesk/assets/js/script.js');
$document->addStylesheet(JURI::base(true) . '/modules/mod_helpdesk/assets/css/style.css');

require(JModuleHelper::getLayoutPath('mod_helpdesk'));