<?php
/**
 * PC HelpDesk Request Form module
 * @package    PC HelpDesk Request Form
 * @subpackage Modules
 * @license        GNU/GPL
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<script type="text/javascript">
window.addEvent('domready',function(){
	var hd<?php echo $uniqid ?> = new hd('helpdesk_submit', {
		name: document.id('name'),
		modId: <?php echo $uniqid ?>,
		email: document.id('email'),
		subject: document.id('subject'),
		message: document.id('message'),
		status: document.id("helpdesk_status"),
		name_text: "<?php echo $name_text ?>",
		email_text: "<?php echo $email_text ?>",
		msg_text: "<?php echo $msg_text ?>",
		err_msg: "<?php echo $err_msg ?>",
		email_warn: "<?php echo $email_warn ?>",
		wait_text: "<?php echo $wait_text ?>",
		failed_text: "<?php echo $failed_text ?>",
		ajax_url: "<?php echo JURI::base() ?>modules/mod_helpdesk/helper.php"
	});
});
</script>

<div id="helpdesk<?php echo $uniqid ?>" class="helpdesk">

						<div id="helpdesk_status"></div>
						<!-- Name Input --><div class="helpdesk_clr"></div>
						<input type="text" name="name" id="name" class="form" onfocus="if (this.value=='<?php echo $name_text ?>') this.value='';" onblur="if (this.value=='') this.value='<?php echo $name_text ?>';" value="<?php echo $name_text ?>" />
						<!-- Email Input --><div class="helpdesk_clr"></div>
						<input type="text" name="email" id="email" class="form" onfocus="if (this.value=='<?php echo $email_text ?>') this.value='';" onblur="if (this.value=='') this.value='<?php echo $email_text ?>';" value="<?php echo $email_text ?>" />
						<!-- Subject Input --><div class="helpdesk_clr"></div>
						<input type="text" name="subject" id="subject" class="form" onfocus="if (this.value=='<?php echo $subject_text ?>') this.value='';" onblur="if (this.value=='') this.value='<?php echo $subject_text ?>';" value="<?php echo $subject_text ?>" />
						<!-- Message Area --><div class="helpdesk_clr"></div>
						<textarea name="message" id="message" class="form textarea" onfocus="if (this.value=='<?php echo $msg_text ?>') this.value='';" onblur="if (this.value=='') this.value='<?php echo $msg_text ?>';" cols="" rows=""><?php echo $msg_text ?></textarea>	
						<!-- Send Button --><div class="helpdesk_clr"></div>
						<button id="helpdesk_submit" class="button form-btn" type="submit" value="<?php echo $send_msg ?>"><i class="fa fa-envelope"></i></button> 
						<div class="helpdesk_clr"></div>

</div>

