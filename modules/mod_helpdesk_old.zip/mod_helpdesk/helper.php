<?php
/**
 * Helper class for PC HelpDesk Request Form module
 * @package    PC HelpDesk Request Form
 * @subpackage Modules
 * @license        GNU/GPL
 */

define( '_JEXEC', 1 );

define('JPATH_BASE', dirname(__FILE__).'/../../' );
require_once ( JPATH_BASE .'/includes/defines.php' );
require_once ( JPATH_BASE .'/includes/framework.php' );
$mainframe 				= JFactory::getApplication('site');

class HelpDesk{
	function sendEmail(){
		global $mainframe;
		$mail 			= JFactory::getMailer();
		$modId			= JRequest::getVar('modId');	
		$db				= JFactory::getDBO();
		$sql 			= "SELECT params FROM #__modules WHERE id=$modId";
		$db->setQuery($sql);
		$data 			= $db->loadResult();
		$params 		= json_decode($data);
		$success 		= $params->success;
		$failed 		= $params->failed;
		$recipient 		= $params->email;
		
		
		$email 			= JRequest::getVar('email');
		$name 			= JRequest::getVar('name');
		$subject 		= JRequest::getVar('subject');
		$message 		= JRequest::getVar('message');
		
		$sender = array($email, $name);	
		$mail->setSender($sender);
		$mail->addRecipient($recipient);
		$mail->setSubject($subject);
		$mail->isHTML(true);
		$mail->Encoding = 'base64';	
		$mail->setBody($message);
		/*echo "<pre>";
		print_r($mail->Send());
		exit;*/
		if ($mail->Send()) {
		  echo '<p class="sp_qc_success">' . $success . '</p>';
		} else {
		  echo '<p class="sp_qc_warn">' . $failed . '</p>';
		}
	}
	
}	
$hd = new HelpDesk();
$hd->sendEmail();