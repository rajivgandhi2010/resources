<?php
/**
 * @package     Extly.Modules
 * @subpackage  JBDropDownMenu - Menu based on Twitter's Bootstrap, Subnav, Nav Nav-pills, with Dropdown Menu
 *
 * @author      Prieco S.A. <support@extly.com>
 * @copyright   Copyright (C) 2007 - 2012 Prieco, S.A. All rights reserved.
 * @license     http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 * @link        http://www.extly.com http://support.extly.com
 */
// No direct access
defined('_JEXEC') or die('Restricted access');
Jhtml::_('behavior.framework', true);
JHtml::stylesheet(JURI::base() . 'modules/' . $module->module . '/tmpl/css/megamenu.css');
JHtml::script(Juri::base() . 'modules/' . $module->module . '/tmpl/js/jquery.hoverIntent.minified.js');
JHtml::script(Juri::base() . 'modules/' . $module->module . '/tmpl/js/jquery.dcverticalmegamenu.1.3.js');
JHtml::script(Juri::base() . 'modules/' . $module->module . '/tmpl/js/megamenu.js');
// Note. It is important to remove spaces between elements.

?>
<div class="subnav<?php echo $class_sfx; ?>">
	<ul id="mega-1" class="mega-menu">
		<?php
			foreach ($list as $i => &$item)
			{
				$class = 'item-' . $item->id;
				if ($item->id == $active_id)
				{
					$class .= ' current';
				}
				if (in_array($item->id, $path))
				{
					$class .= ' active';
				}
				elseif ($item->type == 'alias')
				{
					$aliasToId = $item->params->get('aliasoptions');
					if (count($path) > 0 && $aliasToId == $path[count($path) - 1])
					{
						$class .= ' active';
					}
					elseif (in_array($aliasToId, $path))
					{
						$class .= ' alias-parent-active';
					}
				}
				if ($item->deeper)
				{
					$class .= ' deeper dropdown';
				}
				if ($item->parent)
				{
					$class .= ' parent';
				}
				if (!empty($class))
				{
					$class = ' class="' . trim($class) . '"';
				}
				echo '<li' . $class . '>';
				// Render the menu item.
				//echo $item->type;
				
				switch ($item->type)
				{
					case 'separator':
					case 'url':
					case 'component':
						require JModuleHelper::getLayoutPath('mod_megamenu', 'default_' . $item->type);
						break;

					default:
						require JModuleHelper::getLayoutPath('mod_megamenu', 'default_url');
						break;
				}

				// The next item is deeper.
				if ($item->deeper)
				{
					if($item->anchor_title)
						$title_tag = '<div id="menu_title_tag">'.$item->anchor_title.'</div>';
					else
						$title_tag = '';
					echo '<ul class="dropdown-menu">'.$title_tag;
				}
				// The next item is shallower.
				elseif ($item->shallower)
				{
					echo '</li>';
						echo str_repeat('<div class="menu_footer_message"><span class="menu_footer_message_bold">Can\'t Find What you are Looking For?</span><br/><span class="menu_footer_message_normal">Try the How Do I menu located at the top of this page, or our improved search bar.</span></div></ul></li>',$item->level_diff);
					//echo '<div>Test Message</div>';
				}
				// The next item is on the same level.
				else
				{
					echo '</li>';
				}
			}
			?> 
</ul>
</div>