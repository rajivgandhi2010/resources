jQuery(document).ready(function($) {
    $('#mega-1').dcVerticalMegaMenu();
});