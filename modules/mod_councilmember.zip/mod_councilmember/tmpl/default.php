<?php
/**
 * @package Council Member slider Joomla Module
 * @author Sensiple
 * @website http://sensiple.com
 * @copyright 2014
 **/
 
//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
ini_set('display_errors', '0');     # don't show any errors...
error_reporting(E_ALL | E_STRICT);  # ...but do log them
Jhtml::_('behavior.framework', true);
//JHtml::_('formbehavior.chosen', 'select');
$document = JFactory::getDocument();
$menu = JSite::getMenu();
$document->addStyleSheet( JURI::base() . 'modules/mod_' . $module->name . '/css/slider.css' );
$document->addScript( JURI::base() . 'modules/mod_' . $module->name . '/js/jssor.js' );
$document->addScript( JURI::base() . 'modules/mod_' . $module->name . '/js/jssor.slider.js' );
$document->addScript( JURI::base() . 'modules/mod_' . $module->name . '/js/slider.js' );
$display_type = $params->get('display_type');
?>

<?php
/*echo "<pre>";
print_r($items);*/
if($display_type =='slider')
{
?>
	<form class="memform" name="members" method="POST">
    	<label>Select the Council Member : </label>
        <select onchange="changePage(this.form.selectedPage)" id="memform" name="selectedPage">
            <option selected="" value="">Select Council Member</option>
            <?php 
			foreach ($items as $item)
			{
			?>
            	<option value="<?php echo JURI::root() . $menu->getItem($item->url)->route; ?>"><?php echo $item->name; ?></option>
            <?php } ?>
        </select>
    </form>
    <div id="slider1_container">
        <div u="slides" id="slide_container">
            <?php
                foreach($items as $item)
                {
                    echo '<div><a href="'. JURI::root() . $menu->getItem($item->url)->route. '" ><img u="image" alt="'. $item->district . " : " . $item->name .'" title="'. $item->district . " : " . $item->name .'" src="'.$item->thumbnail.'" /></a></div>';
                }			
            ?>
        </div>
        <!-- Arrow Left -->
        <span u="arrowleft" class="jssora03l" style="top: 123px; left: 8px;"></span>
        <!-- Arrow Right -->
        <span u="arrowright" class="jssora03r" style="top: 123px; right: 8px;"></span>
    </div>
<?php } ?>