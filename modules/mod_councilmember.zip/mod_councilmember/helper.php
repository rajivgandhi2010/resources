<?php
/**
 * Helper class for Council Member Slider module
 * @package    Text Slider
 * @subpackage Modules
 * @license        GNU/GPL
 */
class modCouncilMemberHelper
{
    /**
     * Retrieves the Council Member slider message 
     *	no param
	 *	return items 
   	*/
    public static function getList($params) {
		$display_type = $params->get('display_type');
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		if($display_type == 'slider')
		{
			$query->select(array('c.*'));
			$query->from($db->quoteName('#__councilmember','c'));
			$query->where($db->quoteName('c.state')." = 1");
			$query->order('c.ordering ASC');
			
			//$query->setLimit($count);
			 
			$db->setQuery($query);
			$items = $db->loadObjectList();
		}		
		else
		{
			$items = $display_type;
		}

		/*$query->select($db->quoteName(array('title', 'description')));
		$query->from($db->quoteName('#__councilmember'));
		$query->where($db->quoteName('state')." = 1");
		$query->order('ordering ASC');
		
		$query->setLimit($count);
		 
		$db->setQuery($query);
		$items = $db->loadObjectList();*/
		
		return $items;
	}  	
}
?>