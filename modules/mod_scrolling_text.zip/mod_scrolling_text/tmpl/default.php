<?php 
	// no direct access
	defined( '_JEXEC' ) or die( 'Restricted access' ); 
	Jhtml::_('behavior.framework', true);
	$scroll_text = $params->get('scroll_text');	
	$animation_speed = $params->get('animation_speed');	
?>
<!-- This is the view part of scrolling text -->
<marquee scrollamount="<?php echo $animation_speed; ?>" onMouseOver="this.setAttribute('scrollamount', 0, 0);this.stop();" OnMouseOut="this.setAttribute('scrollamount', <?php echo $animation_speed; ?>, 0);this.start();"><?php echo $scroll_text; ?></marquee>