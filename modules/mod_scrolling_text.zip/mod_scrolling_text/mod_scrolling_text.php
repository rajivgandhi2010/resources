<?php
/**
 * Scrolling Text Module
 * 
 * @package    Joomla.Modules
 * @subpackage Modules
 * @license    GNU/GPL, see LICENSE.php
 */
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

require( JModuleHelper::getLayoutPath( 'mod_scrolling_text',$params->get('layout', 'default') ) );

?>