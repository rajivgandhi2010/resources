<?php
/*------------------------------------------------------------------------
# "Image Slideshow" Joomla module
# Copyright (C) 2013 Sensiple. All Rights Reserved.
# License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
-------------------------------------------------------------------------*/

//no direct access
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

// Path assignments
$mosConfig_absolute_path = JPATH_SITE;
$mosConfig_live_site = JURI :: base();
if(substr($mosConfig_live_site, -1)=="/") { $mosConfig_live_site = substr($mosConfig_live_site, 0, -1); }
 
// get parameters from the module's configuration
$displayNames = $params->get('displayNames','1');
$displayDesc = $params->get('displayDesc','1');
$displayLink = $params->get('displayLink','1');
$displayAlt = $params->get('displayAlt','1');
$linkNewWindow = $params->get('linkNewWindow','0');

$imageFolder = $params->get('imageFolder','images/stories');

for ($loop = 1; $loop <= 9; $loop += 1) {
$imageArray[$loop] = $params->get('image'.$loop,'');
}

for ($loop = 1; $loop <= 9; $loop += 1) {
$TitleArray[$loop] = $params->get('image'.$loop.'title','');
}

for ($loop = 1; $loop <= 9; $loop += 1) {
$DescArray[$loop] = $params->get('image'.$loop.'desc','');
}

for ($loop = 1; $loop <= 9; $loop += 1) {
$LinkArray[$loop] = $params->get('image'.$loop.'link','');
}

for ($loop = 1; $loop <= 9; $loop += 1) {
$AltArray[$loop] = $params->get('image'.$loop.'alt','');
}

require(JModuleHelper::getLayoutPath('mod_slideshow'));
