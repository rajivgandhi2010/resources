<?php
/*------------------------------------------------------------------------
# "Image Slideshow" Joomla module
# Copyright (C) 2013 Sensiple. All Rights Reserved.
# License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
-------------------------------------------------------------------------*/

defined('_JEXEC') or die('Restricted access'); // no direct access

// get the document object
$doc =& JFactory::getDocument();

?>
<div id="main">
    <div class="slider">
        <div class="flexslider">
            <ul class="slides">
				<?php for ($imageCounter = 1; $imageCounter <= 9; $imageCounter += 1) { ?>
                    <?php if ($imageArray[$imageCounter]) { ?>
                        <li>
                            <img src="<?php echo $mosConfig_live_site; ?>/<?php echo $imageFolder ?>/<?php echo $imageArray[$imageCounter]; ?>" alt="<?php echo $AltArray[$imageCounter]; ?>" />
                            <span class="slideshow-caption-bg">
                                <?php if (($displayLink!=0)and($LinkArray[$imageCounter]!="")) { ?><a href="<?php echo $LinkArray[$imageCounter]; ?>"<?php if($linkNewWindow) { ?> target="_blank"<?php } ?>><?php } ?>
                                    <?php echo $TitleArray[$imageCounter]; ?>
                                <?php if (($displayLink!=0)and($LinkArray[$imageCounter]!="")) { ?></a><?php } ?>
                            </span>
                        </li>
                    <?php } ?>
                <?php } ?>
            </ul>
        </div>
    </div>
</div>